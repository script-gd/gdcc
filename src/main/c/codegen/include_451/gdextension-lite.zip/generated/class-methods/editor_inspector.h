// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INSPECTOR_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INSPECTOR_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorInspector *godot_new_EditorInspector();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorInspector_edit(godot_EditorInspector *self, const godot_Object *object);
GDEXTENSION_LITE_DECL godot_String godot_EditorInspector_get_selected_path(const godot_EditorInspector *self);
GDEXTENSION_LITE_DECL godot_Object * godot_EditorInspector_get_edited_object(godot_EditorInspector *self);
GDEXTENSION_LITE_DECL godot_EditorProperty * godot_EditorInspector_instantiate_property_editor(const godot_Object *object, godot_Variant_Type type, const godot_String *path, godot_PropertyHint hint, const godot_String *hint_text, godot_int usage, godot_bool wide);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INSPECTOR_H__
