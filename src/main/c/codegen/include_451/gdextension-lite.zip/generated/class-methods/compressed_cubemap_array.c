// This file was automatically generated
// Do not modify this file
#include "compressed_cubemap_array.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CompressedCubemapArray *godot_new_CompressedCubemapArray() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CompressedCubemapArray);
}


#ifdef __cplusplus
}
#endif
