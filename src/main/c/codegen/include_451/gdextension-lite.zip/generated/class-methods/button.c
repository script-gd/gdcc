// This file was automatically generated
// Do not modify this file
#include "button.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Button *godot_new_Button() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Button);
}

// Methods
void godot_Button_set_text(godot_Button *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_text, 83702148, void, self, text)
}
godot_String godot_Button_get_text(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_text, 201670096, godot_String, self)
}
void godot_Button_set_text_overrun_behavior(godot_Button *self, godot_TextServer_OverrunBehavior overrun_behavior) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_text_overrun_behavior, 1008890932, void, self, &overrun_behavior)
}
godot_TextServer_OverrunBehavior godot_Button_get_text_overrun_behavior(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_text_overrun_behavior, 3779142101, godot_TextServer_OverrunBehavior, self)
}
void godot_Button_set_autowrap_mode(godot_Button *self, godot_TextServer_AutowrapMode autowrap_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_autowrap_mode, 3289138044, void, self, &autowrap_mode)
}
godot_TextServer_AutowrapMode godot_Button_get_autowrap_mode(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_autowrap_mode, 1549071663, godot_TextServer_AutowrapMode, self)
}
void godot_Button_set_autowrap_trim_flags(godot_Button *self, const godot_TextServer_LineBreakFlag *autowrap_trim_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_autowrap_trim_flags, 2809697122, void, self, autowrap_trim_flags)
}
godot_TextServer_LineBreakFlag godot_Button_get_autowrap_trim_flags(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_autowrap_trim_flags, 2340632602, godot_TextServer_LineBreakFlag, self)
}
void godot_Button_set_text_direction(godot_Button *self, godot_Control_TextDirection direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_text_direction, 119160795, void, self, &direction)
}
godot_Control_TextDirection godot_Button_get_text_direction(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_text_direction, 797257663, godot_Control_TextDirection, self)
}
void godot_Button_set_language(godot_Button *self, const godot_String *language) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_language, 83702148, void, self, language)
}
godot_String godot_Button_get_language(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_language, 201670096, godot_String, self)
}
void godot_Button_set_button_icon(godot_Button *self, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_button_icon, 4051416890, void, self, texture)
}
godot_Texture2D * godot_Button_get_button_icon(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_button_icon, 3635182373, godot_Texture2D *, self)
}
void godot_Button_set_flat(godot_Button *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_flat, 2586408642, void, self, &enabled)
}
godot_bool godot_Button_is_flat(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, is_flat, 36873697, godot_bool, self)
}
void godot_Button_set_clip_text(godot_Button *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_clip_text, 2586408642, void, self, &enabled)
}
godot_bool godot_Button_get_clip_text(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_clip_text, 36873697, godot_bool, self)
}
void godot_Button_set_text_alignment(godot_Button *self, godot_HorizontalAlignment alignment) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_text_alignment, 2312603777, void, self, &alignment)
}
godot_HorizontalAlignment godot_Button_get_text_alignment(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_text_alignment, 341400642, godot_HorizontalAlignment, self)
}
void godot_Button_set_icon_alignment(godot_Button *self, godot_HorizontalAlignment icon_alignment) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_icon_alignment, 2312603777, void, self, &icon_alignment)
}
godot_HorizontalAlignment godot_Button_get_icon_alignment(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_icon_alignment, 341400642, godot_HorizontalAlignment, self)
}
void godot_Button_set_vertical_icon_alignment(godot_Button *self, godot_VerticalAlignment vertical_icon_alignment) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_vertical_icon_alignment, 1796458609, void, self, &vertical_icon_alignment)
}
godot_VerticalAlignment godot_Button_get_vertical_icon_alignment(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, get_vertical_icon_alignment, 3274884059, godot_VerticalAlignment, self)
}
void godot_Button_set_expand_icon(godot_Button *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Button, set_expand_icon, 2586408642, void, self, &enabled)
}
godot_bool godot_Button_is_expand_icon(const godot_Button *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Button, is_expand_icon, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
