// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIRECTIONAL_LIGHT3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIRECTIONAL_LIGHT3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_DirectionalLight3D *godot_new_DirectionalLight3D();

// Methods
GDEXTENSION_LITE_DECL void godot_DirectionalLight3D_set_shadow_mode(godot_DirectionalLight3D *self, godot_DirectionalLight3D_ShadowMode mode);
GDEXTENSION_LITE_DECL godot_DirectionalLight3D_ShadowMode godot_DirectionalLight3D_get_shadow_mode(const godot_DirectionalLight3D *self);
GDEXTENSION_LITE_DECL void godot_DirectionalLight3D_set_blend_splits(godot_DirectionalLight3D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_DirectionalLight3D_is_blend_splits_enabled(const godot_DirectionalLight3D *self);
GDEXTENSION_LITE_DECL void godot_DirectionalLight3D_set_sky_mode(godot_DirectionalLight3D *self, godot_DirectionalLight3D_SkyMode mode);
GDEXTENSION_LITE_DECL godot_DirectionalLight3D_SkyMode godot_DirectionalLight3D_get_sky_mode(const godot_DirectionalLight3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIRECTIONAL_LIGHT3D_H__
