// This file was automatically generated
// Do not modify this file
#include "color_picker.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ColorPicker *godot_new_ColorPicker() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ColorPicker);
}

// Methods
void godot_ColorPicker_set_pick_color(godot_ColorPicker *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_pick_color, 2920490490, void, self, color)
}
godot_Color godot_ColorPicker_get_pick_color(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, get_pick_color, 3444240500, godot_Color, self)
}
void godot_ColorPicker_set_deferred_mode(godot_ColorPicker *self, godot_bool mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_deferred_mode, 2586408642, void, self, &mode)
}
godot_bool godot_ColorPicker_is_deferred_mode(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, is_deferred_mode, 36873697, godot_bool, self)
}
void godot_ColorPicker_set_color_mode(godot_ColorPicker *self, godot_ColorPicker_ColorModeType color_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_color_mode, 1579114136, void, self, &color_mode)
}
godot_ColorPicker_ColorModeType godot_ColorPicker_get_color_mode(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, get_color_mode, 392907674, godot_ColorPicker_ColorModeType, self)
}
void godot_ColorPicker_set_edit_alpha(godot_ColorPicker *self, godot_bool show) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_edit_alpha, 2586408642, void, self, &show)
}
godot_bool godot_ColorPicker_is_editing_alpha(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, is_editing_alpha, 36873697, godot_bool, self)
}
void godot_ColorPicker_set_edit_intensity(godot_ColorPicker *self, godot_bool show) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_edit_intensity, 2586408642, void, self, &show)
}
godot_bool godot_ColorPicker_is_editing_intensity(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, is_editing_intensity, 36873697, godot_bool, self)
}
void godot_ColorPicker_set_can_add_swatches(godot_ColorPicker *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_can_add_swatches, 2586408642, void, self, &enabled)
}
godot_bool godot_ColorPicker_are_swatches_enabled(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, are_swatches_enabled, 36873697, godot_bool, self)
}
void godot_ColorPicker_set_presets_visible(godot_ColorPicker *self, godot_bool visible) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_presets_visible, 2586408642, void, self, &visible)
}
godot_bool godot_ColorPicker_are_presets_visible(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, are_presets_visible, 36873697, godot_bool, self)
}
void godot_ColorPicker_set_modes_visible(godot_ColorPicker *self, godot_bool visible) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_modes_visible, 2586408642, void, self, &visible)
}
godot_bool godot_ColorPicker_are_modes_visible(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, are_modes_visible, 36873697, godot_bool, self)
}
void godot_ColorPicker_set_sampler_visible(godot_ColorPicker *self, godot_bool visible) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_sampler_visible, 2586408642, void, self, &visible)
}
godot_bool godot_ColorPicker_is_sampler_visible(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, is_sampler_visible, 36873697, godot_bool, self)
}
void godot_ColorPicker_set_sliders_visible(godot_ColorPicker *self, godot_bool visible) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_sliders_visible, 2586408642, void, self, &visible)
}
godot_bool godot_ColorPicker_are_sliders_visible(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, are_sliders_visible, 36873697, godot_bool, self)
}
void godot_ColorPicker_set_hex_visible(godot_ColorPicker *self, godot_bool visible) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_hex_visible, 2586408642, void, self, &visible)
}
godot_bool godot_ColorPicker_is_hex_visible(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, is_hex_visible, 36873697, godot_bool, self)
}
void godot_ColorPicker_add_preset(godot_ColorPicker *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, add_preset, 2920490490, void, self, color)
}
void godot_ColorPicker_erase_preset(godot_ColorPicker *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, erase_preset, 2920490490, void, self, color)
}
godot_PackedColorArray godot_ColorPicker_get_presets(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, get_presets, 1392750486, godot_PackedColorArray, self)
}
void godot_ColorPicker_add_recent_preset(godot_ColorPicker *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, add_recent_preset, 2920490490, void, self, color)
}
void godot_ColorPicker_erase_recent_preset(godot_ColorPicker *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, erase_recent_preset, 2920490490, void, self, color)
}
godot_PackedColorArray godot_ColorPicker_get_recent_presets(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, get_recent_presets, 1392750486, godot_PackedColorArray, self)
}
void godot_ColorPicker_set_picker_shape(godot_ColorPicker *self, godot_ColorPicker_PickerShapeType shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPicker, set_picker_shape, 3981373861, void, self, &shape)
}
godot_ColorPicker_PickerShapeType godot_ColorPicker_get_picker_shape(const godot_ColorPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPicker, get_picker_shape, 1143229889, godot_ColorPicker_PickerShapeType, self)
}


#ifdef __cplusplus
}
#endif
