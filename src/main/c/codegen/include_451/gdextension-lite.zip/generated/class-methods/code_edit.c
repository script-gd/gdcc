// This file was automatically generated
// Do not modify this file
#include "code_edit.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CodeEdit *godot_new_CodeEdit() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CodeEdit);
}

// Methods
void godot_CodeEdit__confirm_code_completion(godot_CodeEdit *self, godot_bool replace) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, _confirm_code_completion, 2586408642, void, self, &replace)
}
void godot_CodeEdit__request_code_completion(godot_CodeEdit *self, godot_bool force) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, _request_code_completion, 2586408642, void, self, &force)
}
godot_TypedArray(godot_Dictionary) godot_CodeEdit__filter_code_completion_candidates(const godot_CodeEdit *self, const godot_TypedArray(godot_Dictionary) *candidates) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, _filter_code_completion_candidates, 2560709669, godot_TypedArray(godot_Dictionary), self, candidates)
}
void godot_CodeEdit_set_indent_size(godot_CodeEdit *self, godot_int size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_indent_size, 1286410249, void, self, &size)
}
godot_int godot_CodeEdit_get_indent_size(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_indent_size, 3905245786, godot_int, self)
}
void godot_CodeEdit_set_indent_using_spaces(godot_CodeEdit *self, godot_bool use_spaces) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_indent_using_spaces, 2586408642, void, self, &use_spaces)
}
godot_bool godot_CodeEdit_is_indent_using_spaces(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_indent_using_spaces, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_auto_indent_enabled(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_auto_indent_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_auto_indent_enabled(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_auto_indent_enabled, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_auto_indent_prefixes(godot_CodeEdit *self, const godot_TypedArray(godot_String) *prefixes) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_auto_indent_prefixes, 381264803, void, self, prefixes)
}
godot_TypedArray(godot_String) godot_CodeEdit_get_auto_indent_prefixes(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_auto_indent_prefixes, 3995934104, godot_TypedArray(godot_String), self)
}
void godot_CodeEdit_do_indent(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, do_indent, 3218959716, void, self)
}
void godot_CodeEdit_indent_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, indent_lines, 3218959716, void, self)
}
void godot_CodeEdit_unindent_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, unindent_lines, 3218959716, void, self)
}
void godot_CodeEdit_convert_indent(godot_CodeEdit *self, godot_int from_line, godot_int to_line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, convert_indent, 423910286, void, self, &from_line, &to_line)
}
void godot_CodeEdit_set_auto_brace_completion_enabled(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_auto_brace_completion_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_auto_brace_completion_enabled(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_auto_brace_completion_enabled, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_highlight_matching_braces_enabled(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_highlight_matching_braces_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_highlight_matching_braces_enabled(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_highlight_matching_braces_enabled, 36873697, godot_bool, self)
}
void godot_CodeEdit_add_auto_brace_completion_pair(godot_CodeEdit *self, const godot_String *start_key, const godot_String *end_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, add_auto_brace_completion_pair, 3186203200, void, self, start_key, end_key)
}
void godot_CodeEdit_set_auto_brace_completion_pairs(godot_CodeEdit *self, const godot_Dictionary *pairs) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_auto_brace_completion_pairs, 4155329257, void, self, pairs)
}
godot_Dictionary godot_CodeEdit_get_auto_brace_completion_pairs(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_auto_brace_completion_pairs, 3102165223, godot_Dictionary, self)
}
godot_bool godot_CodeEdit_has_auto_brace_completion_open_key(const godot_CodeEdit *self, const godot_String *open_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, has_auto_brace_completion_open_key, 3927539163, godot_bool, self, open_key)
}
godot_bool godot_CodeEdit_has_auto_brace_completion_close_key(const godot_CodeEdit *self, const godot_String *close_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, has_auto_brace_completion_close_key, 3927539163, godot_bool, self, close_key)
}
godot_String godot_CodeEdit_get_auto_brace_completion_close_key(const godot_CodeEdit *self, const godot_String *open_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_auto_brace_completion_close_key, 3135753539, godot_String, self, open_key)
}
void godot_CodeEdit_set_draw_breakpoints_gutter(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_draw_breakpoints_gutter, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_drawing_breakpoints_gutter(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_drawing_breakpoints_gutter, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_draw_bookmarks_gutter(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_draw_bookmarks_gutter, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_drawing_bookmarks_gutter(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_drawing_bookmarks_gutter, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_draw_executing_lines_gutter(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_draw_executing_lines_gutter, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_drawing_executing_lines_gutter(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_drawing_executing_lines_gutter, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_line_as_breakpoint(godot_CodeEdit *self, godot_int line, godot_bool breakpointed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_line_as_breakpoint, 300928843, void, self, &line, &breakpointed)
}
godot_bool godot_CodeEdit_is_line_breakpointed(const godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_line_breakpointed, 1116898809, godot_bool, self, &line)
}
void godot_CodeEdit_clear_breakpointed_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, clear_breakpointed_lines, 3218959716, void, self)
}
godot_PackedInt32Array godot_CodeEdit_get_breakpointed_lines(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_breakpointed_lines, 1930428628, godot_PackedInt32Array, self)
}
void godot_CodeEdit_set_line_as_bookmarked(godot_CodeEdit *self, godot_int line, godot_bool bookmarked) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_line_as_bookmarked, 300928843, void, self, &line, &bookmarked)
}
godot_bool godot_CodeEdit_is_line_bookmarked(const godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_line_bookmarked, 1116898809, godot_bool, self, &line)
}
void godot_CodeEdit_clear_bookmarked_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, clear_bookmarked_lines, 3218959716, void, self)
}
godot_PackedInt32Array godot_CodeEdit_get_bookmarked_lines(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_bookmarked_lines, 1930428628, godot_PackedInt32Array, self)
}
void godot_CodeEdit_set_line_as_executing(godot_CodeEdit *self, godot_int line, godot_bool executing) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_line_as_executing, 300928843, void, self, &line, &executing)
}
godot_bool godot_CodeEdit_is_line_executing(const godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_line_executing, 1116898809, godot_bool, self, &line)
}
void godot_CodeEdit_clear_executing_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, clear_executing_lines, 3218959716, void, self)
}
godot_PackedInt32Array godot_CodeEdit_get_executing_lines(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_executing_lines, 1930428628, godot_PackedInt32Array, self)
}
void godot_CodeEdit_set_draw_line_numbers(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_draw_line_numbers, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_draw_line_numbers_enabled(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_draw_line_numbers_enabled, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_line_numbers_zero_padded(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_line_numbers_zero_padded, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_line_numbers_zero_padded(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_line_numbers_zero_padded, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_draw_fold_gutter(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_draw_fold_gutter, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_drawing_fold_gutter(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_drawing_fold_gutter, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_line_folding_enabled(godot_CodeEdit *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_line_folding_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CodeEdit_is_line_folding_enabled(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_line_folding_enabled, 36873697, godot_bool, self)
}
godot_bool godot_CodeEdit_can_fold_line(const godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, can_fold_line, 1116898809, godot_bool, self, &line)
}
void godot_CodeEdit_fold_line(godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, fold_line, 1286410249, void, self, &line)
}
void godot_CodeEdit_unfold_line(godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, unfold_line, 1286410249, void, self, &line)
}
void godot_CodeEdit_fold_all_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, fold_all_lines, 3218959716, void, self)
}
void godot_CodeEdit_unfold_all_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, unfold_all_lines, 3218959716, void, self)
}
void godot_CodeEdit_toggle_foldable_line(godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, toggle_foldable_line, 1286410249, void, self, &line)
}
void godot_CodeEdit_toggle_foldable_lines_at_carets(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, toggle_foldable_lines_at_carets, 3218959716, void, self)
}
godot_bool godot_CodeEdit_is_line_folded(const godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_line_folded, 1116898809, godot_bool, self, &line)
}
godot_TypedArray(godot_int) godot_CodeEdit_get_folded_lines(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_folded_lines, 3995934104, godot_TypedArray(godot_int), self)
}
void godot_CodeEdit_create_code_region(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, create_code_region, 3218959716, void, self)
}
godot_String godot_CodeEdit_get_code_region_start_tag(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_code_region_start_tag, 201670096, godot_String, self)
}
godot_String godot_CodeEdit_get_code_region_end_tag(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_code_region_end_tag, 201670096, godot_String, self)
}
void godot_CodeEdit_set_code_region_tags(godot_CodeEdit *self, const godot_String *start, const godot_String *end) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_code_region_tags, 708800718, void, self, start, end)
}
godot_bool godot_CodeEdit_is_line_code_region_start(const godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_line_code_region_start, 1116898809, godot_bool, self, &line)
}
godot_bool godot_CodeEdit_is_line_code_region_end(const godot_CodeEdit *self, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_line_code_region_end, 1116898809, godot_bool, self, &line)
}
void godot_CodeEdit_add_string_delimiter(godot_CodeEdit *self, const godot_String *start_key, const godot_String *end_key, godot_bool line_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, add_string_delimiter, 3146098955, void, self, start_key, end_key, &line_only)
}
void godot_CodeEdit_remove_string_delimiter(godot_CodeEdit *self, const godot_String *start_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, remove_string_delimiter, 83702148, void, self, start_key)
}
godot_bool godot_CodeEdit_has_string_delimiter(const godot_CodeEdit *self, const godot_String *start_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, has_string_delimiter, 3927539163, godot_bool, self, start_key)
}
void godot_CodeEdit_set_string_delimiters(godot_CodeEdit *self, const godot_TypedArray(godot_String) *string_delimiters) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_string_delimiters, 381264803, void, self, string_delimiters)
}
void godot_CodeEdit_clear_string_delimiters(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, clear_string_delimiters, 3218959716, void, self)
}
godot_TypedArray(godot_String) godot_CodeEdit_get_string_delimiters(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_string_delimiters, 3995934104, godot_TypedArray(godot_String), self)
}
godot_int godot_CodeEdit_is_in_string(const godot_CodeEdit *self, godot_int line, godot_int column) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_in_string, 688195400, godot_int, self, &line, &column)
}
void godot_CodeEdit_add_comment_delimiter(godot_CodeEdit *self, const godot_String *start_key, const godot_String *end_key, godot_bool line_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, add_comment_delimiter, 3146098955, void, self, start_key, end_key, &line_only)
}
void godot_CodeEdit_remove_comment_delimiter(godot_CodeEdit *self, const godot_String *start_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, remove_comment_delimiter, 83702148, void, self, start_key)
}
godot_bool godot_CodeEdit_has_comment_delimiter(const godot_CodeEdit *self, const godot_String *start_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, has_comment_delimiter, 3927539163, godot_bool, self, start_key)
}
void godot_CodeEdit_set_comment_delimiters(godot_CodeEdit *self, const godot_TypedArray(godot_String) *comment_delimiters) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_comment_delimiters, 381264803, void, self, comment_delimiters)
}
void godot_CodeEdit_clear_comment_delimiters(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, clear_comment_delimiters, 3218959716, void, self)
}
godot_TypedArray(godot_String) godot_CodeEdit_get_comment_delimiters(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_comment_delimiters, 3995934104, godot_TypedArray(godot_String), self)
}
godot_int godot_CodeEdit_is_in_comment(const godot_CodeEdit *self, godot_int line, godot_int column) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_in_comment, 688195400, godot_int, self, &line, &column)
}
godot_String godot_CodeEdit_get_delimiter_start_key(const godot_CodeEdit *self, godot_int delimiter_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_delimiter_start_key, 844755477, godot_String, self, &delimiter_index)
}
godot_String godot_CodeEdit_get_delimiter_end_key(const godot_CodeEdit *self, godot_int delimiter_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_delimiter_end_key, 844755477, godot_String, self, &delimiter_index)
}
godot_Vector2 godot_CodeEdit_get_delimiter_start_position(const godot_CodeEdit *self, godot_int line, godot_int column) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_delimiter_start_position, 3016396712, godot_Vector2, self, &line, &column)
}
godot_Vector2 godot_CodeEdit_get_delimiter_end_position(const godot_CodeEdit *self, godot_int line, godot_int column) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_delimiter_end_position, 3016396712, godot_Vector2, self, &line, &column)
}
void godot_CodeEdit_set_code_hint(godot_CodeEdit *self, const godot_String *code_hint) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_code_hint, 83702148, void, self, code_hint)
}
void godot_CodeEdit_set_code_hint_draw_below(godot_CodeEdit *self, godot_bool draw_below) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_code_hint_draw_below, 2586408642, void, self, &draw_below)
}
godot_String godot_CodeEdit_get_text_for_code_completion(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_text_for_code_completion, 201670096, godot_String, self)
}
void godot_CodeEdit_request_code_completion(godot_CodeEdit *self, godot_bool force) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, request_code_completion, 107499316, void, self, &force)
}
void godot_CodeEdit_add_code_completion_option(godot_CodeEdit *self, godot_CodeEdit_CodeCompletionKind type, const godot_String *display_text, const godot_String *insert_text, const godot_Color *text_color, const godot_Resource *icon, const godot_Variant *value, godot_int location) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, add_code_completion_option, 3944379502, void, self, &type, display_text, insert_text, text_color, icon, value, &location)
}
void godot_CodeEdit_update_code_completion_options(godot_CodeEdit *self, godot_bool force) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, update_code_completion_options, 2586408642, void, self, &force)
}
godot_TypedArray(godot_Dictionary) godot_CodeEdit_get_code_completion_options(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_code_completion_options, 3995934104, godot_TypedArray(godot_Dictionary), self)
}
godot_Dictionary godot_CodeEdit_get_code_completion_option(const godot_CodeEdit *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_code_completion_option, 3485342025, godot_Dictionary, self, &index)
}
godot_int godot_CodeEdit_get_code_completion_selected_index(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_code_completion_selected_index, 3905245786, godot_int, self)
}
void godot_CodeEdit_set_code_completion_selected_index(godot_CodeEdit *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_code_completion_selected_index, 1286410249, void, self, &index)
}
void godot_CodeEdit_confirm_code_completion(godot_CodeEdit *self, godot_bool replace) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, confirm_code_completion, 107499316, void, self, &replace)
}
void godot_CodeEdit_cancel_code_completion(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, cancel_code_completion, 3218959716, void, self)
}
void godot_CodeEdit_set_code_completion_enabled(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_code_completion_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_code_completion_enabled(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_code_completion_enabled, 36873697, godot_bool, self)
}
void godot_CodeEdit_set_code_completion_prefixes(godot_CodeEdit *self, const godot_TypedArray(godot_String) *prefixes) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_code_completion_prefixes, 381264803, void, self, prefixes)
}
godot_TypedArray(godot_String) godot_CodeEdit_get_code_completion_prefixes(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_code_completion_prefixes, 3995934104, godot_TypedArray(godot_String), self)
}
void godot_CodeEdit_set_line_length_guidelines(godot_CodeEdit *self, const godot_TypedArray(godot_int) *guideline_columns) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_line_length_guidelines, 381264803, void, self, guideline_columns)
}
godot_TypedArray(godot_int) godot_CodeEdit_get_line_length_guidelines(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_line_length_guidelines, 3995934104, godot_TypedArray(godot_int), self)
}
void godot_CodeEdit_set_symbol_lookup_on_click_enabled(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_symbol_lookup_on_click_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_symbol_lookup_on_click_enabled(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_symbol_lookup_on_click_enabled, 36873697, godot_bool, self)
}
godot_String godot_CodeEdit_get_text_for_symbol_lookup(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_text_for_symbol_lookup, 201670096, godot_String, self)
}
godot_String godot_CodeEdit_get_text_with_cursor_char(const godot_CodeEdit *self, godot_int line, godot_int column) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, get_text_with_cursor_char, 1391810591, godot_String, self, &line, &column)
}
void godot_CodeEdit_set_symbol_lookup_word_as_valid(godot_CodeEdit *self, godot_bool valid) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_symbol_lookup_word_as_valid, 2586408642, void, self, &valid)
}
void godot_CodeEdit_set_symbol_tooltip_on_hover_enabled(godot_CodeEdit *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, set_symbol_tooltip_on_hover_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_CodeEdit_is_symbol_tooltip_on_hover_enabled(const godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeEdit, is_symbol_tooltip_on_hover_enabled, 36873697, godot_bool, self)
}
void godot_CodeEdit_move_lines_up(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, move_lines_up, 3218959716, void, self)
}
void godot_CodeEdit_move_lines_down(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, move_lines_down, 3218959716, void, self)
}
void godot_CodeEdit_delete_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, delete_lines, 3218959716, void, self)
}
void godot_CodeEdit_duplicate_selection(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, duplicate_selection, 3218959716, void, self)
}
void godot_CodeEdit_duplicate_lines(godot_CodeEdit *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeEdit, duplicate_lines, 3218959716, void, self)
}


#ifdef __cplusplus
}
#endif
