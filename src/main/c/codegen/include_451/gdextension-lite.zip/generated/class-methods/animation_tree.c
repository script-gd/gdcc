// This file was automatically generated
// Do not modify this file
#include "animation_tree.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationTree *godot_new_AnimationTree() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationTree);
}

// Methods
void godot_AnimationTree_set_tree_root(godot_AnimationTree *self, const godot_AnimationRootNode *animation_node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationTree, set_tree_root, 2581683800, void, self, animation_node)
}
godot_AnimationRootNode * godot_AnimationTree_get_tree_root(const godot_AnimationTree *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationTree, get_tree_root, 4110384712, godot_AnimationRootNode *, self)
}
void godot_AnimationTree_set_advance_expression_base_node(godot_AnimationTree *self, const godot_NodePath *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationTree, set_advance_expression_base_node, 1348162250, void, self, path)
}
godot_NodePath godot_AnimationTree_get_advance_expression_base_node(const godot_AnimationTree *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationTree, get_advance_expression_base_node, 4075236667, godot_NodePath, self)
}
void godot_AnimationTree_set_animation_player(godot_AnimationTree *self, const godot_NodePath *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationTree, set_animation_player, 1348162250, void, self, path)
}
godot_NodePath godot_AnimationTree_get_animation_player(const godot_AnimationTree *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationTree, get_animation_player, 4075236667, godot_NodePath, self)
}
void godot_AnimationTree_set_process_callback(godot_AnimationTree *self, godot_AnimationTree_AnimationProcessCallback mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationTree, set_process_callback, 1723352826, void, self, &mode)
}
godot_AnimationTree_AnimationProcessCallback godot_AnimationTree_get_process_callback(const godot_AnimationTree *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationTree, get_process_callback, 891317132, godot_AnimationTree_AnimationProcessCallback, self)
}


#ifdef __cplusplus
}
#endif
