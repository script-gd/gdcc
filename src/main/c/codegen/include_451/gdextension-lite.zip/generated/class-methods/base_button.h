// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BASE_BUTTON_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BASE_BUTTON_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BaseButton *godot_new_BaseButton();

// Methods
GDEXTENSION_LITE_DECL void godot_BaseButton__pressed(godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton__toggled(godot_BaseButton *self, godot_bool toggled_on);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_pressed(godot_BaseButton *self, godot_bool pressed);
GDEXTENSION_LITE_DECL godot_bool godot_BaseButton_is_pressed(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_pressed_no_signal(godot_BaseButton *self, godot_bool pressed);
GDEXTENSION_LITE_DECL godot_bool godot_BaseButton_is_hovered(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_toggle_mode(godot_BaseButton *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_BaseButton_is_toggle_mode(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_shortcut_in_tooltip(godot_BaseButton *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_BaseButton_is_shortcut_in_tooltip_enabled(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_disabled(godot_BaseButton *self, godot_bool disabled);
GDEXTENSION_LITE_DECL godot_bool godot_BaseButton_is_disabled(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_action_mode(godot_BaseButton *self, godot_BaseButton_ActionMode mode);
GDEXTENSION_LITE_DECL godot_BaseButton_ActionMode godot_BaseButton_get_action_mode(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_button_mask(godot_BaseButton *self, const godot_MouseButtonMask *mask);
GDEXTENSION_LITE_DECL godot_MouseButtonMask godot_BaseButton_get_button_mask(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL godot_BaseButton_DrawMode godot_BaseButton_get_draw_mode(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_keep_pressed_outside(godot_BaseButton *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_BaseButton_is_keep_pressed_outside(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_shortcut_feedback(godot_BaseButton *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_BaseButton_is_shortcut_feedback(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_shortcut(godot_BaseButton *self, const godot_Shortcut *shortcut);
GDEXTENSION_LITE_DECL godot_Shortcut * godot_BaseButton_get_shortcut(const godot_BaseButton *self);
GDEXTENSION_LITE_DECL void godot_BaseButton_set_button_group(godot_BaseButton *self, const godot_ButtonGroup *button_group);
GDEXTENSION_LITE_DECL godot_ButtonGroup * godot_BaseButton_get_button_group(const godot_BaseButton *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BASE_BUTTON_H__
