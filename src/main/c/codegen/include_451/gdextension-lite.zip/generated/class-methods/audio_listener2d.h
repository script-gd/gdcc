// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_LISTENER2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_LISTENER2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioListener2D *godot_new_AudioListener2D();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioListener2D_make_current(godot_AudioListener2D *self);
GDEXTENSION_LITE_DECL void godot_AudioListener2D_clear_current(godot_AudioListener2D *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioListener2D_is_current(const godot_AudioListener2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_LISTENER2D_H__
