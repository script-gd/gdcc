// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_EQ_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_EQ_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectEQ *godot_new_AudioEffectEQ();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectEQ_set_band_gain_db(godot_AudioEffectEQ *self, godot_int band_idx, godot_float volume_db);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectEQ_get_band_gain_db(const godot_AudioEffectEQ *self, godot_int band_idx);
GDEXTENSION_LITE_DECL godot_int godot_AudioEffectEQ_get_band_count(const godot_AudioEffectEQ *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_EQ_H__
