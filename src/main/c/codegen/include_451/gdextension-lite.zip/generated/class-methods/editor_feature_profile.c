// This file was automatically generated
// Do not modify this file
#include "editor_feature_profile.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorFeatureProfile *godot_new_EditorFeatureProfile() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorFeatureProfile);
}

// Methods
void godot_EditorFeatureProfile_set_disable_class(godot_EditorFeatureProfile *self, const godot_StringName *class_name, godot_bool disable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFeatureProfile, set_disable_class, 2524380260, void, self, class_name, &disable)
}
godot_bool godot_EditorFeatureProfile_is_class_disabled(const godot_EditorFeatureProfile *self, const godot_StringName *class_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFeatureProfile, is_class_disabled, 2619796661, godot_bool, self, class_name)
}
void godot_EditorFeatureProfile_set_disable_class_editor(godot_EditorFeatureProfile *self, const godot_StringName *class_name, godot_bool disable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFeatureProfile, set_disable_class_editor, 2524380260, void, self, class_name, &disable)
}
godot_bool godot_EditorFeatureProfile_is_class_editor_disabled(const godot_EditorFeatureProfile *self, const godot_StringName *class_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFeatureProfile, is_class_editor_disabled, 2619796661, godot_bool, self, class_name)
}
void godot_EditorFeatureProfile_set_disable_class_property(godot_EditorFeatureProfile *self, const godot_StringName *class_name, const godot_StringName *property, godot_bool disable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFeatureProfile, set_disable_class_property, 865197084, void, self, class_name, property, &disable)
}
godot_bool godot_EditorFeatureProfile_is_class_property_disabled(const godot_EditorFeatureProfile *self, const godot_StringName *class_name, const godot_StringName *property) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFeatureProfile, is_class_property_disabled, 471820014, godot_bool, self, class_name, property)
}
void godot_EditorFeatureProfile_set_disable_feature(godot_EditorFeatureProfile *self, godot_EditorFeatureProfile_Feature feature, godot_bool disable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFeatureProfile, set_disable_feature, 1884871044, void, self, &feature, &disable)
}
godot_bool godot_EditorFeatureProfile_is_feature_disabled(const godot_EditorFeatureProfile *self, godot_EditorFeatureProfile_Feature feature) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFeatureProfile, is_feature_disabled, 2974403161, godot_bool, self, &feature)
}
godot_String godot_EditorFeatureProfile_get_feature_name(godot_EditorFeatureProfile *self, godot_EditorFeatureProfile_Feature feature) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFeatureProfile, get_feature_name, 3401335809, godot_String, self, &feature)
}
godot_Error godot_EditorFeatureProfile_save_to_file(godot_EditorFeatureProfile *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFeatureProfile, save_to_file, 166001499, godot_Error, self, path)
}
godot_Error godot_EditorFeatureProfile_load_from_file(godot_EditorFeatureProfile *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFeatureProfile, load_from_file, 166001499, godot_Error, self, path)
}


#ifdef __cplusplus
}
#endif
