// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FEATURE_PROFILE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FEATURE_PROFILE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorFeatureProfile *godot_new_EditorFeatureProfile();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorFeatureProfile_set_disable_class(godot_EditorFeatureProfile *self, const godot_StringName *class_name, godot_bool disable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFeatureProfile_is_class_disabled(const godot_EditorFeatureProfile *self, const godot_StringName *class_name);
GDEXTENSION_LITE_DECL void godot_EditorFeatureProfile_set_disable_class_editor(godot_EditorFeatureProfile *self, const godot_StringName *class_name, godot_bool disable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFeatureProfile_is_class_editor_disabled(const godot_EditorFeatureProfile *self, const godot_StringName *class_name);
GDEXTENSION_LITE_DECL void godot_EditorFeatureProfile_set_disable_class_property(godot_EditorFeatureProfile *self, const godot_StringName *class_name, const godot_StringName *property, godot_bool disable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFeatureProfile_is_class_property_disabled(const godot_EditorFeatureProfile *self, const godot_StringName *class_name, const godot_StringName *property);
GDEXTENSION_LITE_DECL void godot_EditorFeatureProfile_set_disable_feature(godot_EditorFeatureProfile *self, godot_EditorFeatureProfile_Feature feature, godot_bool disable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFeatureProfile_is_feature_disabled(const godot_EditorFeatureProfile *self, godot_EditorFeatureProfile_Feature feature);
GDEXTENSION_LITE_DECL godot_String godot_EditorFeatureProfile_get_feature_name(godot_EditorFeatureProfile *self, godot_EditorFeatureProfile_Feature feature);
GDEXTENSION_LITE_DECL godot_Error godot_EditorFeatureProfile_save_to_file(godot_EditorFeatureProfile *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Error godot_EditorFeatureProfile_load_from_file(godot_EditorFeatureProfile *self, const godot_String *path);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FEATURE_PROFILE_H__
