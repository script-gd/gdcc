// This file was automatically generated
// Do not modify this file
#include "audio_stream_playback_resampled.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamPlaybackResampled *godot_new_AudioStreamPlaybackResampled() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamPlaybackResampled);
}

// Methods
godot_int godot_AudioStreamPlaybackResampled__mix_resampled(godot_AudioStreamPlaybackResampled *self, godot_AudioFrame* dst_buffer, godot_int frame_count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaybackResampled, _mix_resampled, 50157827, godot_int, self, dst_buffer, &frame_count)
}
godot_float godot_AudioStreamPlaybackResampled__get_stream_sampling_rate(const godot_AudioStreamPlaybackResampled *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaybackResampled, _get_stream_sampling_rate, 1740695150, godot_float, self)
}
void godot_AudioStreamPlaybackResampled_begin_resample(godot_AudioStreamPlaybackResampled *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaybackResampled, begin_resample, 3218959716, void, self)
}


#ifdef __cplusplus
}
#endif
