// This file was automatically generated
// Do not modify this file
#include "editor_inspector_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorInspectorPlugin *godot_new_EditorInspectorPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorInspectorPlugin);
}

// Methods
godot_bool godot_EditorInspectorPlugin__can_handle(const godot_EditorInspectorPlugin *self, const godot_Object *object) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInspectorPlugin, _can_handle, 397768994, godot_bool, self, object)
}
void godot_EditorInspectorPlugin__parse_begin(godot_EditorInspectorPlugin *self, const godot_Object *object) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInspectorPlugin, _parse_begin, 3975164845, void, self, object)
}
void godot_EditorInspectorPlugin__parse_category(godot_EditorInspectorPlugin *self, const godot_Object *object, const godot_String *category) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInspectorPlugin, _parse_category, 357144787, void, self, object, category)
}
void godot_EditorInspectorPlugin__parse_group(godot_EditorInspectorPlugin *self, const godot_Object *object, const godot_String *group) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInspectorPlugin, _parse_group, 357144787, void, self, object, group)
}
godot_bool godot_EditorInspectorPlugin__parse_property(godot_EditorInspectorPlugin *self, const godot_Object *object, godot_Variant_Type type, const godot_String *name, godot_PropertyHint hint_type, const godot_String *hint_string, const godot_PropertyUsageFlags *usage_flags, godot_bool wide) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInspectorPlugin, _parse_property, 1087679910, godot_bool, self, object, &type, name, &hint_type, hint_string, usage_flags, &wide)
}
void godot_EditorInspectorPlugin__parse_end(godot_EditorInspectorPlugin *self, const godot_Object *object) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInspectorPlugin, _parse_end, 3975164845, void, self, object)
}
void godot_EditorInspectorPlugin_add_custom_control(godot_EditorInspectorPlugin *self, const godot_Control *control) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInspectorPlugin, add_custom_control, 1496901182, void, self, control)
}
void godot_EditorInspectorPlugin_add_property_editor(godot_EditorInspectorPlugin *self, const godot_String *property, const godot_Control *editor, godot_bool add_to_end, const godot_String *label) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInspectorPlugin, add_property_editor, 2042698479, void, self, property, editor, &add_to_end, label)
}
void godot_EditorInspectorPlugin_add_property_editor_for_multiple_properties(godot_EditorInspectorPlugin *self, const godot_String *label, const godot_PackedStringArray *properties, const godot_Control *editor) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInspectorPlugin, add_property_editor_for_multiple_properties, 788598683, void, self, label, properties, editor)
}


#ifdef __cplusplus
}
#endif
