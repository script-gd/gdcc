// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASTAR2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASTAR2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AStar2D *godot_new_AStar2D();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_AStar2D__filter_neighbor(const godot_AStar2D *self, godot_int from_id, godot_int neighbor_id);
GDEXTENSION_LITE_DECL godot_float godot_AStar2D__estimate_cost(const godot_AStar2D *self, godot_int from_id, godot_int end_id);
GDEXTENSION_LITE_DECL godot_float godot_AStar2D__compute_cost(const godot_AStar2D *self, godot_int from_id, godot_int to_id);
GDEXTENSION_LITE_DECL godot_int godot_AStar2D_get_available_point_id(const godot_AStar2D *self);
GDEXTENSION_LITE_DECL void godot_AStar2D_add_point(godot_AStar2D *self, godot_int id, const godot_Vector2 *position, godot_float weight_scale);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AStar2D_get_point_position(const godot_AStar2D *self, godot_int id);
GDEXTENSION_LITE_DECL void godot_AStar2D_set_point_position(godot_AStar2D *self, godot_int id, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL godot_float godot_AStar2D_get_point_weight_scale(const godot_AStar2D *self, godot_int id);
GDEXTENSION_LITE_DECL void godot_AStar2D_set_point_weight_scale(godot_AStar2D *self, godot_int id, godot_float weight_scale);
GDEXTENSION_LITE_DECL void godot_AStar2D_remove_point(godot_AStar2D *self, godot_int id);
GDEXTENSION_LITE_DECL godot_bool godot_AStar2D_has_point(const godot_AStar2D *self, godot_int id);
GDEXTENSION_LITE_DECL godot_PackedInt64Array godot_AStar2D_get_point_connections(godot_AStar2D *self, godot_int id);
GDEXTENSION_LITE_DECL godot_PackedInt64Array godot_AStar2D_get_point_ids(godot_AStar2D *self);
GDEXTENSION_LITE_DECL void godot_AStar2D_set_neighbor_filter_enabled(godot_AStar2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_AStar2D_is_neighbor_filter_enabled(const godot_AStar2D *self);
GDEXTENSION_LITE_DECL void godot_AStar2D_set_point_disabled(godot_AStar2D *self, godot_int id, godot_bool disabled);
GDEXTENSION_LITE_DECL godot_bool godot_AStar2D_is_point_disabled(const godot_AStar2D *self, godot_int id);
GDEXTENSION_LITE_DECL void godot_AStar2D_connect_points(godot_AStar2D *self, godot_int id, godot_int to_id, godot_bool bidirectional);
GDEXTENSION_LITE_DECL void godot_AStar2D_disconnect_points(godot_AStar2D *self, godot_int id, godot_int to_id, godot_bool bidirectional);
GDEXTENSION_LITE_DECL godot_bool godot_AStar2D_are_points_connected(const godot_AStar2D *self, godot_int id, godot_int to_id, godot_bool bidirectional);
GDEXTENSION_LITE_DECL godot_int godot_AStar2D_get_point_count(const godot_AStar2D *self);
GDEXTENSION_LITE_DECL godot_int godot_AStar2D_get_point_capacity(const godot_AStar2D *self);
GDEXTENSION_LITE_DECL void godot_AStar2D_reserve_space(godot_AStar2D *self, godot_int num_nodes);
GDEXTENSION_LITE_DECL void godot_AStar2D_clear(godot_AStar2D *self);
GDEXTENSION_LITE_DECL godot_int godot_AStar2D_get_closest_point(const godot_AStar2D *self, const godot_Vector2 *to_position, godot_bool include_disabled);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AStar2D_get_closest_position_in_segment(const godot_AStar2D *self, const godot_Vector2 *to_position);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_AStar2D_get_point_path(godot_AStar2D *self, godot_int from_id, godot_int to_id, godot_bool allow_partial_path);
GDEXTENSION_LITE_DECL godot_PackedInt64Array godot_AStar2D_get_id_path(godot_AStar2D *self, godot_int from_id, godot_int to_id, godot_bool allow_partial_path);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASTAR2D_H__
