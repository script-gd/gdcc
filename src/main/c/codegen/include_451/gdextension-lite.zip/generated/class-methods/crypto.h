// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CRYPTO_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CRYPTO_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Crypto *godot_new_Crypto();

// Methods
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_Crypto_generate_random_bytes(godot_Crypto *self, godot_int size);
GDEXTENSION_LITE_DECL godot_CryptoKey * godot_Crypto_generate_rsa(godot_Crypto *self, godot_int size);
GDEXTENSION_LITE_DECL godot_X509Certificate * godot_Crypto_generate_self_signed_certificate(godot_Crypto *self, const godot_CryptoKey *key, const godot_String *issuer_name, const godot_String *not_before, const godot_String *not_after);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_Crypto_sign(godot_Crypto *self, godot_HashingContext_HashType hash_type, const godot_PackedByteArray *hash, const godot_CryptoKey *key);
GDEXTENSION_LITE_DECL godot_bool godot_Crypto_verify(godot_Crypto *self, godot_HashingContext_HashType hash_type, const godot_PackedByteArray *hash, const godot_PackedByteArray *signature, const godot_CryptoKey *key);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_Crypto_encrypt(godot_Crypto *self, const godot_CryptoKey *key, const godot_PackedByteArray *plaintext);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_Crypto_decrypt(godot_Crypto *self, const godot_CryptoKey *key, const godot_PackedByteArray *ciphertext);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_Crypto_hmac_digest(godot_Crypto *self, godot_HashingContext_HashType hash_type, const godot_PackedByteArray *key, const godot_PackedByteArray *msg);
GDEXTENSION_LITE_DECL godot_bool godot_Crypto_constant_time_compare(godot_Crypto *self, const godot_PackedByteArray *trusted, const godot_PackedByteArray *received);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CRYPTO_H__
