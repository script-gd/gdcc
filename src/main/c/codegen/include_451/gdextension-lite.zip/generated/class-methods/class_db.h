// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CLASS_DB_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CLASS_DB_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
GDEXTENSION_LITE_DECL godot_ClassDB *godot_ClassDB_singleton();

// Methods
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_ClassDB_get_class_list(const godot_ClassDB *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_ClassDB_get_inheriters_from_class(const godot_ClassDB *self, const godot_StringName *cls);
GDEXTENSION_LITE_DECL godot_StringName godot_ClassDB_get_parent_class(const godot_ClassDB *self, const godot_StringName *cls);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_class_exists(const godot_ClassDB *self, const godot_StringName *cls);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_is_parent_class(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *inherits);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_can_instantiate(const godot_ClassDB *self, const godot_StringName *cls);
GDEXTENSION_LITE_DECL godot_Variant godot_ClassDB_instantiate(const godot_ClassDB *self, const godot_StringName *cls);
GDEXTENSION_LITE_DECL godot_ClassDB_APIType godot_ClassDB_class_get_api_type(const godot_ClassDB *self, const godot_StringName *cls);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_class_has_signal(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *signal);
GDEXTENSION_LITE_DECL godot_Dictionary godot_ClassDB_class_get_signal(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *signal);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_ClassDB_class_get_signal_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_ClassDB_class_get_property_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_StringName godot_ClassDB_class_get_property_getter(godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *property);
GDEXTENSION_LITE_DECL godot_StringName godot_ClassDB_class_get_property_setter(godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *property);
GDEXTENSION_LITE_DECL godot_Variant godot_ClassDB_class_get_property(const godot_ClassDB *self, const godot_Object *object, const godot_StringName *property);
GDEXTENSION_LITE_DECL godot_Error godot_ClassDB_class_set_property(const godot_ClassDB *self, const godot_Object *object, const godot_StringName *property, const godot_Variant *value);
GDEXTENSION_LITE_DECL godot_Variant godot_ClassDB_class_get_property_default_value(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *property);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_class_has_method(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *method, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_int godot_ClassDB_class_get_method_argument_count(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *method, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_ClassDB_class_get_method_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_Variant godot_ClassDB_class_call_static(godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *method, const godot_Variant **argv, godot_int argc);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_ClassDB_class_get_integer_constant_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_class_has_integer_constant(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_int godot_ClassDB_class_get_integer_constant(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_class_has_enum(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *name, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_ClassDB_class_get_enum_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_ClassDB_class_get_enum_constants(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *enumeration, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_StringName godot_ClassDB_class_get_integer_constant_enum(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *name, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_is_class_enum_bitfield(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *enumeration, godot_bool no_inheritance);
GDEXTENSION_LITE_DECL godot_bool godot_ClassDB_is_class_enabled(const godot_ClassDB *self, const godot_StringName *cls);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CLASS_DB_H__
