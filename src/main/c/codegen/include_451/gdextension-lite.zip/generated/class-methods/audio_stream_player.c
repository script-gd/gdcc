// This file was automatically generated
// Do not modify this file
#include "audio_stream_player.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamPlayer *godot_new_AudioStreamPlayer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamPlayer);
}

// Methods
void godot_AudioStreamPlayer_set_stream(godot_AudioStreamPlayer *self, const godot_AudioStream *stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_stream, 2210767741, void, self, stream)
}
godot_AudioStream * godot_AudioStreamPlayer_get_stream(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_stream, 160907539, godot_AudioStream *, self)
}
void godot_AudioStreamPlayer_set_volume_db(godot_AudioStreamPlayer *self, godot_float volume_db) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_volume_db, 373806689, void, self, &volume_db)
}
godot_float godot_AudioStreamPlayer_get_volume_db(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_volume_db, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayer_set_volume_linear(godot_AudioStreamPlayer *self, godot_float volume_linear) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_volume_linear, 373806689, void, self, &volume_linear)
}
godot_float godot_AudioStreamPlayer_get_volume_linear(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_volume_linear, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayer_set_pitch_scale(godot_AudioStreamPlayer *self, godot_float pitch_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_pitch_scale, 373806689, void, self, &pitch_scale)
}
godot_float godot_AudioStreamPlayer_get_pitch_scale(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_pitch_scale, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayer_play(godot_AudioStreamPlayer *self, godot_float from_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, play, 1958160172, void, self, &from_position)
}
void godot_AudioStreamPlayer_seek(godot_AudioStreamPlayer *self, godot_float to_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, seek, 373806689, void, self, &to_position)
}
void godot_AudioStreamPlayer_stop(godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, stop, 3218959716, void, self)
}
godot_bool godot_AudioStreamPlayer_is_playing(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, is_playing, 36873697, godot_bool, self)
}
godot_float godot_AudioStreamPlayer_get_playback_position(godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_playback_position, 191475506, godot_float, self)
}
void godot_AudioStreamPlayer_set_bus(godot_AudioStreamPlayer *self, const godot_StringName *bus) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_bus, 3304788590, void, self, bus)
}
godot_StringName godot_AudioStreamPlayer_get_bus(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_bus, 2002593661, godot_StringName, self)
}
void godot_AudioStreamPlayer_set_autoplay(godot_AudioStreamPlayer *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_autoplay, 2586408642, void, self, &enable)
}
godot_bool godot_AudioStreamPlayer_is_autoplay_enabled(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, is_autoplay_enabled, 36873697, godot_bool, self)
}
void godot_AudioStreamPlayer_set_mix_target(godot_AudioStreamPlayer *self, godot_AudioStreamPlayer_MixTarget mix_target) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_mix_target, 2300306138, void, self, &mix_target)
}
godot_AudioStreamPlayer_MixTarget godot_AudioStreamPlayer_get_mix_target(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_mix_target, 172807476, godot_AudioStreamPlayer_MixTarget, self)
}
void godot_AudioStreamPlayer_set_playing(godot_AudioStreamPlayer *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_playing, 2586408642, void, self, &enable)
}
void godot_AudioStreamPlayer_set_stream_paused(godot_AudioStreamPlayer *self, godot_bool pause) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_stream_paused, 2586408642, void, self, &pause)
}
godot_bool godot_AudioStreamPlayer_get_stream_paused(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_stream_paused, 36873697, godot_bool, self)
}
void godot_AudioStreamPlayer_set_max_polyphony(godot_AudioStreamPlayer *self, godot_int max_polyphony) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_max_polyphony, 1286410249, void, self, &max_polyphony)
}
godot_int godot_AudioStreamPlayer_get_max_polyphony(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_max_polyphony, 3905245786, godot_int, self)
}
godot_bool godot_AudioStreamPlayer_has_stream_playback(godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, has_stream_playback, 2240911060, godot_bool, self)
}
godot_AudioStreamPlayback * godot_AudioStreamPlayer_get_stream_playback(godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_stream_playback, 210135309, godot_AudioStreamPlayback *, self)
}
void godot_AudioStreamPlayer_set_playback_type(godot_AudioStreamPlayer *self, godot_AudioServer_PlaybackType playback_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer, set_playback_type, 725473817, void, self, &playback_type)
}
godot_AudioServer_PlaybackType godot_AudioStreamPlayer_get_playback_type(const godot_AudioStreamPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer, get_playback_type, 4011264623, godot_AudioServer_PlaybackType, self)
}


#ifdef __cplusplus
}
#endif
