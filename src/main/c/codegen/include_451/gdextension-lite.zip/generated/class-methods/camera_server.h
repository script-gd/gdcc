// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_SERVER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_SERVER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
GDEXTENSION_LITE_DECL godot_CameraServer *godot_CameraServer_singleton();

// Methods
GDEXTENSION_LITE_DECL void godot_CameraServer_set_monitoring_feeds(godot_CameraServer *self, godot_bool is_monitoring_feeds);
GDEXTENSION_LITE_DECL godot_bool godot_CameraServer_is_monitoring_feeds(const godot_CameraServer *self);
GDEXTENSION_LITE_DECL godot_CameraFeed * godot_CameraServer_get_feed(godot_CameraServer *self, godot_int index);
GDEXTENSION_LITE_DECL godot_int godot_CameraServer_get_feed_count(godot_CameraServer *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_CameraFeed) godot_CameraServer_feeds(godot_CameraServer *self);
GDEXTENSION_LITE_DECL void godot_CameraServer_add_feed(godot_CameraServer *self, const godot_CameraFeed *feed);
GDEXTENSION_LITE_DECL void godot_CameraServer_remove_feed(godot_CameraServer *self, const godot_CameraFeed *feed);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_SERVER_H__
