// This file was automatically generated
// Do not modify this file
#include "camera_texture.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CameraTexture *godot_new_CameraTexture() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CameraTexture);
}

// Methods
void godot_CameraTexture_set_camera_feed_id(godot_CameraTexture *self, godot_int feed_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraTexture, set_camera_feed_id, 1286410249, void, self, &feed_id)
}
godot_int godot_CameraTexture_get_camera_feed_id(const godot_CameraTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraTexture, get_camera_feed_id, 3905245786, godot_int, self)
}
void godot_CameraTexture_set_which_feed(godot_CameraTexture *self, godot_CameraServer_FeedImage which_feed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraTexture, set_which_feed, 1595299230, void, self, &which_feed)
}
godot_CameraServer_FeedImage godot_CameraTexture_get_which_feed(const godot_CameraTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraTexture, get_which_feed, 91039457, godot_CameraServer_FeedImage, self)
}
void godot_CameraTexture_set_camera_active(godot_CameraTexture *self, godot_bool active) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraTexture, set_camera_active, 2586408642, void, self, &active)
}
godot_bool godot_CameraTexture_get_camera_active(const godot_CameraTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraTexture, get_camera_active, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
