// This file was automatically generated
// Do not modify this file
#include "audio_effect_high_shelf_filter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectHighShelfFilter *godot_new_AudioEffectHighShelfFilter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectHighShelfFilter);
}


#ifdef __cplusplus
}
#endif
