// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PICKER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PICKER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorResourcePicker *godot_new_EditorResourcePicker();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorResourcePicker__set_create_options(godot_EditorResourcePicker *self, const godot_Object *menu_node);
GDEXTENSION_LITE_DECL godot_bool godot_EditorResourcePicker__handle_menu_selected(godot_EditorResourcePicker *self, godot_int id);
GDEXTENSION_LITE_DECL void godot_EditorResourcePicker_set_base_type(godot_EditorResourcePicker *self, const godot_String *base_type);
GDEXTENSION_LITE_DECL godot_String godot_EditorResourcePicker_get_base_type(const godot_EditorResourcePicker *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorResourcePicker_get_allowed_types(const godot_EditorResourcePicker *self);
GDEXTENSION_LITE_DECL void godot_EditorResourcePicker_set_edited_resource(godot_EditorResourcePicker *self, const godot_Resource *resource);
GDEXTENSION_LITE_DECL godot_Resource * godot_EditorResourcePicker_get_edited_resource(godot_EditorResourcePicker *self);
GDEXTENSION_LITE_DECL void godot_EditorResourcePicker_set_toggle_mode(godot_EditorResourcePicker *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorResourcePicker_is_toggle_mode(const godot_EditorResourcePicker *self);
GDEXTENSION_LITE_DECL void godot_EditorResourcePicker_set_toggle_pressed(godot_EditorResourcePicker *self, godot_bool pressed);
GDEXTENSION_LITE_DECL void godot_EditorResourcePicker_set_editable(godot_EditorResourcePicker *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorResourcePicker_is_editable(const godot_EditorResourcePicker *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PICKER_H__
