// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_CAPTURE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_CAPTURE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectCapture *godot_new_AudioEffectCapture();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_AudioEffectCapture_can_get_buffer(const godot_AudioEffectCapture *self, godot_int frames);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_AudioEffectCapture_get_buffer(godot_AudioEffectCapture *self, godot_int frames);
GDEXTENSION_LITE_DECL void godot_AudioEffectCapture_clear_buffer(godot_AudioEffectCapture *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectCapture_set_buffer_length(godot_AudioEffectCapture *self, godot_float buffer_length_seconds);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectCapture_get_buffer_length(godot_AudioEffectCapture *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioEffectCapture_get_frames_available(const godot_AudioEffectCapture *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioEffectCapture_get_discarded_frames(const godot_AudioEffectCapture *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioEffectCapture_get_buffer_length_frames(const godot_AudioEffectCapture *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioEffectCapture_get_pushed_frames(const godot_AudioEffectCapture *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_CAPTURE_H__
