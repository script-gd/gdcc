// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATABLE_BODY2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATABLE_BODY2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimatableBody2D *godot_new_AnimatableBody2D();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimatableBody2D_set_sync_to_physics(godot_AnimatableBody2D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimatableBody2D_is_sync_to_physics_enabled(const godot_AnimatableBody2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATABLE_BODY2D_H__
