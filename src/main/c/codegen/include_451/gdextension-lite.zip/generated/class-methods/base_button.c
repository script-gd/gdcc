// This file was automatically generated
// Do not modify this file
#include "base_button.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BaseButton *godot_new_BaseButton() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BaseButton);
}

// Methods
void godot_BaseButton__pressed(godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, _pressed, 3218959716, void, self)
}
void godot_BaseButton__toggled(godot_BaseButton *self, godot_bool toggled_on) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, _toggled, 2586408642, void, self, &toggled_on)
}
void godot_BaseButton_set_pressed(godot_BaseButton *self, godot_bool pressed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_pressed, 2586408642, void, self, &pressed)
}
godot_bool godot_BaseButton_is_pressed(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, is_pressed, 36873697, godot_bool, self)
}
void godot_BaseButton_set_pressed_no_signal(godot_BaseButton *self, godot_bool pressed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_pressed_no_signal, 2586408642, void, self, &pressed)
}
godot_bool godot_BaseButton_is_hovered(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, is_hovered, 36873697, godot_bool, self)
}
void godot_BaseButton_set_toggle_mode(godot_BaseButton *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_toggle_mode, 2586408642, void, self, &enabled)
}
godot_bool godot_BaseButton_is_toggle_mode(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, is_toggle_mode, 36873697, godot_bool, self)
}
void godot_BaseButton_set_shortcut_in_tooltip(godot_BaseButton *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_shortcut_in_tooltip, 2586408642, void, self, &enabled)
}
godot_bool godot_BaseButton_is_shortcut_in_tooltip_enabled(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, is_shortcut_in_tooltip_enabled, 36873697, godot_bool, self)
}
void godot_BaseButton_set_disabled(godot_BaseButton *self, godot_bool disabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_disabled, 2586408642, void, self, &disabled)
}
godot_bool godot_BaseButton_is_disabled(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, is_disabled, 36873697, godot_bool, self)
}
void godot_BaseButton_set_action_mode(godot_BaseButton *self, godot_BaseButton_ActionMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_action_mode, 1985162088, void, self, &mode)
}
godot_BaseButton_ActionMode godot_BaseButton_get_action_mode(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, get_action_mode, 2589712189, godot_BaseButton_ActionMode, self)
}
void godot_BaseButton_set_button_mask(godot_BaseButton *self, const godot_MouseButtonMask *mask) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_button_mask, 3950145251, void, self, mask)
}
godot_MouseButtonMask godot_BaseButton_get_button_mask(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, get_button_mask, 2512161324, godot_MouseButtonMask, self)
}
godot_BaseButton_DrawMode godot_BaseButton_get_draw_mode(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, get_draw_mode, 2492721305, godot_BaseButton_DrawMode, self)
}
void godot_BaseButton_set_keep_pressed_outside(godot_BaseButton *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_keep_pressed_outside, 2586408642, void, self, &enabled)
}
godot_bool godot_BaseButton_is_keep_pressed_outside(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, is_keep_pressed_outside, 36873697, godot_bool, self)
}
void godot_BaseButton_set_shortcut_feedback(godot_BaseButton *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_shortcut_feedback, 2586408642, void, self, &enabled)
}
godot_bool godot_BaseButton_is_shortcut_feedback(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, is_shortcut_feedback, 36873697, godot_bool, self)
}
void godot_BaseButton_set_shortcut(godot_BaseButton *self, const godot_Shortcut *shortcut) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_shortcut, 857163497, void, self, shortcut)
}
godot_Shortcut * godot_BaseButton_get_shortcut(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, get_shortcut, 3415666916, godot_Shortcut *, self)
}
void godot_BaseButton_set_button_group(godot_BaseButton *self, const godot_ButtonGroup *button_group) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseButton, set_button_group, 1794463739, void, self, button_group)
}
godot_ButtonGroup * godot_BaseButton_get_button_group(const godot_BaseButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseButton, get_button_group, 281644053, godot_ButtonGroup *, self)
}


#ifdef __cplusplus
}
#endif
