// This file was automatically generated
// Do not modify this file
#include "animation_node_animation.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeAnimation *godot_new_AnimationNodeAnimation() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeAnimation);
}

// Methods
void godot_AnimationNodeAnimation_set_animation(godot_AnimationNodeAnimation *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeAnimation, set_animation, 3304788590, void, self, name)
}
godot_StringName godot_AnimationNodeAnimation_get_animation(const godot_AnimationNodeAnimation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeAnimation, get_animation, 2002593661, godot_StringName, self)
}
void godot_AnimationNodeAnimation_set_play_mode(godot_AnimationNodeAnimation *self, godot_AnimationNodeAnimation_PlayMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeAnimation, set_play_mode, 3347718873, void, self, &mode)
}
godot_AnimationNodeAnimation_PlayMode godot_AnimationNodeAnimation_get_play_mode(const godot_AnimationNodeAnimation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeAnimation, get_play_mode, 2061244637, godot_AnimationNodeAnimation_PlayMode, self)
}
void godot_AnimationNodeAnimation_set_advance_on_start(godot_AnimationNodeAnimation *self, godot_bool advance_on_start) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeAnimation, set_advance_on_start, 2586408642, void, self, &advance_on_start)
}
godot_bool godot_AnimationNodeAnimation_is_advance_on_start(const godot_AnimationNodeAnimation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeAnimation, is_advance_on_start, 36873697, godot_bool, self)
}
void godot_AnimationNodeAnimation_set_use_custom_timeline(godot_AnimationNodeAnimation *self, godot_bool use_custom_timeline) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeAnimation, set_use_custom_timeline, 2586408642, void, self, &use_custom_timeline)
}
godot_bool godot_AnimationNodeAnimation_is_using_custom_timeline(const godot_AnimationNodeAnimation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeAnimation, is_using_custom_timeline, 36873697, godot_bool, self)
}
void godot_AnimationNodeAnimation_set_timeline_length(godot_AnimationNodeAnimation *self, godot_float timeline_length) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeAnimation, set_timeline_length, 373806689, void, self, &timeline_length)
}
godot_float godot_AnimationNodeAnimation_get_timeline_length(const godot_AnimationNodeAnimation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeAnimation, get_timeline_length, 1740695150, godot_float, self)
}
void godot_AnimationNodeAnimation_set_stretch_time_scale(godot_AnimationNodeAnimation *self, godot_bool stretch_time_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeAnimation, set_stretch_time_scale, 2586408642, void, self, &stretch_time_scale)
}
godot_bool godot_AnimationNodeAnimation_is_stretching_time_scale(const godot_AnimationNodeAnimation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeAnimation, is_stretching_time_scale, 36873697, godot_bool, self)
}
void godot_AnimationNodeAnimation_set_start_offset(godot_AnimationNodeAnimation *self, godot_float start_offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeAnimation, set_start_offset, 373806689, void, self, &start_offset)
}
godot_float godot_AnimationNodeAnimation_get_start_offset(const godot_AnimationNodeAnimation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeAnimation, get_start_offset, 1740695150, godot_float, self)
}
void godot_AnimationNodeAnimation_set_loop_mode(godot_AnimationNodeAnimation *self, godot_Animation_LoopMode loop_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeAnimation, set_loop_mode, 3155355575, void, self, &loop_mode)
}
godot_Animation_LoopMode godot_AnimationNodeAnimation_get_loop_mode(const godot_AnimationNodeAnimation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeAnimation, get_loop_mode, 1988889481, godot_Animation_LoopMode, self)
}


#ifdef __cplusplus
}
#endif
