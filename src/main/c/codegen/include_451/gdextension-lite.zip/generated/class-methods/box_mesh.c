// This file was automatically generated
// Do not modify this file
#include "box_mesh.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BoxMesh *godot_new_BoxMesh() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BoxMesh);
}

// Methods
void godot_BoxMesh_set_size(godot_BoxMesh *self, const godot_Vector3 *size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoxMesh, set_size, 3460891852, void, self, size)
}
godot_Vector3 godot_BoxMesh_get_size(const godot_BoxMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoxMesh, get_size, 3360562783, godot_Vector3, self)
}
void godot_BoxMesh_set_subdivide_width(godot_BoxMesh *self, godot_int subdivide) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoxMesh, set_subdivide_width, 1286410249, void, self, &subdivide)
}
godot_int godot_BoxMesh_get_subdivide_width(const godot_BoxMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoxMesh, get_subdivide_width, 3905245786, godot_int, self)
}
void godot_BoxMesh_set_subdivide_height(godot_BoxMesh *self, godot_int divisions) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoxMesh, set_subdivide_height, 1286410249, void, self, &divisions)
}
godot_int godot_BoxMesh_get_subdivide_height(const godot_BoxMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoxMesh, get_subdivide_height, 3905245786, godot_int, self)
}
void godot_BoxMesh_set_subdivide_depth(godot_BoxMesh *self, godot_int divisions) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoxMesh, set_subdivide_depth, 1286410249, void, self, &divisions)
}
godot_int godot_BoxMesh_get_subdivide_depth(const godot_BoxMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoxMesh, get_subdivide_depth, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
