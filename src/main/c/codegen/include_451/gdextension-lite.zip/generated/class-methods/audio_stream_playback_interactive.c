// This file was automatically generated
// Do not modify this file
#include "audio_stream_playback_interactive.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
void godot_AudioStreamPlaybackInteractive_switch_to_clip_by_name(godot_AudioStreamPlaybackInteractive *self, const godot_StringName *clip_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaybackInteractive, switch_to_clip_by_name, 3304788590, void, self, clip_name)
}
void godot_AudioStreamPlaybackInteractive_switch_to_clip(godot_AudioStreamPlaybackInteractive *self, godot_int clip_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaybackInteractive, switch_to_clip, 1286410249, void, self, &clip_index)
}
godot_int godot_AudioStreamPlaybackInteractive_get_current_clip_index(const godot_AudioStreamPlaybackInteractive *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaybackInteractive, get_current_clip_index, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
