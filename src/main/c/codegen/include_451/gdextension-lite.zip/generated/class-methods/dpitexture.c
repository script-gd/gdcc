// This file was automatically generated
// Do not modify this file
#include "dpitexture.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_DPITexture *godot_new_DPITexture() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(DPITexture);
}

// Methods
godot_DPITexture * godot_DPITexture_create_from_string(const godot_String *source, godot_float scale, godot_float saturation, const godot_Dictionary *color_map) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DPITexture, create_from_string, 755140520, godot_DPITexture *, NULL, source, &scale, &saturation, color_map)
}
void godot_DPITexture_set_source(godot_DPITexture *self, const godot_String *source) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DPITexture, set_source, 83702148, void, self, source)
}
godot_String godot_DPITexture_get_source(const godot_DPITexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DPITexture, get_source, 201670096, godot_String, self)
}
void godot_DPITexture_set_base_scale(godot_DPITexture *self, godot_float base_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DPITexture, set_base_scale, 373806689, void, self, &base_scale)
}
godot_float godot_DPITexture_get_base_scale(const godot_DPITexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DPITexture, get_base_scale, 1740695150, godot_float, self)
}
void godot_DPITexture_set_saturation(godot_DPITexture *self, godot_float saturation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DPITexture, set_saturation, 373806689, void, self, &saturation)
}
godot_float godot_DPITexture_get_saturation(const godot_DPITexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DPITexture, get_saturation, 1740695150, godot_float, self)
}
void godot_DPITexture_set_color_map(godot_DPITexture *self, const godot_Dictionary *color_map) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DPITexture, set_color_map, 4155329257, void, self, color_map)
}
godot_Dictionary godot_DPITexture_get_color_map(const godot_DPITexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DPITexture, get_color_map, 3102165223, godot_Dictionary, self)
}
void godot_DPITexture_set_size_override(godot_DPITexture *self, const godot_Vector2i *size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DPITexture, set_size_override, 1130785943, void, self, size)
}
godot_RID godot_DPITexture_get_scaled_rid(const godot_DPITexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DPITexture, get_scaled_rid, 2944877500, godot_RID, self)
}


#ifdef __cplusplus
}
#endif
