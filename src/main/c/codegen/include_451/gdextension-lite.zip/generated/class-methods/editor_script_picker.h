// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCRIPT_PICKER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCRIPT_PICKER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorScriptPicker *godot_new_EditorScriptPicker();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorScriptPicker_set_script_owner(godot_EditorScriptPicker *self, const godot_Node *owner_node);
GDEXTENSION_LITE_DECL godot_Node * godot_EditorScriptPicker_get_script_owner(const godot_EditorScriptPicker *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCRIPT_PICKER_H__
