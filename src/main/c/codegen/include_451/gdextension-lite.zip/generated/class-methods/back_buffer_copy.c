// This file was automatically generated
// Do not modify this file
#include "back_buffer_copy.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BackBufferCopy *godot_new_BackBufferCopy() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BackBufferCopy);
}

// Methods
void godot_BackBufferCopy_set_rect(godot_BackBufferCopy *self, const godot_Rect2 *rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BackBufferCopy, set_rect, 2046264180, void, self, rect)
}
godot_Rect2 godot_BackBufferCopy_get_rect(const godot_BackBufferCopy *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BackBufferCopy, get_rect, 1639390495, godot_Rect2, self)
}
void godot_BackBufferCopy_set_copy_mode(godot_BackBufferCopy *self, godot_BackBufferCopy_CopyMode copy_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BackBufferCopy, set_copy_mode, 1713538590, void, self, &copy_mode)
}
godot_BackBufferCopy_CopyMode godot_BackBufferCopy_get_copy_mode(const godot_BackBufferCopy *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BackBufferCopy, get_copy_mode, 3271169440, godot_BackBufferCopy_CopyMode, self)
}


#ifdef __cplusplus
}
#endif
