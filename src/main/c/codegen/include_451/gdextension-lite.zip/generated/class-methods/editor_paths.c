// This file was automatically generated
// Do not modify this file
#include "editor_paths.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorPaths *godot_new_EditorPaths() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorPaths);
}

// Methods
godot_String godot_EditorPaths_get_data_dir(const godot_EditorPaths *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorPaths, get_data_dir, 201670096, godot_String, self)
}
godot_String godot_EditorPaths_get_config_dir(const godot_EditorPaths *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorPaths, get_config_dir, 201670096, godot_String, self)
}
godot_String godot_EditorPaths_get_cache_dir(const godot_EditorPaths *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorPaths, get_cache_dir, 201670096, godot_String, self)
}
godot_bool godot_EditorPaths_is_self_contained(const godot_EditorPaths *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorPaths, is_self_contained, 36873697, godot_bool, self)
}
godot_String godot_EditorPaths_get_self_contained_file(const godot_EditorPaths *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorPaths, get_self_contained_file, 201670096, godot_String, self)
}
godot_String godot_EditorPaths_get_project_settings_dir(const godot_EditorPaths *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorPaths, get_project_settings_dir, 201670096, godot_String, self)
}


#ifdef __cplusplus
}
#endif
