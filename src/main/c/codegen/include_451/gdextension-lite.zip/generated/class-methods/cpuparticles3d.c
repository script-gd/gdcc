// This file was automatically generated
// Do not modify this file
#include "cpuparticles3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CPUParticles3D *godot_new_CPUParticles3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CPUParticles3D);
}

// Methods
void godot_CPUParticles3D_set_emitting(godot_CPUParticles3D *self, godot_bool emitting) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emitting, 2586408642, void, self, &emitting)
}
void godot_CPUParticles3D_set_amount(godot_CPUParticles3D *self, godot_int amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_amount, 1286410249, void, self, &amount)
}
void godot_CPUParticles3D_set_lifetime(godot_CPUParticles3D *self, godot_float secs) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_lifetime, 373806689, void, self, &secs)
}
void godot_CPUParticles3D_set_one_shot(godot_CPUParticles3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_one_shot, 2586408642, void, self, &enable)
}
void godot_CPUParticles3D_set_pre_process_time(godot_CPUParticles3D *self, godot_float secs) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_pre_process_time, 373806689, void, self, &secs)
}
void godot_CPUParticles3D_set_explosiveness_ratio(godot_CPUParticles3D *self, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_explosiveness_ratio, 373806689, void, self, &ratio)
}
void godot_CPUParticles3D_set_randomness_ratio(godot_CPUParticles3D *self, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_randomness_ratio, 373806689, void, self, &ratio)
}
void godot_CPUParticles3D_set_visibility_aabb(godot_CPUParticles3D *self, const godot_AABB *aabb) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_visibility_aabb, 259215842, void, self, aabb)
}
void godot_CPUParticles3D_set_lifetime_randomness(godot_CPUParticles3D *self, godot_float random) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_lifetime_randomness, 373806689, void, self, &random)
}
void godot_CPUParticles3D_set_use_local_coordinates(godot_CPUParticles3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_use_local_coordinates, 2586408642, void, self, &enable)
}
void godot_CPUParticles3D_set_fixed_fps(godot_CPUParticles3D *self, godot_int fps) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_fixed_fps, 1286410249, void, self, &fps)
}
void godot_CPUParticles3D_set_fractional_delta(godot_CPUParticles3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_fractional_delta, 2586408642, void, self, &enable)
}
void godot_CPUParticles3D_set_speed_scale(godot_CPUParticles3D *self, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_speed_scale, 373806689, void, self, &scale)
}
godot_bool godot_CPUParticles3D_is_emitting(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, is_emitting, 36873697, godot_bool, self)
}
godot_int godot_CPUParticles3D_get_amount(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_amount, 3905245786, godot_int, self)
}
godot_float godot_CPUParticles3D_get_lifetime(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_lifetime, 1740695150, godot_float, self)
}
godot_bool godot_CPUParticles3D_get_one_shot(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_one_shot, 36873697, godot_bool, self)
}
godot_float godot_CPUParticles3D_get_pre_process_time(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_pre_process_time, 1740695150, godot_float, self)
}
godot_float godot_CPUParticles3D_get_explosiveness_ratio(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_explosiveness_ratio, 1740695150, godot_float, self)
}
godot_float godot_CPUParticles3D_get_randomness_ratio(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_randomness_ratio, 1740695150, godot_float, self)
}
godot_AABB godot_CPUParticles3D_get_visibility_aabb(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_visibility_aabb, 1068685055, godot_AABB, self)
}
godot_float godot_CPUParticles3D_get_lifetime_randomness(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_lifetime_randomness, 1740695150, godot_float, self)
}
godot_bool godot_CPUParticles3D_get_use_local_coordinates(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_use_local_coordinates, 36873697, godot_bool, self)
}
godot_int godot_CPUParticles3D_get_fixed_fps(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_fixed_fps, 3905245786, godot_int, self)
}
godot_bool godot_CPUParticles3D_get_fractional_delta(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_fractional_delta, 36873697, godot_bool, self)
}
godot_float godot_CPUParticles3D_get_speed_scale(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_speed_scale, 1740695150, godot_float, self)
}
void godot_CPUParticles3D_set_draw_order(godot_CPUParticles3D *self, godot_CPUParticles3D_DrawOrder order) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_draw_order, 1427401774, void, self, &order)
}
godot_CPUParticles3D_DrawOrder godot_CPUParticles3D_get_draw_order(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_draw_order, 1321900776, godot_CPUParticles3D_DrawOrder, self)
}
void godot_CPUParticles3D_set_mesh(godot_CPUParticles3D *self, const godot_Mesh *mesh) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_mesh, 194775623, void, self, mesh)
}
godot_Mesh * godot_CPUParticles3D_get_mesh(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_mesh, 1808005922, godot_Mesh *, self)
}
void godot_CPUParticles3D_set_use_fixed_seed(godot_CPUParticles3D *self, godot_bool use_fixed_seed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_use_fixed_seed, 2586408642, void, self, &use_fixed_seed)
}
godot_bool godot_CPUParticles3D_get_use_fixed_seed(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_use_fixed_seed, 36873697, godot_bool, self)
}
void godot_CPUParticles3D_set_seed(godot_CPUParticles3D *self, godot_int seed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_seed, 1286410249, void, self, &seed)
}
godot_int godot_CPUParticles3D_get_seed(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_seed, 3905245786, godot_int, self)
}
void godot_CPUParticles3D_restart(godot_CPUParticles3D *self, godot_bool keep_seed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, restart, 107499316, void, self, &keep_seed)
}
void godot_CPUParticles3D_request_particles_process(godot_CPUParticles3D *self, godot_float process_time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, request_particles_process, 373806689, void, self, &process_time)
}
godot_AABB godot_CPUParticles3D_capture_aabb(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, capture_aabb, 1068685055, godot_AABB, self)
}
void godot_CPUParticles3D_set_direction(godot_CPUParticles3D *self, const godot_Vector3 *direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_direction, 3460891852, void, self, direction)
}
godot_Vector3 godot_CPUParticles3D_get_direction(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_direction, 3360562783, godot_Vector3, self)
}
void godot_CPUParticles3D_set_spread(godot_CPUParticles3D *self, godot_float degrees) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_spread, 373806689, void, self, &degrees)
}
godot_float godot_CPUParticles3D_get_spread(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_spread, 1740695150, godot_float, self)
}
void godot_CPUParticles3D_set_flatness(godot_CPUParticles3D *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_flatness, 373806689, void, self, &amount)
}
godot_float godot_CPUParticles3D_get_flatness(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_flatness, 1740695150, godot_float, self)
}
void godot_CPUParticles3D_set_param_min(godot_CPUParticles3D *self, godot_CPUParticles3D_Parameter param, godot_float value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_param_min, 557936109, void, self, &param, &value)
}
godot_float godot_CPUParticles3D_get_param_min(const godot_CPUParticles3D *self, godot_CPUParticles3D_Parameter param) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_param_min, 597646162, godot_float, self, &param)
}
void godot_CPUParticles3D_set_param_max(godot_CPUParticles3D *self, godot_CPUParticles3D_Parameter param, godot_float value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_param_max, 557936109, void, self, &param, &value)
}
godot_float godot_CPUParticles3D_get_param_max(const godot_CPUParticles3D *self, godot_CPUParticles3D_Parameter param) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_param_max, 597646162, godot_float, self, &param)
}
void godot_CPUParticles3D_set_param_curve(godot_CPUParticles3D *self, godot_CPUParticles3D_Parameter param, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_param_curve, 4044142537, void, self, &param, curve)
}
godot_Curve * godot_CPUParticles3D_get_param_curve(const godot_CPUParticles3D *self, godot_CPUParticles3D_Parameter param) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_param_curve, 4132790277, godot_Curve *, self, &param)
}
void godot_CPUParticles3D_set_color(godot_CPUParticles3D *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_color, 2920490490, void, self, color)
}
godot_Color godot_CPUParticles3D_get_color(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_color, 3444240500, godot_Color, self)
}
void godot_CPUParticles3D_set_color_ramp(godot_CPUParticles3D *self, const godot_Gradient *ramp) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_color_ramp, 2756054477, void, self, ramp)
}
godot_Gradient * godot_CPUParticles3D_get_color_ramp(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_color_ramp, 132272999, godot_Gradient *, self)
}
void godot_CPUParticles3D_set_color_initial_ramp(godot_CPUParticles3D *self, const godot_Gradient *ramp) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_color_initial_ramp, 2756054477, void, self, ramp)
}
godot_Gradient * godot_CPUParticles3D_get_color_initial_ramp(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_color_initial_ramp, 132272999, godot_Gradient *, self)
}
void godot_CPUParticles3D_set_particle_flag(godot_CPUParticles3D *self, godot_CPUParticles3D_ParticleFlags particle_flag, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_particle_flag, 3515406498, void, self, &particle_flag, &enable)
}
godot_bool godot_CPUParticles3D_get_particle_flag(const godot_CPUParticles3D *self, godot_CPUParticles3D_ParticleFlags particle_flag) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_particle_flag, 2845201987, godot_bool, self, &particle_flag)
}
void godot_CPUParticles3D_set_emission_shape(godot_CPUParticles3D *self, godot_CPUParticles3D_EmissionShape shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_shape, 491823814, void, self, &shape)
}
godot_CPUParticles3D_EmissionShape godot_CPUParticles3D_get_emission_shape(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_shape, 2961454842, godot_CPUParticles3D_EmissionShape, self)
}
void godot_CPUParticles3D_set_emission_sphere_radius(godot_CPUParticles3D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_sphere_radius, 373806689, void, self, &radius)
}
godot_float godot_CPUParticles3D_get_emission_sphere_radius(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_sphere_radius, 1740695150, godot_float, self)
}
void godot_CPUParticles3D_set_emission_box_extents(godot_CPUParticles3D *self, const godot_Vector3 *extents) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_box_extents, 3460891852, void, self, extents)
}
godot_Vector3 godot_CPUParticles3D_get_emission_box_extents(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_box_extents, 3360562783, godot_Vector3, self)
}
void godot_CPUParticles3D_set_emission_points(godot_CPUParticles3D *self, const godot_PackedVector3Array *array) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_points, 334873810, void, self, array)
}
godot_PackedVector3Array godot_CPUParticles3D_get_emission_points(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_points, 497664490, godot_PackedVector3Array, self)
}
void godot_CPUParticles3D_set_emission_normals(godot_CPUParticles3D *self, const godot_PackedVector3Array *array) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_normals, 334873810, void, self, array)
}
godot_PackedVector3Array godot_CPUParticles3D_get_emission_normals(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_normals, 497664490, godot_PackedVector3Array, self)
}
void godot_CPUParticles3D_set_emission_colors(godot_CPUParticles3D *self, const godot_PackedColorArray *array) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_colors, 3546319833, void, self, array)
}
godot_PackedColorArray godot_CPUParticles3D_get_emission_colors(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_colors, 1392750486, godot_PackedColorArray, self)
}
void godot_CPUParticles3D_set_emission_ring_axis(godot_CPUParticles3D *self, const godot_Vector3 *axis) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_ring_axis, 3460891852, void, self, axis)
}
godot_Vector3 godot_CPUParticles3D_get_emission_ring_axis(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_ring_axis, 3360562783, godot_Vector3, self)
}
void godot_CPUParticles3D_set_emission_ring_height(godot_CPUParticles3D *self, godot_float height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_ring_height, 373806689, void, self, &height)
}
godot_float godot_CPUParticles3D_get_emission_ring_height(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_ring_height, 1740695150, godot_float, self)
}
void godot_CPUParticles3D_set_emission_ring_radius(godot_CPUParticles3D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_ring_radius, 373806689, void, self, &radius)
}
godot_float godot_CPUParticles3D_get_emission_ring_radius(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_ring_radius, 1740695150, godot_float, self)
}
void godot_CPUParticles3D_set_emission_ring_inner_radius(godot_CPUParticles3D *self, godot_float inner_radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_ring_inner_radius, 373806689, void, self, &inner_radius)
}
godot_float godot_CPUParticles3D_get_emission_ring_inner_radius(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_ring_inner_radius, 1740695150, godot_float, self)
}
void godot_CPUParticles3D_set_emission_ring_cone_angle(godot_CPUParticles3D *self, godot_float cone_angle) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_emission_ring_cone_angle, 373806689, void, self, &cone_angle)
}
godot_float godot_CPUParticles3D_get_emission_ring_cone_angle(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_emission_ring_cone_angle, 1740695150, godot_float, self)
}
godot_Vector3 godot_CPUParticles3D_get_gravity(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_gravity, 3360562783, godot_Vector3, self)
}
void godot_CPUParticles3D_set_gravity(godot_CPUParticles3D *self, const godot_Vector3 *accel_vec) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_gravity, 3460891852, void, self, accel_vec)
}
godot_bool godot_CPUParticles3D_get_split_scale(godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_split_scale, 2240911060, godot_bool, self)
}
void godot_CPUParticles3D_set_split_scale(godot_CPUParticles3D *self, godot_bool split_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_split_scale, 2586408642, void, self, &split_scale)
}
godot_Curve * godot_CPUParticles3D_get_scale_curve_x(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_scale_curve_x, 2460114913, godot_Curve *, self)
}
void godot_CPUParticles3D_set_scale_curve_x(godot_CPUParticles3D *self, const godot_Curve *scale_curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_scale_curve_x, 270443179, void, self, scale_curve)
}
godot_Curve * godot_CPUParticles3D_get_scale_curve_y(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_scale_curve_y, 2460114913, godot_Curve *, self)
}
void godot_CPUParticles3D_set_scale_curve_y(godot_CPUParticles3D *self, const godot_Curve *scale_curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_scale_curve_y, 270443179, void, self, scale_curve)
}
godot_Curve * godot_CPUParticles3D_get_scale_curve_z(const godot_CPUParticles3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles3D, get_scale_curve_z, 2460114913, godot_Curve *, self)
}
void godot_CPUParticles3D_set_scale_curve_z(godot_CPUParticles3D *self, const godot_Curve *scale_curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, set_scale_curve_z, 270443179, void, self, scale_curve)
}
void godot_CPUParticles3D_convert_from_particles(godot_CPUParticles3D *self, const godot_Node *particles) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles3D, convert_from_particles, 1078189570, void, self, particles)
}


#ifdef __cplusplus
}
#endif
