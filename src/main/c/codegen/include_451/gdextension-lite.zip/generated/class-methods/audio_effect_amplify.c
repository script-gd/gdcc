// This file was automatically generated
// Do not modify this file
#include "audio_effect_amplify.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectAmplify *godot_new_AudioEffectAmplify() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectAmplify);
}

// Methods
void godot_AudioEffectAmplify_set_volume_db(godot_AudioEffectAmplify *self, godot_float volume) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectAmplify, set_volume_db, 373806689, void, self, &volume)
}
godot_float godot_AudioEffectAmplify_get_volume_db(const godot_AudioEffectAmplify *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectAmplify, get_volume_db, 1740695150, godot_float, self)
}
void godot_AudioEffectAmplify_set_volume_linear(godot_AudioEffectAmplify *self, godot_float volume) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectAmplify, set_volume_linear, 373806689, void, self, &volume)
}
godot_float godot_AudioEffectAmplify_get_volume_linear(const godot_AudioEffectAmplify *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectAmplify, get_volume_linear, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
