// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Curve3D *godot_new_Curve3D();

// Methods
GDEXTENSION_LITE_DECL godot_int godot_Curve3D_get_point_count(const godot_Curve3D *self);
GDEXTENSION_LITE_DECL void godot_Curve3D_set_point_count(godot_Curve3D *self, godot_int count);
GDEXTENSION_LITE_DECL void godot_Curve3D_add_point(godot_Curve3D *self, const godot_Vector3 *position, const godot_Vector3 *in, const godot_Vector3 *out, godot_int index);
GDEXTENSION_LITE_DECL void godot_Curve3D_set_point_position(godot_Curve3D *self, godot_int idx, const godot_Vector3 *position);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Curve3D_get_point_position(const godot_Curve3D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve3D_set_point_tilt(godot_Curve3D *self, godot_int idx, godot_float tilt);
GDEXTENSION_LITE_DECL godot_float godot_Curve3D_get_point_tilt(const godot_Curve3D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve3D_set_point_in(godot_Curve3D *self, godot_int idx, const godot_Vector3 *position);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Curve3D_get_point_in(const godot_Curve3D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve3D_set_point_out(godot_Curve3D *self, godot_int idx, const godot_Vector3 *position);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Curve3D_get_point_out(const godot_Curve3D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve3D_remove_point(godot_Curve3D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve3D_clear_points(godot_Curve3D *self);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Curve3D_sample(const godot_Curve3D *self, godot_int idx, godot_float t);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Curve3D_samplef(const godot_Curve3D *self, godot_float fofs);
GDEXTENSION_LITE_DECL void godot_Curve3D_set_closed(godot_Curve3D *self, godot_bool closed);
GDEXTENSION_LITE_DECL godot_bool godot_Curve3D_is_closed(const godot_Curve3D *self);
GDEXTENSION_LITE_DECL void godot_Curve3D_set_bake_interval(godot_Curve3D *self, godot_float distance);
GDEXTENSION_LITE_DECL godot_float godot_Curve3D_get_bake_interval(const godot_Curve3D *self);
GDEXTENSION_LITE_DECL void godot_Curve3D_set_up_vector_enabled(godot_Curve3D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Curve3D_is_up_vector_enabled(const godot_Curve3D *self);
GDEXTENSION_LITE_DECL godot_float godot_Curve3D_get_baked_length(const godot_Curve3D *self);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Curve3D_sample_baked(const godot_Curve3D *self, godot_float offset, godot_bool cubic);
GDEXTENSION_LITE_DECL godot_Transform3D godot_Curve3D_sample_baked_with_rotation(const godot_Curve3D *self, godot_float offset, godot_bool cubic, godot_bool apply_tilt);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Curve3D_sample_baked_up_vector(const godot_Curve3D *self, godot_float offset, godot_bool apply_tilt);
GDEXTENSION_LITE_DECL godot_PackedVector3Array godot_Curve3D_get_baked_points(const godot_Curve3D *self);
GDEXTENSION_LITE_DECL godot_PackedFloat32Array godot_Curve3D_get_baked_tilts(const godot_Curve3D *self);
GDEXTENSION_LITE_DECL godot_PackedVector3Array godot_Curve3D_get_baked_up_vectors(const godot_Curve3D *self);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Curve3D_get_closest_point(const godot_Curve3D *self, const godot_Vector3 *to_point);
GDEXTENSION_LITE_DECL godot_float godot_Curve3D_get_closest_offset(const godot_Curve3D *self, const godot_Vector3 *to_point);
GDEXTENSION_LITE_DECL godot_PackedVector3Array godot_Curve3D_tessellate(const godot_Curve3D *self, godot_int max_stages, godot_float tolerance_degrees);
GDEXTENSION_LITE_DECL godot_PackedVector3Array godot_Curve3D_tessellate_even_length(const godot_Curve3D *self, godot_int max_stages, godot_float tolerance_length);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE3D_H__
