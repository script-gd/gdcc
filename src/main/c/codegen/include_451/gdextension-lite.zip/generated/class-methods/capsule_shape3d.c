// This file was automatically generated
// Do not modify this file
#include "capsule_shape3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CapsuleShape3D *godot_new_CapsuleShape3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CapsuleShape3D);
}

// Methods
void godot_CapsuleShape3D_set_radius(godot_CapsuleShape3D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleShape3D, set_radius, 373806689, void, self, &radius)
}
godot_float godot_CapsuleShape3D_get_radius(const godot_CapsuleShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleShape3D, get_radius, 1740695150, godot_float, self)
}
void godot_CapsuleShape3D_set_height(godot_CapsuleShape3D *self, godot_float height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleShape3D, set_height, 373806689, void, self, &height)
}
godot_float godot_CapsuleShape3D_get_height(const godot_CapsuleShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleShape3D, get_height, 1740695150, godot_float, self)
}
void godot_CapsuleShape3D_set_mid_height(godot_CapsuleShape3D *self, godot_float mid_height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleShape3D, set_mid_height, 373806689, void, self, &mid_height)
}
godot_float godot_CapsuleShape3D_get_mid_height(const godot_CapsuleShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleShape3D, get_mid_height, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
