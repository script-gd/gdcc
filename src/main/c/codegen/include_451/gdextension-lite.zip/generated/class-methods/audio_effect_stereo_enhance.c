// This file was automatically generated
// Do not modify this file
#include "audio_effect_stereo_enhance.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectStereoEnhance *godot_new_AudioEffectStereoEnhance() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectStereoEnhance);
}

// Methods
void godot_AudioEffectStereoEnhance_set_pan_pullout(godot_AudioEffectStereoEnhance *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectStereoEnhance, set_pan_pullout, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectStereoEnhance_get_pan_pullout(const godot_AudioEffectStereoEnhance *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectStereoEnhance, get_pan_pullout, 1740695150, godot_float, self)
}
void godot_AudioEffectStereoEnhance_set_time_pullout(godot_AudioEffectStereoEnhance *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectStereoEnhance, set_time_pullout, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectStereoEnhance_get_time_pullout(const godot_AudioEffectStereoEnhance *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectStereoEnhance, get_time_pullout, 1740695150, godot_float, self)
}
void godot_AudioEffectStereoEnhance_set_surround(godot_AudioEffectStereoEnhance *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectStereoEnhance, set_surround, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectStereoEnhance_get_surround(const godot_AudioEffectStereoEnhance *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectStereoEnhance, get_surround, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
