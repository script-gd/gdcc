// This file was automatically generated
// Do not modify this file
#include "animation_node_transition.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeTransition *godot_new_AnimationNodeTransition() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeTransition);
}

// Methods
void godot_AnimationNodeTransition_set_input_count(godot_AnimationNodeTransition *self, godot_int input_count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeTransition, set_input_count, 1286410249, void, self, &input_count)
}
void godot_AnimationNodeTransition_set_input_as_auto_advance(godot_AnimationNodeTransition *self, godot_int input, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeTransition, set_input_as_auto_advance, 300928843, void, self, &input, &enable)
}
godot_bool godot_AnimationNodeTransition_is_input_set_as_auto_advance(const godot_AnimationNodeTransition *self, godot_int input) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeTransition, is_input_set_as_auto_advance, 1116898809, godot_bool, self, &input)
}
void godot_AnimationNodeTransition_set_input_break_loop_at_end(godot_AnimationNodeTransition *self, godot_int input, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeTransition, set_input_break_loop_at_end, 300928843, void, self, &input, &enable)
}
godot_bool godot_AnimationNodeTransition_is_input_loop_broken_at_end(const godot_AnimationNodeTransition *self, godot_int input) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeTransition, is_input_loop_broken_at_end, 1116898809, godot_bool, self, &input)
}
void godot_AnimationNodeTransition_set_input_reset(godot_AnimationNodeTransition *self, godot_int input, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeTransition, set_input_reset, 300928843, void, self, &input, &enable)
}
godot_bool godot_AnimationNodeTransition_is_input_reset(const godot_AnimationNodeTransition *self, godot_int input) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeTransition, is_input_reset, 1116898809, godot_bool, self, &input)
}
void godot_AnimationNodeTransition_set_xfade_time(godot_AnimationNodeTransition *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeTransition, set_xfade_time, 373806689, void, self, &time)
}
godot_float godot_AnimationNodeTransition_get_xfade_time(const godot_AnimationNodeTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeTransition, get_xfade_time, 1740695150, godot_float, self)
}
void godot_AnimationNodeTransition_set_xfade_curve(godot_AnimationNodeTransition *self, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeTransition, set_xfade_curve, 270443179, void, self, curve)
}
godot_Curve * godot_AnimationNodeTransition_get_xfade_curve(const godot_AnimationNodeTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeTransition, get_xfade_curve, 2460114913, godot_Curve *, self)
}
void godot_AnimationNodeTransition_set_allow_transition_to_self(godot_AnimationNodeTransition *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeTransition, set_allow_transition_to_self, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeTransition_is_allow_transition_to_self(const godot_AnimationNodeTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeTransition, is_allow_transition_to_self, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
