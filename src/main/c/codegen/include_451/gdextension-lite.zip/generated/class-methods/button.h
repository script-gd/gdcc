// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BUTTON_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BUTTON_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Button *godot_new_Button();

// Methods
GDEXTENSION_LITE_DECL void godot_Button_set_text(godot_Button *self, const godot_String *text);
GDEXTENSION_LITE_DECL godot_String godot_Button_get_text(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_text_overrun_behavior(godot_Button *self, godot_TextServer_OverrunBehavior overrun_behavior);
GDEXTENSION_LITE_DECL godot_TextServer_OverrunBehavior godot_Button_get_text_overrun_behavior(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_autowrap_mode(godot_Button *self, godot_TextServer_AutowrapMode autowrap_mode);
GDEXTENSION_LITE_DECL godot_TextServer_AutowrapMode godot_Button_get_autowrap_mode(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_autowrap_trim_flags(godot_Button *self, const godot_TextServer_LineBreakFlag *autowrap_trim_flags);
GDEXTENSION_LITE_DECL godot_TextServer_LineBreakFlag godot_Button_get_autowrap_trim_flags(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_text_direction(godot_Button *self, godot_Control_TextDirection direction);
GDEXTENSION_LITE_DECL godot_Control_TextDirection godot_Button_get_text_direction(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_language(godot_Button *self, const godot_String *language);
GDEXTENSION_LITE_DECL godot_String godot_Button_get_language(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_button_icon(godot_Button *self, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_Button_get_button_icon(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_flat(godot_Button *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Button_is_flat(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_clip_text(godot_Button *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Button_get_clip_text(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_text_alignment(godot_Button *self, godot_HorizontalAlignment alignment);
GDEXTENSION_LITE_DECL godot_HorizontalAlignment godot_Button_get_text_alignment(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_icon_alignment(godot_Button *self, godot_HorizontalAlignment icon_alignment);
GDEXTENSION_LITE_DECL godot_HorizontalAlignment godot_Button_get_icon_alignment(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_vertical_icon_alignment(godot_Button *self, godot_VerticalAlignment vertical_icon_alignment);
GDEXTENSION_LITE_DECL godot_VerticalAlignment godot_Button_get_vertical_icon_alignment(const godot_Button *self);
GDEXTENSION_LITE_DECL void godot_Button_set_expand_icon(godot_Button *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Button_is_expand_icon(const godot_Button *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BUTTON_H__
