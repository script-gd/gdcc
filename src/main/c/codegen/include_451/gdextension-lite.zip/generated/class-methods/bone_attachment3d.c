// This file was automatically generated
// Do not modify this file
#include "bone_attachment3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BoneAttachment3D *godot_new_BoneAttachment3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BoneAttachment3D);
}

// Methods
godot_Skeleton3D * godot_BoneAttachment3D_get_skeleton(godot_BoneAttachment3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneAttachment3D, get_skeleton, 1814733083, godot_Skeleton3D *, self)
}
void godot_BoneAttachment3D_set_bone_name(godot_BoneAttachment3D *self, const godot_String *bone_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneAttachment3D, set_bone_name, 83702148, void, self, bone_name)
}
godot_String godot_BoneAttachment3D_get_bone_name(const godot_BoneAttachment3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneAttachment3D, get_bone_name, 201670096, godot_String, self)
}
void godot_BoneAttachment3D_set_bone_idx(godot_BoneAttachment3D *self, godot_int bone_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneAttachment3D, set_bone_idx, 1286410249, void, self, &bone_idx)
}
godot_int godot_BoneAttachment3D_get_bone_idx(const godot_BoneAttachment3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneAttachment3D, get_bone_idx, 3905245786, godot_int, self)
}
void godot_BoneAttachment3D_on_skeleton_update(godot_BoneAttachment3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneAttachment3D, on_skeleton_update, 3218959716, void, self)
}
void godot_BoneAttachment3D_set_override_pose(godot_BoneAttachment3D *self, godot_bool override_pose) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneAttachment3D, set_override_pose, 2586408642, void, self, &override_pose)
}
godot_bool godot_BoneAttachment3D_get_override_pose(const godot_BoneAttachment3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneAttachment3D, get_override_pose, 36873697, godot_bool, self)
}
void godot_BoneAttachment3D_set_use_external_skeleton(godot_BoneAttachment3D *self, godot_bool use_external_skeleton) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneAttachment3D, set_use_external_skeleton, 2586408642, void, self, &use_external_skeleton)
}
godot_bool godot_BoneAttachment3D_get_use_external_skeleton(const godot_BoneAttachment3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneAttachment3D, get_use_external_skeleton, 36873697, godot_bool, self)
}
void godot_BoneAttachment3D_set_external_skeleton(godot_BoneAttachment3D *self, const godot_NodePath *external_skeleton) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneAttachment3D, set_external_skeleton, 1348162250, void, self, external_skeleton)
}
godot_NodePath godot_BoneAttachment3D_get_external_skeleton(const godot_BoneAttachment3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneAttachment3D, get_external_skeleton, 4075236667, godot_NodePath, self)
}


#ifdef __cplusplus
}
#endif
