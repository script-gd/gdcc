// This file was automatically generated
// Do not modify this file
#include "audio_effect_panner.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectPanner *godot_new_AudioEffectPanner() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectPanner);
}

// Methods
void godot_AudioEffectPanner_set_pan(godot_AudioEffectPanner *self, godot_float cpanume) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPanner, set_pan, 373806689, void, self, &cpanume)
}
godot_float godot_AudioEffectPanner_get_pan(const godot_AudioEffectPanner *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPanner, get_pan, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
