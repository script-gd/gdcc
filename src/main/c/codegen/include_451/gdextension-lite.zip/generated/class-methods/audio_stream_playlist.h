// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYLIST_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYLIST_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamPlaylist *godot_new_AudioStreamPlaylist();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaylist_set_stream_count(godot_AudioStreamPlaylist *self, godot_int stream_count);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPlaylist_get_stream_count(const godot_AudioStreamPlaylist *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlaylist_get_bpm(const godot_AudioStreamPlaylist *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaylist_set_list_stream(godot_AudioStreamPlaylist *self, godot_int stream_index, const godot_AudioStream *audio_stream);
GDEXTENSION_LITE_DECL godot_AudioStream * godot_AudioStreamPlaylist_get_list_stream(const godot_AudioStreamPlaylist *self, godot_int stream_index);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaylist_set_shuffle(godot_AudioStreamPlaylist *self, godot_bool shuffle);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlaylist_get_shuffle(const godot_AudioStreamPlaylist *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaylist_set_fade_time(godot_AudioStreamPlaylist *self, godot_float dec);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlaylist_get_fade_time(const godot_AudioStreamPlaylist *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaylist_set_loop(godot_AudioStreamPlaylist *self, godot_bool loop);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlaylist_has_loop(const godot_AudioStreamPlaylist *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYLIST_H__
