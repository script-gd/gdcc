// This file was automatically generated
// Do not modify this file
#include "audio_effect_spectrum_analyzer_instance.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_Vector2 godot_AudioEffectSpectrumAnalyzerInstance_get_magnitude_for_frequency_range(const godot_AudioEffectSpectrumAnalyzerInstance *self, godot_float from_hz, godot_float to_hz, godot_AudioEffectSpectrumAnalyzerInstance_MagnitudeMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectSpectrumAnalyzerInstance, get_magnitude_for_frequency_range, 797993915, godot_Vector2, self, &from_hz, &to_hz, &mode)
}


#ifdef __cplusplus
}
#endif
