// This file was automatically generated
// Do not modify this file
#include "editor_export_platform_extension.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlatformExtension *godot_new_EditorExportPlatformExtension() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlatformExtension);
}

// Methods
godot_PackedStringArray godot_EditorExportPlatformExtension__get_preset_features(const godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_preset_features, 1387456631, godot_PackedStringArray, self, preset)
}
godot_bool godot_EditorExportPlatformExtension__is_executable(const godot_EditorExportPlatformExtension *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _is_executable, 3927539163, godot_bool, self, path)
}
godot_TypedArray(godot_Dictionary) godot_EditorExportPlatformExtension__get_export_options(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_export_options, 3995934104, godot_TypedArray(godot_Dictionary), self)
}
godot_bool godot_EditorExportPlatformExtension__should_update_export_options(godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _should_update_export_options, 2240911060, godot_bool, self)
}
godot_bool godot_EditorExportPlatformExtension__get_export_option_visibility(const godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, const godot_String *option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_export_option_visibility, 969350244, godot_bool, self, preset, option)
}
godot_String godot_EditorExportPlatformExtension__get_export_option_warning(const godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, const godot_StringName *option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_export_option_warning, 805886795, godot_String, self, preset, option)
}
godot_String godot_EditorExportPlatformExtension__get_os_name(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_os_name, 201670096, godot_String, self)
}
godot_String godot_EditorExportPlatformExtension__get_name(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_name, 201670096, godot_String, self)
}
godot_Texture2D * godot_EditorExportPlatformExtension__get_logo(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_logo, 3635182373, godot_Texture2D *, self)
}
godot_bool godot_EditorExportPlatformExtension__poll_export(godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _poll_export, 2240911060, godot_bool, self)
}
godot_int godot_EditorExportPlatformExtension__get_options_count(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_options_count, 3905245786, godot_int, self)
}
godot_String godot_EditorExportPlatformExtension__get_options_tooltip(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_options_tooltip, 201670096, godot_String, self)
}
godot_Texture2D * godot_EditorExportPlatformExtension__get_option_icon(const godot_EditorExportPlatformExtension *self, godot_int device) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_option_icon, 3536238170, godot_Texture2D *, self, &device)
}
godot_String godot_EditorExportPlatformExtension__get_option_label(const godot_EditorExportPlatformExtension *self, godot_int device) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_option_label, 844755477, godot_String, self, &device)
}
godot_String godot_EditorExportPlatformExtension__get_option_tooltip(const godot_EditorExportPlatformExtension *self, godot_int device) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_option_tooltip, 844755477, godot_String, self, &device)
}
godot_String godot_EditorExportPlatformExtension__get_device_architecture(const godot_EditorExportPlatformExtension *self, godot_int device) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_device_architecture, 844755477, godot_String, self, &device)
}
void godot_EditorExportPlatformExtension__cleanup(godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlatformExtension, _cleanup, 3218959716, void, self)
}
godot_Error godot_EditorExportPlatformExtension__run(godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, godot_int device, const godot_EditorExportPlatform_DebugFlags *debug_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _run, 1726914928, godot_Error, self, preset, &device, debug_flags)
}
godot_Texture2D * godot_EditorExportPlatformExtension__get_run_icon(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_run_icon, 3635182373, godot_Texture2D *, self)
}
godot_bool godot_EditorExportPlatformExtension__can_export(const godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _can_export, 493961987, godot_bool, self, preset, &debug)
}
godot_bool godot_EditorExportPlatformExtension__has_valid_export_configuration(const godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _has_valid_export_configuration, 493961987, godot_bool, self, preset, &debug)
}
godot_bool godot_EditorExportPlatformExtension__has_valid_project_configuration(const godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _has_valid_project_configuration, 3117166915, godot_bool, self, preset)
}
godot_PackedStringArray godot_EditorExportPlatformExtension__get_binary_extensions(const godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_binary_extensions, 1387456631, godot_PackedStringArray, self, preset)
}
godot_Error godot_EditorExportPlatformExtension__export_project(godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _export_project, 1328957260, godot_Error, self, preset, &debug, path, flags)
}
godot_Error godot_EditorExportPlatformExtension__export_pack(godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _export_pack, 1328957260, godot_Error, self, preset, &debug, path, flags)
}
godot_Error godot_EditorExportPlatformExtension__export_zip(godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _export_zip, 1328957260, godot_Error, self, preset, &debug, path, flags)
}
godot_Error godot_EditorExportPlatformExtension__export_pack_patch(godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_PackedStringArray *patches, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _export_pack_patch, 454765315, godot_Error, self, preset, &debug, path, patches, flags)
}
godot_Error godot_EditorExportPlatformExtension__export_zip_patch(godot_EditorExportPlatformExtension *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_PackedStringArray *patches, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _export_zip_patch, 454765315, godot_Error, self, preset, &debug, path, patches, flags)
}
godot_PackedStringArray godot_EditorExportPlatformExtension__get_platform_features(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_platform_features, 1139954409, godot_PackedStringArray, self)
}
godot_String godot_EditorExportPlatformExtension__get_debug_protocol(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, _get_debug_protocol, 201670096, godot_String, self)
}
void godot_EditorExportPlatformExtension_set_config_error(const godot_EditorExportPlatformExtension *self, const godot_String *error_text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlatformExtension, set_config_error, 3089850668, void, self, error_text)
}
godot_String godot_EditorExportPlatformExtension_get_config_error(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, get_config_error, 201670096, godot_String, self)
}
void godot_EditorExportPlatformExtension_set_config_missing_templates(const godot_EditorExportPlatformExtension *self, godot_bool missing_templates) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlatformExtension, set_config_missing_templates, 1695273946, void, self, &missing_templates)
}
godot_bool godot_EditorExportPlatformExtension_get_config_missing_templates(const godot_EditorExportPlatformExtension *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatformExtension, get_config_missing_templates, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
