// This file was automatically generated
// Do not modify this file
#include "editor_selection.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorSelection *godot_new_EditorSelection() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorSelection);
}

// Methods
void godot_EditorSelection_clear(godot_EditorSelection *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorSelection, clear, 3218959716, void, self)
}
void godot_EditorSelection_add_node(godot_EditorSelection *self, const godot_Node *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorSelection, add_node, 1078189570, void, self, node)
}
void godot_EditorSelection_remove_node(godot_EditorSelection *self, const godot_Node *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorSelection, remove_node, 1078189570, void, self, node)
}
godot_TypedArray(godot_Node) godot_EditorSelection_get_selected_nodes(godot_EditorSelection *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorSelection, get_selected_nodes, 2915620761, godot_TypedArray(godot_Node), self)
}
godot_TypedArray(godot_Node) godot_EditorSelection_get_top_selected_nodes(godot_EditorSelection *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorSelection, get_top_selected_nodes, 2915620761, godot_TypedArray(godot_Node), self)
}
godot_TypedArray(godot_Node) godot_EditorSelection_get_transformable_selected_nodes(godot_EditorSelection *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorSelection, get_transformable_selected_nodes, 2915620761, godot_TypedArray(godot_Node), self)
}


#ifdef __cplusplus
}
#endif
