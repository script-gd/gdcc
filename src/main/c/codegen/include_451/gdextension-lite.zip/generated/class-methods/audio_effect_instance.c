// This file was automatically generated
// Do not modify this file
#include "audio_effect_instance.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectInstance *godot_new_AudioEffectInstance() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectInstance);
}

// Methods
void godot_AudioEffectInstance__process(godot_AudioEffectInstance *self, const void* src_buffer, godot_AudioFrame* dst_buffer, godot_int frame_count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectInstance, _process, 1649997291, void, self, src_buffer, dst_buffer, &frame_count)
}
godot_bool godot_AudioEffectInstance__process_silence(const godot_AudioEffectInstance *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectInstance, _process_silence, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
