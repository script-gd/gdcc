// This file was automatically generated
// Do not modify this file
#include "damped_spring_joint2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_DampedSpringJoint2D *godot_new_DampedSpringJoint2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(DampedSpringJoint2D);
}

// Methods
void godot_DampedSpringJoint2D_set_length(godot_DampedSpringJoint2D *self, godot_float length) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DampedSpringJoint2D, set_length, 373806689, void, self, &length)
}
godot_float godot_DampedSpringJoint2D_get_length(const godot_DampedSpringJoint2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DampedSpringJoint2D, get_length, 1740695150, godot_float, self)
}
void godot_DampedSpringJoint2D_set_rest_length(godot_DampedSpringJoint2D *self, godot_float rest_length) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DampedSpringJoint2D, set_rest_length, 373806689, void, self, &rest_length)
}
godot_float godot_DampedSpringJoint2D_get_rest_length(const godot_DampedSpringJoint2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DampedSpringJoint2D, get_rest_length, 1740695150, godot_float, self)
}
void godot_DampedSpringJoint2D_set_stiffness(godot_DampedSpringJoint2D *self, godot_float stiffness) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DampedSpringJoint2D, set_stiffness, 373806689, void, self, &stiffness)
}
godot_float godot_DampedSpringJoint2D_get_stiffness(const godot_DampedSpringJoint2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DampedSpringJoint2D, get_stiffness, 1740695150, godot_float, self)
}
void godot_DampedSpringJoint2D_set_damping(godot_DampedSpringJoint2D *self, godot_float damping) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DampedSpringJoint2D, set_damping, 373806689, void, self, &damping)
}
godot_float godot_DampedSpringJoint2D_get_damping(const godot_DampedSpringJoint2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DampedSpringJoint2D, get_damping, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
