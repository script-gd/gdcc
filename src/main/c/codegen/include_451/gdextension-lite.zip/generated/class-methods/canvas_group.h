// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_GROUP_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_GROUP_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CanvasGroup *godot_new_CanvasGroup();

// Methods
GDEXTENSION_LITE_DECL void godot_CanvasGroup_set_fit_margin(godot_CanvasGroup *self, godot_float fit_margin);
GDEXTENSION_LITE_DECL godot_float godot_CanvasGroup_get_fit_margin(const godot_CanvasGroup *self);
GDEXTENSION_LITE_DECL void godot_CanvasGroup_set_clear_margin(godot_CanvasGroup *self, godot_float clear_margin);
GDEXTENSION_LITE_DECL godot_float godot_CanvasGroup_get_clear_margin(const godot_CanvasGroup *self);
GDEXTENSION_LITE_DECL void godot_CanvasGroup_set_use_mipmaps(godot_CanvasGroup *self, godot_bool use_mipmaps);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasGroup_is_using_mipmaps(const godot_CanvasGroup *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_GROUP_H__
