// This file was automatically generated
// Do not modify this file
#include "audio_sample.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioSample *godot_new_AudioSample() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioSample);
}


#ifdef __cplusplus
}
#endif
