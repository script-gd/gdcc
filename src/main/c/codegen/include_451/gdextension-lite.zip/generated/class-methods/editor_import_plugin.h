// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_IMPORT_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_IMPORT_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorImportPlugin *godot_new_EditorImportPlugin();

// Methods
GDEXTENSION_LITE_DECL godot_String godot_EditorImportPlugin__get_importer_name(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorImportPlugin__get_visible_name(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_int godot_EditorImportPlugin__get_preset_count(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorImportPlugin__get_preset_name(const godot_EditorImportPlugin *self, godot_int preset_index);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorImportPlugin__get_recognized_extensions(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_EditorImportPlugin__get_import_options(const godot_EditorImportPlugin *self, const godot_String *path, godot_int preset_index);
GDEXTENSION_LITE_DECL godot_String godot_EditorImportPlugin__get_save_extension(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorImportPlugin__get_resource_type(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_float godot_EditorImportPlugin__get_priority(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_int godot_EditorImportPlugin__get_import_order(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_int godot_EditorImportPlugin__get_format_version(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorImportPlugin__get_option_visibility(const godot_EditorImportPlugin *self, const godot_String *path, const godot_StringName *option_name, const godot_Dictionary *options);
GDEXTENSION_LITE_DECL godot_Error godot_EditorImportPlugin__import(const godot_EditorImportPlugin *self, const godot_String *source_file, const godot_String *save_path, const godot_Dictionary *options, const godot_TypedArray(godot_String) *platform_variants, const godot_TypedArray(godot_String) *gen_files);
GDEXTENSION_LITE_DECL godot_bool godot_EditorImportPlugin__can_import_threaded(const godot_EditorImportPlugin *self);
GDEXTENSION_LITE_DECL godot_Error godot_EditorImportPlugin_append_import_external_resource(godot_EditorImportPlugin *self, const godot_String *path, const godot_Dictionary *custom_options, const godot_String *custom_importer, const godot_Variant *generator_parameters);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_IMPORT_PLUGIN_H__
