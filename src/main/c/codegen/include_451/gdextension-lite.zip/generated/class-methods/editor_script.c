// This file was automatically generated
// Do not modify this file
#include "editor_script.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorScript *godot_new_EditorScript() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorScript);
}

// Methods
void godot_EditorScript__run(godot_EditorScript *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScript, _run, 3218959716, void, self)
}
void godot_EditorScript_add_root_node(godot_EditorScript *self, const godot_Node *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScript, add_root_node, 1078189570, void, self, node)
}
godot_Node * godot_EditorScript_get_scene(const godot_EditorScript *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScript, get_scene, 3160264692, godot_Node *, self)
}
godot_EditorInterface * godot_EditorScript_get_editor_interface(const godot_EditorScript *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScript, get_editor_interface, 1976662476, godot_EditorInterface *, self)
}


#ifdef __cplusplus
}
#endif
