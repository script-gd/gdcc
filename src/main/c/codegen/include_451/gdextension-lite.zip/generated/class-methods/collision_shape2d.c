// This file was automatically generated
// Do not modify this file
#include "collision_shape2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CollisionShape2D *godot_new_CollisionShape2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CollisionShape2D);
}

// Methods
void godot_CollisionShape2D_set_shape(godot_CollisionShape2D *self, const godot_Shape2D *shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape2D, set_shape, 771364740, void, self, shape)
}
godot_Shape2D * godot_CollisionShape2D_get_shape(const godot_CollisionShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape2D, get_shape, 522005891, godot_Shape2D *, self)
}
void godot_CollisionShape2D_set_disabled(godot_CollisionShape2D *self, godot_bool disabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape2D, set_disabled, 2586408642, void, self, &disabled)
}
godot_bool godot_CollisionShape2D_is_disabled(const godot_CollisionShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape2D, is_disabled, 36873697, godot_bool, self)
}
void godot_CollisionShape2D_set_one_way_collision(godot_CollisionShape2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape2D, set_one_way_collision, 2586408642, void, self, &enabled)
}
godot_bool godot_CollisionShape2D_is_one_way_collision_enabled(const godot_CollisionShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape2D, is_one_way_collision_enabled, 36873697, godot_bool, self)
}
void godot_CollisionShape2D_set_one_way_collision_margin(godot_CollisionShape2D *self, godot_float margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape2D, set_one_way_collision_margin, 373806689, void, self, &margin)
}
godot_float godot_CollisionShape2D_get_one_way_collision_margin(const godot_CollisionShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape2D, get_one_way_collision_margin, 1740695150, godot_float, self)
}
void godot_CollisionShape2D_set_debug_color(godot_CollisionShape2D *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape2D, set_debug_color, 2920490490, void, self, color)
}
godot_Color godot_CollisionShape2D_get_debug_color(const godot_CollisionShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape2D, get_debug_color, 3444240500, godot_Color, self)
}


#ifdef __cplusplus
}
#endif
