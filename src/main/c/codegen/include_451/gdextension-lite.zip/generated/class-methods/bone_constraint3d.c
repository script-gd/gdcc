// This file was automatically generated
// Do not modify this file
#include "bone_constraint3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BoneConstraint3D *godot_new_BoneConstraint3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BoneConstraint3D);
}

// Methods
void godot_BoneConstraint3D_set_amount(godot_BoneConstraint3D *self, godot_int index, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneConstraint3D, set_amount, 1602489585, void, self, &index, &amount)
}
godot_float godot_BoneConstraint3D_get_amount(const godot_BoneConstraint3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneConstraint3D, get_amount, 2339986948, godot_float, self, &index)
}
void godot_BoneConstraint3D_set_apply_bone_name(godot_BoneConstraint3D *self, godot_int index, const godot_String *bone_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneConstraint3D, set_apply_bone_name, 501894301, void, self, &index, bone_name)
}
godot_String godot_BoneConstraint3D_get_apply_bone_name(const godot_BoneConstraint3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneConstraint3D, get_apply_bone_name, 844755477, godot_String, self, &index)
}
void godot_BoneConstraint3D_set_apply_bone(godot_BoneConstraint3D *self, godot_int index, godot_int bone) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneConstraint3D, set_apply_bone, 3937882851, void, self, &index, &bone)
}
godot_int godot_BoneConstraint3D_get_apply_bone(const godot_BoneConstraint3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneConstraint3D, get_apply_bone, 923996154, godot_int, self, &index)
}
void godot_BoneConstraint3D_set_reference_bone_name(godot_BoneConstraint3D *self, godot_int index, const godot_String *bone_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneConstraint3D, set_reference_bone_name, 501894301, void, self, &index, bone_name)
}
godot_String godot_BoneConstraint3D_get_reference_bone_name(const godot_BoneConstraint3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneConstraint3D, get_reference_bone_name, 844755477, godot_String, self, &index)
}
void godot_BoneConstraint3D_set_reference_bone(godot_BoneConstraint3D *self, godot_int index, godot_int bone) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneConstraint3D, set_reference_bone, 3937882851, void, self, &index, &bone)
}
godot_int godot_BoneConstraint3D_get_reference_bone(const godot_BoneConstraint3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneConstraint3D, get_reference_bone, 923996154, godot_int, self, &index)
}
void godot_BoneConstraint3D_set_setting_count(godot_BoneConstraint3D *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneConstraint3D, set_setting_count, 1286410249, void, self, &count)
}
godot_int godot_BoneConstraint3D_get_setting_count(const godot_BoneConstraint3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneConstraint3D, get_setting_count, 3905245786, godot_int, self)
}
void godot_BoneConstraint3D_clear_setting(godot_BoneConstraint3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneConstraint3D, clear_setting, 3218959716, void, self)
}


#ifdef __cplusplus
}
#endif
