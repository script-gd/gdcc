// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_BLEND_TREE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_BLEND_TREE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeBlendTree *godot_new_AnimationNodeBlendTree();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendTree_add_node(godot_AnimationNodeBlendTree *self, const godot_StringName *name, const godot_AnimationNode *node, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL godot_AnimationNode * godot_AnimationNodeBlendTree_get_node(const godot_AnimationNodeBlendTree *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendTree_remove_node(godot_AnimationNodeBlendTree *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendTree_rename_node(godot_AnimationNodeBlendTree *self, const godot_StringName *name, const godot_StringName *new_name);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeBlendTree_has_node(const godot_AnimationNodeBlendTree *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendTree_connect_node(godot_AnimationNodeBlendTree *self, const godot_StringName *input_node, godot_int input_index, const godot_StringName *output_node);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendTree_disconnect_node(godot_AnimationNodeBlendTree *self, const godot_StringName *input_node, godot_int input_index);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_StringName) godot_AnimationNodeBlendTree_get_node_list(const godot_AnimationNodeBlendTree *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendTree_set_node_position(godot_AnimationNodeBlendTree *self, const godot_StringName *name, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AnimationNodeBlendTree_get_node_position(const godot_AnimationNodeBlendTree *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendTree_set_graph_offset(godot_AnimationNodeBlendTree *self, const godot_Vector2 *offset);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AnimationNodeBlendTree_get_graph_offset(const godot_AnimationNodeBlendTree *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_BLEND_TREE_H__
