// This file was automatically generated
// Do not modify this file
#include "canvas_modulate.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CanvasModulate *godot_new_CanvasModulate() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CanvasModulate);
}

// Methods
void godot_CanvasModulate_set_color(godot_CanvasModulate *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasModulate, set_color, 2920490490, void, self, color)
}
godot_Color godot_CanvasModulate_get_color(const godot_CanvasModulate *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasModulate, get_color, 3444240500, godot_Color, self)
}


#ifdef __cplusplus
}
#endif
