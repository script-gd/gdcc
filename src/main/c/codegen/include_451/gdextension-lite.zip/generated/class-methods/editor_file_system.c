// This file was automatically generated
// Do not modify this file
#include "editor_file_system.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_EditorFileSystemDirectory * godot_EditorFileSystem_get_filesystem(godot_EditorFileSystem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystem, get_filesystem, 842323275, godot_EditorFileSystemDirectory *, self)
}
godot_bool godot_EditorFileSystem_is_scanning(const godot_EditorFileSystem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystem, is_scanning, 36873697, godot_bool, self)
}
godot_float godot_EditorFileSystem_get_scanning_progress(const godot_EditorFileSystem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystem, get_scanning_progress, 1740695150, godot_float, self)
}
void godot_EditorFileSystem_scan(godot_EditorFileSystem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileSystem, scan, 3218959716, void, self)
}
void godot_EditorFileSystem_scan_sources(godot_EditorFileSystem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileSystem, scan_sources, 3218959716, void, self)
}
void godot_EditorFileSystem_update_file(godot_EditorFileSystem *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileSystem, update_file, 83702148, void, self, path)
}
godot_EditorFileSystemDirectory * godot_EditorFileSystem_get_filesystem_path(godot_EditorFileSystem *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystem, get_filesystem_path, 3188521125, godot_EditorFileSystemDirectory *, self, path)
}
godot_String godot_EditorFileSystem_get_file_type(const godot_EditorFileSystem *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystem, get_file_type, 3135753539, godot_String, self, path)
}
void godot_EditorFileSystem_reimport_files(godot_EditorFileSystem *self, const godot_PackedStringArray *files) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileSystem, reimport_files, 4015028928, void, self, files)
}


#ifdef __cplusplus
}
#endif
