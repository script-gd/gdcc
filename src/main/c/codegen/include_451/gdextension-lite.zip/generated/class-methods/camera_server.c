// This file was automatically generated
// Do not modify this file
#include "camera_server.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
godot_CameraServer *godot_CameraServer_singleton() {
	GDEXTENSION_LITE_GET_SINGLETON_IMPL(CameraServer, "CameraServer");
}

// Methods
void godot_CameraServer_set_monitoring_feeds(godot_CameraServer *self, godot_bool is_monitoring_feeds) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraServer, set_monitoring_feeds, 2586408642, void, self, &is_monitoring_feeds)
}
godot_bool godot_CameraServer_is_monitoring_feeds(const godot_CameraServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraServer, is_monitoring_feeds, 36873697, godot_bool, self)
}
godot_CameraFeed * godot_CameraServer_get_feed(godot_CameraServer *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraServer, get_feed, 361927068, godot_CameraFeed *, self, &index)
}
godot_int godot_CameraServer_get_feed_count(godot_CameraServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraServer, get_feed_count, 2455072627, godot_int, self)
}
godot_TypedArray(godot_CameraFeed) godot_CameraServer_feeds(godot_CameraServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraServer, feeds, 2915620761, godot_TypedArray(godot_CameraFeed), self)
}
void godot_CameraServer_add_feed(godot_CameraServer *self, const godot_CameraFeed *feed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraServer, add_feed, 3204782488, void, self, feed)
}
void godot_CameraServer_remove_feed(godot_CameraServer *self, const godot_CameraFeed *feed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraServer, remove_feed, 3204782488, void, self, feed)
}


#ifdef __cplusplus
}
#endif
