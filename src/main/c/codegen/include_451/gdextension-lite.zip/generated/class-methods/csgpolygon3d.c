// This file was automatically generated
// Do not modify this file
#include "csgpolygon3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CSGPolygon3D *godot_new_CSGPolygon3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CSGPolygon3D);
}

// Methods
void godot_CSGPolygon3D_set_polygon(godot_CSGPolygon3D *self, const godot_PackedVector2Array *polygon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_polygon, 1509147220, void, self, polygon)
}
godot_PackedVector2Array godot_CSGPolygon3D_get_polygon(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_polygon, 2961356807, godot_PackedVector2Array, self)
}
void godot_CSGPolygon3D_set_mode(godot_CSGPolygon3D *self, godot_CSGPolygon3D_Mode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_mode, 3158377035, void, self, &mode)
}
godot_CSGPolygon3D_Mode godot_CSGPolygon3D_get_mode(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_mode, 1201612222, godot_CSGPolygon3D_Mode, self)
}
void godot_CSGPolygon3D_set_depth(godot_CSGPolygon3D *self, godot_float depth) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_depth, 373806689, void, self, &depth)
}
godot_float godot_CSGPolygon3D_get_depth(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_depth, 1740695150, godot_float, self)
}
void godot_CSGPolygon3D_set_spin_degrees(godot_CSGPolygon3D *self, godot_float degrees) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_spin_degrees, 373806689, void, self, &degrees)
}
godot_float godot_CSGPolygon3D_get_spin_degrees(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_spin_degrees, 1740695150, godot_float, self)
}
void godot_CSGPolygon3D_set_spin_sides(godot_CSGPolygon3D *self, godot_int spin_sides) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_spin_sides, 1286410249, void, self, &spin_sides)
}
godot_int godot_CSGPolygon3D_get_spin_sides(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_spin_sides, 3905245786, godot_int, self)
}
void godot_CSGPolygon3D_set_path_node(godot_CSGPolygon3D *self, const godot_NodePath *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_node, 1348162250, void, self, path)
}
godot_NodePath godot_CSGPolygon3D_get_path_node(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_path_node, 4075236667, godot_NodePath, self)
}
void godot_CSGPolygon3D_set_path_interval_type(godot_CSGPolygon3D *self, godot_CSGPolygon3D_PathIntervalType interval_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_interval_type, 3744240707, void, self, &interval_type)
}
godot_CSGPolygon3D_PathIntervalType godot_CSGPolygon3D_get_path_interval_type(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_path_interval_type, 3434618397, godot_CSGPolygon3D_PathIntervalType, self)
}
void godot_CSGPolygon3D_set_path_interval(godot_CSGPolygon3D *self, godot_float interval) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_interval, 373806689, void, self, &interval)
}
godot_float godot_CSGPolygon3D_get_path_interval(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_path_interval, 1740695150, godot_float, self)
}
void godot_CSGPolygon3D_set_path_simplify_angle(godot_CSGPolygon3D *self, godot_float degrees) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_simplify_angle, 373806689, void, self, &degrees)
}
godot_float godot_CSGPolygon3D_get_path_simplify_angle(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_path_simplify_angle, 1740695150, godot_float, self)
}
void godot_CSGPolygon3D_set_path_rotation(godot_CSGPolygon3D *self, godot_CSGPolygon3D_PathRotation path_rotation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_rotation, 1412947288, void, self, &path_rotation)
}
godot_CSGPolygon3D_PathRotation godot_CSGPolygon3D_get_path_rotation(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_path_rotation, 647219346, godot_CSGPolygon3D_PathRotation, self)
}
void godot_CSGPolygon3D_set_path_rotation_accurate(godot_CSGPolygon3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_rotation_accurate, 2586408642, void, self, &enable)
}
godot_bool godot_CSGPolygon3D_get_path_rotation_accurate(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_path_rotation_accurate, 36873697, godot_bool, self)
}
void godot_CSGPolygon3D_set_path_local(godot_CSGPolygon3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_local, 2586408642, void, self, &enable)
}
godot_bool godot_CSGPolygon3D_is_path_local(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, is_path_local, 36873697, godot_bool, self)
}
void godot_CSGPolygon3D_set_path_continuous_u(godot_CSGPolygon3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_continuous_u, 2586408642, void, self, &enable)
}
godot_bool godot_CSGPolygon3D_is_path_continuous_u(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, is_path_continuous_u, 36873697, godot_bool, self)
}
void godot_CSGPolygon3D_set_path_u_distance(godot_CSGPolygon3D *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_u_distance, 373806689, void, self, &distance)
}
godot_float godot_CSGPolygon3D_get_path_u_distance(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_path_u_distance, 1740695150, godot_float, self)
}
void godot_CSGPolygon3D_set_path_joined(godot_CSGPolygon3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_path_joined, 2586408642, void, self, &enable)
}
godot_bool godot_CSGPolygon3D_is_path_joined(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, is_path_joined, 36873697, godot_bool, self)
}
void godot_CSGPolygon3D_set_material(godot_CSGPolygon3D *self, const godot_Material *material) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_material, 2757459619, void, self, material)
}
godot_Material * godot_CSGPolygon3D_get_material(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_material, 5934680, godot_Material *, self)
}
void godot_CSGPolygon3D_set_smooth_faces(godot_CSGPolygon3D *self, godot_bool smooth_faces) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPolygon3D, set_smooth_faces, 2586408642, void, self, &smooth_faces)
}
godot_bool godot_CSGPolygon3D_get_smooth_faces(const godot_CSGPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPolygon3D, get_smooth_faces, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
