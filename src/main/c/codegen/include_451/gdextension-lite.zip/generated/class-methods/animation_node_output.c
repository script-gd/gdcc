// This file was automatically generated
// Do not modify this file
#include "animation_node_output.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeOutput *godot_new_AnimationNodeOutput() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeOutput);
}


#ifdef __cplusplus
}
#endif
