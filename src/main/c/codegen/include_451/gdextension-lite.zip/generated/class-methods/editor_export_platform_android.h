// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLATFORM_ANDROID_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLATFORM_ANDROID_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorExportPlatformAndroid *godot_new_EditorExportPlatformAndroid();


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLATFORM_ANDROID_H__
