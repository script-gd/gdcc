// This file was automatically generated
// Do not modify this file
#include "audio_effect.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffect *godot_new_AudioEffect() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffect);
}

// Methods
godot_AudioEffectInstance * godot_AudioEffect__instantiate(godot_AudioEffect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffect, _instantiate, 1659796816, godot_AudioEffectInstance *, self)
}


#ifdef __cplusplus
}
#endif
