// This file was automatically generated
// Do not modify this file
#include "bit_map.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BitMap *godot_new_BitMap() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BitMap);
}

// Methods
void godot_BitMap_create(godot_BitMap *self, const godot_Vector2i *size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BitMap, create, 1130785943, void, self, size)
}
void godot_BitMap_create_from_image_alpha(godot_BitMap *self, const godot_Image *image, godot_float threshold) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BitMap, create_from_image_alpha, 106271684, void, self, image, &threshold)
}
void godot_BitMap_set_bitv(godot_BitMap *self, const godot_Vector2i *position, godot_bool bit) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BitMap, set_bitv, 4153096796, void, self, position, &bit)
}
void godot_BitMap_set_bit(godot_BitMap *self, godot_int x, godot_int y, godot_bool bit) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BitMap, set_bit, 1383440665, void, self, &x, &y, &bit)
}
godot_bool godot_BitMap_get_bitv(const godot_BitMap *self, const godot_Vector2i *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BitMap, get_bitv, 3900751641, godot_bool, self, position)
}
godot_bool godot_BitMap_get_bit(const godot_BitMap *self, godot_int x, godot_int y) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BitMap, get_bit, 2522259332, godot_bool, self, &x, &y)
}
void godot_BitMap_set_bit_rect(godot_BitMap *self, const godot_Rect2i *rect, godot_bool bit) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BitMap, set_bit_rect, 472162941, void, self, rect, &bit)
}
godot_int godot_BitMap_get_true_bit_count(const godot_BitMap *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BitMap, get_true_bit_count, 3905245786, godot_int, self)
}
godot_Vector2i godot_BitMap_get_size(const godot_BitMap *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BitMap, get_size, 3690982128, godot_Vector2i, self)
}
void godot_BitMap_resize(godot_BitMap *self, const godot_Vector2i *new_size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BitMap, resize, 1130785943, void, self, new_size)
}
void godot_BitMap_grow_mask(godot_BitMap *self, godot_int pixels, const godot_Rect2i *rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BitMap, grow_mask, 3317281434, void, self, &pixels, rect)
}
godot_Image * godot_BitMap_convert_to_image(const godot_BitMap *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BitMap, convert_to_image, 4190603485, godot_Image *, self)
}
godot_TypedArray(godot_PackedVector2Array) godot_BitMap_opaque_to_polygons(const godot_BitMap *self, const godot_Rect2i *rect, godot_float epsilon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BitMap, opaque_to_polygons, 48478126, godot_TypedArray(godot_PackedVector2Array), self, rect, &epsilon)
}


#ifdef __cplusplus
}
#endif
