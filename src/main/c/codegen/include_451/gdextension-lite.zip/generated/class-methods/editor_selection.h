// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SELECTION_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SELECTION_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorSelection *godot_new_EditorSelection();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorSelection_clear(godot_EditorSelection *self);
GDEXTENSION_LITE_DECL void godot_EditorSelection_add_node(godot_EditorSelection *self, const godot_Node *node);
GDEXTENSION_LITE_DECL void godot_EditorSelection_remove_node(godot_EditorSelection *self, const godot_Node *node);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Node) godot_EditorSelection_get_selected_nodes(godot_EditorSelection *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Node) godot_EditorSelection_get_top_selected_nodes(godot_EditorSelection *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Node) godot_EditorSelection_get_transformable_selected_nodes(godot_EditorSelection *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SELECTION_H__
