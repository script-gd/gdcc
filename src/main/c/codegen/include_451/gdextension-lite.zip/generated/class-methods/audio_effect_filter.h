// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_FILTER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_FILTER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectFilter *godot_new_AudioEffectFilter();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectFilter_set_cutoff(godot_AudioEffectFilter *self, godot_float freq);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectFilter_get_cutoff(const godot_AudioEffectFilter *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectFilter_set_resonance(godot_AudioEffectFilter *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectFilter_get_resonance(const godot_AudioEffectFilter *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectFilter_set_gain(godot_AudioEffectFilter *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectFilter_get_gain(const godot_AudioEffectFilter *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectFilter_set_db(godot_AudioEffectFilter *self, godot_AudioEffectFilter_FilterDB amount);
GDEXTENSION_LITE_DECL godot_AudioEffectFilter_FilterDB godot_AudioEffectFilter_get_db(const godot_AudioEffectFilter *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_FILTER_H__
