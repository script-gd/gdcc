// This file was automatically generated
// Do not modify this file
#include "audio_effect_band_pass_filter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectBandPassFilter *godot_new_AudioEffectBandPassFilter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectBandPassFilter);
}


#ifdef __cplusplus
}
#endif
