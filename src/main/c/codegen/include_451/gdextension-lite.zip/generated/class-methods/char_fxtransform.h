// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CHAR_FXTRANSFORM_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CHAR_FXTRANSFORM_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CharFXTransform *godot_new_CharFXTransform();

// Methods
GDEXTENSION_LITE_DECL godot_Transform2D godot_CharFXTransform_get_transform(godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_transform(godot_CharFXTransform *self, const godot_Transform2D *transform);
GDEXTENSION_LITE_DECL godot_Vector2i godot_CharFXTransform_get_range(godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_range(godot_CharFXTransform *self, const godot_Vector2i *range);
GDEXTENSION_LITE_DECL godot_float godot_CharFXTransform_get_elapsed_time(godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_elapsed_time(godot_CharFXTransform *self, godot_float time);
GDEXTENSION_LITE_DECL godot_bool godot_CharFXTransform_is_visible(godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_visibility(godot_CharFXTransform *self, godot_bool visibility);
GDEXTENSION_LITE_DECL godot_bool godot_CharFXTransform_is_outline(godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_outline(godot_CharFXTransform *self, godot_bool outline);
GDEXTENSION_LITE_DECL godot_Vector2 godot_CharFXTransform_get_offset(godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_offset(godot_CharFXTransform *self, const godot_Vector2 *offset);
GDEXTENSION_LITE_DECL godot_Color godot_CharFXTransform_get_color(godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_color(godot_CharFXTransform *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Dictionary godot_CharFXTransform_get_environment(godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_environment(godot_CharFXTransform *self, const godot_Dictionary *environment);
GDEXTENSION_LITE_DECL godot_int godot_CharFXTransform_get_glyph_index(const godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_glyph_index(godot_CharFXTransform *self, godot_int glyph_index);
GDEXTENSION_LITE_DECL godot_int godot_CharFXTransform_get_relative_index(const godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_relative_index(godot_CharFXTransform *self, godot_int relative_index);
GDEXTENSION_LITE_DECL godot_int godot_CharFXTransform_get_glyph_count(const godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_glyph_count(godot_CharFXTransform *self, godot_int glyph_count);
GDEXTENSION_LITE_DECL godot_int godot_CharFXTransform_get_glyph_flags(const godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_glyph_flags(godot_CharFXTransform *self, godot_int glyph_flags);
GDEXTENSION_LITE_DECL godot_RID godot_CharFXTransform_get_font(const godot_CharFXTransform *self);
GDEXTENSION_LITE_DECL void godot_CharFXTransform_set_font(godot_CharFXTransform *self, const godot_RID *font);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CHAR_FXTRANSFORM_H__
