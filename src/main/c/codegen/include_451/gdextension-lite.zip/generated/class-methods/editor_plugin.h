// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorPlugin *godot_new_EditorPlugin();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_EditorPlugin__forward_canvas_gui_input(godot_EditorPlugin *self, const godot_InputEvent *event);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__forward_canvas_draw_over_viewport(godot_EditorPlugin *self, const godot_Control *viewport_control);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__forward_canvas_force_draw_over_viewport(godot_EditorPlugin *self, const godot_Control *viewport_control);
GDEXTENSION_LITE_DECL godot_int godot_EditorPlugin__forward_3d_gui_input(godot_EditorPlugin *self, const godot_Camera3D *viewport_camera, const godot_InputEvent *event);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__forward_3d_draw_over_viewport(godot_EditorPlugin *self, const godot_Control *viewport_control);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__forward_3d_force_draw_over_viewport(godot_EditorPlugin *self, const godot_Control *viewport_control);
GDEXTENSION_LITE_DECL godot_String godot_EditorPlugin__get_plugin_name(const godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_EditorPlugin__get_plugin_icon(const godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorPlugin__has_main_screen(const godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__make_visible(godot_EditorPlugin *self, godot_bool visible);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__edit(godot_EditorPlugin *self, const godot_Object *object);
GDEXTENSION_LITE_DECL godot_bool godot_EditorPlugin__handles(const godot_EditorPlugin *self, const godot_Object *object);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorPlugin__get_state(const godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__set_state(godot_EditorPlugin *self, const godot_Dictionary *state);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__clear(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorPlugin__get_unsaved_status(const godot_EditorPlugin *self, const godot_String *for_scene);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__save_external_data(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__apply_changes(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorPlugin__get_breakpoints(const godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__set_window_layout(godot_EditorPlugin *self, const godot_ConfigFile *configuration);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__get_window_layout(godot_EditorPlugin *self, const godot_ConfigFile *configuration);
GDEXTENSION_LITE_DECL godot_bool godot_EditorPlugin__build(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__enable_plugin(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin__disable_plugin(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_control_to_container(godot_EditorPlugin *self, godot_EditorPlugin_CustomControlContainer container, const godot_Control *control);
GDEXTENSION_LITE_DECL godot_Button * godot_EditorPlugin_add_control_to_bottom_panel(godot_EditorPlugin *self, const godot_Control *control, const godot_String *title, const godot_Shortcut *shortcut);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_control_to_dock(godot_EditorPlugin *self, godot_EditorPlugin_DockSlot slot, const godot_Control *control, const godot_Shortcut *shortcut);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_control_from_docks(godot_EditorPlugin *self, const godot_Control *control);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_control_from_bottom_panel(godot_EditorPlugin *self, const godot_Control *control);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_control_from_container(godot_EditorPlugin *self, godot_EditorPlugin_CustomControlContainer container, const godot_Control *control);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_set_dock_tab_icon(godot_EditorPlugin *self, const godot_Control *control, const godot_Texture2D *icon);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_tool_menu_item(godot_EditorPlugin *self, const godot_String *name, const godot_Callable *callable);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_tool_submenu_item(godot_EditorPlugin *self, const godot_String *name, const godot_PopupMenu *submenu);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_tool_menu_item(godot_EditorPlugin *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_PopupMenu * godot_EditorPlugin_get_export_as_menu(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_custom_type(godot_EditorPlugin *self, const godot_String *type, const godot_String *base, const godot_Script *script, const godot_Texture2D *icon);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_custom_type(godot_EditorPlugin *self, const godot_String *type);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_autoload_singleton(godot_EditorPlugin *self, const godot_String *name, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_autoload_singleton(godot_EditorPlugin *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_int godot_EditorPlugin_update_overlays(const godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_make_bottom_panel_item_visible(godot_EditorPlugin *self, const godot_Control *item);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_hide_bottom_panel(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL godot_EditorUndoRedoManager * godot_EditorPlugin_get_undo_redo(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_undo_redo_inspector_hook_callback(godot_EditorPlugin *self, const godot_Callable *callable);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_undo_redo_inspector_hook_callback(godot_EditorPlugin *self, const godot_Callable *callable);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_queue_save_layout(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_translation_parser_plugin(godot_EditorPlugin *self, const godot_EditorTranslationParserPlugin *parser);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_translation_parser_plugin(godot_EditorPlugin *self, const godot_EditorTranslationParserPlugin *parser);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_import_plugin(godot_EditorPlugin *self, const godot_EditorImportPlugin *importer, godot_bool first_priority);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_import_plugin(godot_EditorPlugin *self, const godot_EditorImportPlugin *importer);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_scene_format_importer_plugin(godot_EditorPlugin *self, const godot_EditorSceneFormatImporter *scene_format_importer, godot_bool first_priority);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_scene_format_importer_plugin(godot_EditorPlugin *self, const godot_EditorSceneFormatImporter *scene_format_importer);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_scene_post_import_plugin(godot_EditorPlugin *self, const godot_EditorScenePostImportPlugin *scene_import_plugin, godot_bool first_priority);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_scene_post_import_plugin(godot_EditorPlugin *self, const godot_EditorScenePostImportPlugin *scene_import_plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_export_plugin(godot_EditorPlugin *self, const godot_EditorExportPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_export_plugin(godot_EditorPlugin *self, const godot_EditorExportPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_export_platform(godot_EditorPlugin *self, const godot_EditorExportPlatform *platform);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_export_platform(godot_EditorPlugin *self, const godot_EditorExportPlatform *platform);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_node_3d_gizmo_plugin(godot_EditorPlugin *self, const godot_EditorNode3DGizmoPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_node_3d_gizmo_plugin(godot_EditorPlugin *self, const godot_EditorNode3DGizmoPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_inspector_plugin(godot_EditorPlugin *self, const godot_EditorInspectorPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_inspector_plugin(godot_EditorPlugin *self, const godot_EditorInspectorPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_resource_conversion_plugin(godot_EditorPlugin *self, const godot_EditorResourceConversionPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_resource_conversion_plugin(godot_EditorPlugin *self, const godot_EditorResourceConversionPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_set_input_event_forwarding_always_enabled(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_set_force_draw_over_forwarding_enabled(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_context_menu_plugin(godot_EditorPlugin *self, godot_EditorContextMenuPlugin_ContextMenuSlot slot, const godot_EditorContextMenuPlugin *plugin);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_context_menu_plugin(godot_EditorPlugin *self, const godot_EditorContextMenuPlugin *plugin);
GDEXTENSION_LITE_DECL godot_EditorInterface * godot_EditorPlugin_get_editor_interface(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL godot_ScriptCreateDialog * godot_EditorPlugin_get_script_create_dialog(godot_EditorPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_add_debugger_plugin(godot_EditorPlugin *self, const godot_EditorDebuggerPlugin *script);
GDEXTENSION_LITE_DECL void godot_EditorPlugin_remove_debugger_plugin(godot_EditorPlugin *self, const godot_EditorDebuggerPlugin *script);
GDEXTENSION_LITE_DECL godot_String godot_EditorPlugin_get_plugin_version(const godot_EditorPlugin *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PLUGIN_H__
