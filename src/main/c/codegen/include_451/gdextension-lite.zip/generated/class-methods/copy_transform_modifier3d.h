// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COPY_TRANSFORM_MODIFIER3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COPY_TRANSFORM_MODIFIER3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CopyTransformModifier3D *godot_new_CopyTransformModifier3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_copy_flags(godot_CopyTransformModifier3D *self, godot_int index, const godot_CopyTransformModifier3D_TransformFlag *copy_flags);
GDEXTENSION_LITE_DECL godot_CopyTransformModifier3D_TransformFlag godot_CopyTransformModifier3D_get_copy_flags(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_axis_flags(godot_CopyTransformModifier3D *self, godot_int index, const godot_CopyTransformModifier3D_AxisFlag *axis_flags);
GDEXTENSION_LITE_DECL godot_CopyTransformModifier3D_AxisFlag godot_CopyTransformModifier3D_get_axis_flags(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_invert_flags(godot_CopyTransformModifier3D *self, godot_int index, const godot_CopyTransformModifier3D_AxisFlag *axis_flags);
GDEXTENSION_LITE_DECL godot_CopyTransformModifier3D_AxisFlag godot_CopyTransformModifier3D_get_invert_flags(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_copy_position(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_position_copying(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_copy_rotation(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_rotation_copying(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_copy_scale(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_scale_copying(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_axis_x_enabled(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_axis_x_enabled(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_axis_y_enabled(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_axis_y_enabled(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_axis_z_enabled(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_axis_z_enabled(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_axis_x_inverted(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_axis_x_inverted(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_axis_y_inverted(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_axis_y_inverted(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_axis_z_inverted(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_axis_z_inverted(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_relative(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_relative(const godot_CopyTransformModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CopyTransformModifier3D_set_additive(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CopyTransformModifier3D_is_additive(const godot_CopyTransformModifier3D *self, godot_int index);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COPY_TRANSFORM_MODIFIER3D_H__
