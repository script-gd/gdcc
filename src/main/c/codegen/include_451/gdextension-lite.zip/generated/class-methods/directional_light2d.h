// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIRECTIONAL_LIGHT2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIRECTIONAL_LIGHT2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_DirectionalLight2D *godot_new_DirectionalLight2D();

// Methods
GDEXTENSION_LITE_DECL void godot_DirectionalLight2D_set_max_distance(godot_DirectionalLight2D *self, godot_float pixels);
GDEXTENSION_LITE_DECL godot_float godot_DirectionalLight2D_get_max_distance(const godot_DirectionalLight2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIRECTIONAL_LIGHT2D_H__
