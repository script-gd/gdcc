// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_CONSTRAINT3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_CONSTRAINT3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BoneConstraint3D *godot_new_BoneConstraint3D();

// Methods
GDEXTENSION_LITE_DECL void godot_BoneConstraint3D_set_amount(godot_BoneConstraint3D *self, godot_int index, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_BoneConstraint3D_get_amount(const godot_BoneConstraint3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_BoneConstraint3D_set_apply_bone_name(godot_BoneConstraint3D *self, godot_int index, const godot_String *bone_name);
GDEXTENSION_LITE_DECL godot_String godot_BoneConstraint3D_get_apply_bone_name(const godot_BoneConstraint3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_BoneConstraint3D_set_apply_bone(godot_BoneConstraint3D *self, godot_int index, godot_int bone);
GDEXTENSION_LITE_DECL godot_int godot_BoneConstraint3D_get_apply_bone(const godot_BoneConstraint3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_BoneConstraint3D_set_reference_bone_name(godot_BoneConstraint3D *self, godot_int index, const godot_String *bone_name);
GDEXTENSION_LITE_DECL godot_String godot_BoneConstraint3D_get_reference_bone_name(const godot_BoneConstraint3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_BoneConstraint3D_set_reference_bone(godot_BoneConstraint3D *self, godot_int index, godot_int bone);
GDEXTENSION_LITE_DECL godot_int godot_BoneConstraint3D_get_reference_bone(const godot_BoneConstraint3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_BoneConstraint3D_set_setting_count(godot_BoneConstraint3D *self, godot_int count);
GDEXTENSION_LITE_DECL godot_int godot_BoneConstraint3D_get_setting_count(const godot_BoneConstraint3D *self);
GDEXTENSION_LITE_DECL void godot_BoneConstraint3D_clear_setting(godot_BoneConstraint3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_CONSTRAINT3D_H__
