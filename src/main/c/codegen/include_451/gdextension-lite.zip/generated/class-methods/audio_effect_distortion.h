// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_DISTORTION_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_DISTORTION_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectDistortion *godot_new_AudioEffectDistortion();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectDistortion_set_mode(godot_AudioEffectDistortion *self, godot_AudioEffectDistortion_Mode mode);
GDEXTENSION_LITE_DECL godot_AudioEffectDistortion_Mode godot_AudioEffectDistortion_get_mode(const godot_AudioEffectDistortion *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDistortion_set_pre_gain(godot_AudioEffectDistortion *self, godot_float pre_gain);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDistortion_get_pre_gain(const godot_AudioEffectDistortion *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDistortion_set_keep_hf_hz(godot_AudioEffectDistortion *self, godot_float keep_hf_hz);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDistortion_get_keep_hf_hz(const godot_AudioEffectDistortion *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDistortion_set_drive(godot_AudioEffectDistortion *self, godot_float drive);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDistortion_get_drive(const godot_AudioEffectDistortion *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDistortion_set_post_gain(godot_AudioEffectDistortion *self, godot_float post_gain);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDistortion_get_post_gain(const godot_AudioEffectDistortion *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_DISTORTION_H__
