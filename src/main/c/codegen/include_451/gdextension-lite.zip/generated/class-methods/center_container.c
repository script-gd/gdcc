// This file was automatically generated
// Do not modify this file
#include "center_container.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CenterContainer *godot_new_CenterContainer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CenterContainer);
}

// Methods
void godot_CenterContainer_set_use_top_left(godot_CenterContainer *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CenterContainer, set_use_top_left, 2586408642, void, self, &enable)
}
godot_bool godot_CenterContainer_is_using_top_left(const godot_CenterContainer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CenterContainer, is_using_top_left, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
