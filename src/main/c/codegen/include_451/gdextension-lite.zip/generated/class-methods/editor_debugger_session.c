// This file was automatically generated
// Do not modify this file
#include "editor_debugger_session.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
void godot_EditorDebuggerSession_send_message(godot_EditorDebuggerSession *self, const godot_String *message, const godot_Array *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerSession, send_message, 85656714, void, self, message, data)
}
void godot_EditorDebuggerSession_toggle_profiler(godot_EditorDebuggerSession *self, const godot_String *profiler, godot_bool enable, const godot_Array *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerSession, toggle_profiler, 1198443697, void, self, profiler, &enable, data)
}
godot_bool godot_EditorDebuggerSession_is_breaked(godot_EditorDebuggerSession *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorDebuggerSession, is_breaked, 2240911060, godot_bool, self)
}
godot_bool godot_EditorDebuggerSession_is_debuggable(godot_EditorDebuggerSession *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorDebuggerSession, is_debuggable, 2240911060, godot_bool, self)
}
godot_bool godot_EditorDebuggerSession_is_active(godot_EditorDebuggerSession *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorDebuggerSession, is_active, 2240911060, godot_bool, self)
}
void godot_EditorDebuggerSession_add_session_tab(godot_EditorDebuggerSession *self, const godot_Control *control) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerSession, add_session_tab, 1496901182, void, self, control)
}
void godot_EditorDebuggerSession_remove_session_tab(godot_EditorDebuggerSession *self, const godot_Control *control) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerSession, remove_session_tab, 1496901182, void, self, control)
}
void godot_EditorDebuggerSession_set_breakpoint(godot_EditorDebuggerSession *self, const godot_String *path, godot_int line, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerSession, set_breakpoint, 4108344793, void, self, path, &line, &enabled)
}


#ifdef __cplusplus
}
#endif
