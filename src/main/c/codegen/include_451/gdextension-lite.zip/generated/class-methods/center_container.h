// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CENTER_CONTAINER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CENTER_CONTAINER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CenterContainer *godot_new_CenterContainer();

// Methods
GDEXTENSION_LITE_DECL void godot_CenterContainer_set_use_top_left(godot_CenterContainer *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CenterContainer_is_using_top_left(const godot_CenterContainer *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CENTER_CONTAINER_H__
