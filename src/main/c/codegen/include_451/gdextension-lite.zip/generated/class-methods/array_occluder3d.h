// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ARRAY_OCCLUDER3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ARRAY_OCCLUDER3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ArrayOccluder3D *godot_new_ArrayOccluder3D();

// Methods
GDEXTENSION_LITE_DECL void godot_ArrayOccluder3D_set_arrays(godot_ArrayOccluder3D *self, const godot_PackedVector3Array *vertices, const godot_PackedInt32Array *indices);
GDEXTENSION_LITE_DECL void godot_ArrayOccluder3D_set_vertices(godot_ArrayOccluder3D *self, const godot_PackedVector3Array *vertices);
GDEXTENSION_LITE_DECL void godot_ArrayOccluder3D_set_indices(godot_ArrayOccluder3D *self, const godot_PackedInt32Array *indices);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ARRAY_OCCLUDER3D_H__
