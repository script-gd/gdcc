// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CODE_EDIT_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CODE_EDIT_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CodeEdit *godot_new_CodeEdit();

// Methods
GDEXTENSION_LITE_DECL void godot_CodeEdit__confirm_code_completion(godot_CodeEdit *self, godot_bool replace);
GDEXTENSION_LITE_DECL void godot_CodeEdit__request_code_completion(godot_CodeEdit *self, godot_bool force);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_CodeEdit__filter_code_completion_candidates(const godot_CodeEdit *self, const godot_TypedArray(godot_Dictionary) *candidates);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_indent_size(godot_CodeEdit *self, godot_int size);
GDEXTENSION_LITE_DECL godot_int godot_CodeEdit_get_indent_size(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_indent_using_spaces(godot_CodeEdit *self, godot_bool use_spaces);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_indent_using_spaces(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_auto_indent_enabled(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_auto_indent_enabled(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_auto_indent_prefixes(godot_CodeEdit *self, const godot_TypedArray(godot_String) *prefixes);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_String) godot_CodeEdit_get_auto_indent_prefixes(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_do_indent(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_indent_lines(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_unindent_lines(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_convert_indent(godot_CodeEdit *self, godot_int from_line, godot_int to_line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_auto_brace_completion_enabled(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_auto_brace_completion_enabled(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_highlight_matching_braces_enabled(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_highlight_matching_braces_enabled(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_add_auto_brace_completion_pair(godot_CodeEdit *self, const godot_String *start_key, const godot_String *end_key);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_auto_brace_completion_pairs(godot_CodeEdit *self, const godot_Dictionary *pairs);
GDEXTENSION_LITE_DECL godot_Dictionary godot_CodeEdit_get_auto_brace_completion_pairs(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_has_auto_brace_completion_open_key(const godot_CodeEdit *self, const godot_String *open_key);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_has_auto_brace_completion_close_key(const godot_CodeEdit *self, const godot_String *close_key);
GDEXTENSION_LITE_DECL godot_String godot_CodeEdit_get_auto_brace_completion_close_key(const godot_CodeEdit *self, const godot_String *open_key);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_draw_breakpoints_gutter(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_drawing_breakpoints_gutter(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_draw_bookmarks_gutter(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_drawing_bookmarks_gutter(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_draw_executing_lines_gutter(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_drawing_executing_lines_gutter(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_line_as_breakpoint(godot_CodeEdit *self, godot_int line, godot_bool breakpointed);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_line_breakpointed(const godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_clear_breakpointed_lines(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_CodeEdit_get_breakpointed_lines(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_line_as_bookmarked(godot_CodeEdit *self, godot_int line, godot_bool bookmarked);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_line_bookmarked(const godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_clear_bookmarked_lines(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_CodeEdit_get_bookmarked_lines(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_line_as_executing(godot_CodeEdit *self, godot_int line, godot_bool executing);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_line_executing(const godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_clear_executing_lines(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_CodeEdit_get_executing_lines(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_draw_line_numbers(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_draw_line_numbers_enabled(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_line_numbers_zero_padded(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_line_numbers_zero_padded(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_draw_fold_gutter(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_drawing_fold_gutter(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_line_folding_enabled(godot_CodeEdit *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_line_folding_enabled(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_can_fold_line(const godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_fold_line(godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_unfold_line(godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_fold_all_lines(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_unfold_all_lines(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_toggle_foldable_line(godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_toggle_foldable_lines_at_carets(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_line_folded(const godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_int) godot_CodeEdit_get_folded_lines(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_create_code_region(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_String godot_CodeEdit_get_code_region_start_tag(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_String godot_CodeEdit_get_code_region_end_tag(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_code_region_tags(godot_CodeEdit *self, const godot_String *start, const godot_String *end);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_line_code_region_start(const godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_line_code_region_end(const godot_CodeEdit *self, godot_int line);
GDEXTENSION_LITE_DECL void godot_CodeEdit_add_string_delimiter(godot_CodeEdit *self, const godot_String *start_key, const godot_String *end_key, godot_bool line_only);
GDEXTENSION_LITE_DECL void godot_CodeEdit_remove_string_delimiter(godot_CodeEdit *self, const godot_String *start_key);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_has_string_delimiter(const godot_CodeEdit *self, const godot_String *start_key);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_string_delimiters(godot_CodeEdit *self, const godot_TypedArray(godot_String) *string_delimiters);
GDEXTENSION_LITE_DECL void godot_CodeEdit_clear_string_delimiters(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_String) godot_CodeEdit_get_string_delimiters(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_int godot_CodeEdit_is_in_string(const godot_CodeEdit *self, godot_int line, godot_int column);
GDEXTENSION_LITE_DECL void godot_CodeEdit_add_comment_delimiter(godot_CodeEdit *self, const godot_String *start_key, const godot_String *end_key, godot_bool line_only);
GDEXTENSION_LITE_DECL void godot_CodeEdit_remove_comment_delimiter(godot_CodeEdit *self, const godot_String *start_key);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_has_comment_delimiter(const godot_CodeEdit *self, const godot_String *start_key);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_comment_delimiters(godot_CodeEdit *self, const godot_TypedArray(godot_String) *comment_delimiters);
GDEXTENSION_LITE_DECL void godot_CodeEdit_clear_comment_delimiters(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_String) godot_CodeEdit_get_comment_delimiters(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_int godot_CodeEdit_is_in_comment(const godot_CodeEdit *self, godot_int line, godot_int column);
GDEXTENSION_LITE_DECL godot_String godot_CodeEdit_get_delimiter_start_key(const godot_CodeEdit *self, godot_int delimiter_index);
GDEXTENSION_LITE_DECL godot_String godot_CodeEdit_get_delimiter_end_key(const godot_CodeEdit *self, godot_int delimiter_index);
GDEXTENSION_LITE_DECL godot_Vector2 godot_CodeEdit_get_delimiter_start_position(const godot_CodeEdit *self, godot_int line, godot_int column);
GDEXTENSION_LITE_DECL godot_Vector2 godot_CodeEdit_get_delimiter_end_position(const godot_CodeEdit *self, godot_int line, godot_int column);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_code_hint(godot_CodeEdit *self, const godot_String *code_hint);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_code_hint_draw_below(godot_CodeEdit *self, godot_bool draw_below);
GDEXTENSION_LITE_DECL godot_String godot_CodeEdit_get_text_for_code_completion(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_request_code_completion(godot_CodeEdit *self, godot_bool force);
GDEXTENSION_LITE_DECL void godot_CodeEdit_add_code_completion_option(godot_CodeEdit *self, godot_CodeEdit_CodeCompletionKind type, const godot_String *display_text, const godot_String *insert_text, const godot_Color *text_color, const godot_Resource *icon, const godot_Variant *value, godot_int location);
GDEXTENSION_LITE_DECL void godot_CodeEdit_update_code_completion_options(godot_CodeEdit *self, godot_bool force);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_CodeEdit_get_code_completion_options(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_Dictionary godot_CodeEdit_get_code_completion_option(const godot_CodeEdit *self, godot_int index);
GDEXTENSION_LITE_DECL godot_int godot_CodeEdit_get_code_completion_selected_index(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_code_completion_selected_index(godot_CodeEdit *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_CodeEdit_confirm_code_completion(godot_CodeEdit *self, godot_bool replace);
GDEXTENSION_LITE_DECL void godot_CodeEdit_cancel_code_completion(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_code_completion_enabled(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_code_completion_enabled(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_code_completion_prefixes(godot_CodeEdit *self, const godot_TypedArray(godot_String) *prefixes);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_String) godot_CodeEdit_get_code_completion_prefixes(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_line_length_guidelines(godot_CodeEdit *self, const godot_TypedArray(godot_int) *guideline_columns);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_int) godot_CodeEdit_get_line_length_guidelines(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_symbol_lookup_on_click_enabled(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_symbol_lookup_on_click_enabled(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_String godot_CodeEdit_get_text_for_symbol_lookup(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL godot_String godot_CodeEdit_get_text_with_cursor_char(const godot_CodeEdit *self, godot_int line, godot_int column);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_symbol_lookup_word_as_valid(godot_CodeEdit *self, godot_bool valid);
GDEXTENSION_LITE_DECL void godot_CodeEdit_set_symbol_tooltip_on_hover_enabled(godot_CodeEdit *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CodeEdit_is_symbol_tooltip_on_hover_enabled(const godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_move_lines_up(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_move_lines_down(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_delete_lines(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_duplicate_selection(godot_CodeEdit *self);
GDEXTENSION_LITE_DECL void godot_CodeEdit_duplicate_lines(godot_CodeEdit *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CODE_EDIT_H__
