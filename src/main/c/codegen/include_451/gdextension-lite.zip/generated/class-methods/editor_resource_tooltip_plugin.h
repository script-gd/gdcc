// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_TOOLTIP_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_TOOLTIP_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorResourceTooltipPlugin *godot_new_EditorResourceTooltipPlugin();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_EditorResourceTooltipPlugin__handles(const godot_EditorResourceTooltipPlugin *self, const godot_String *type);
GDEXTENSION_LITE_DECL godot_Control * godot_EditorResourceTooltipPlugin__make_tooltip_for_path(const godot_EditorResourceTooltipPlugin *self, const godot_String *path, const godot_Dictionary *metadata, const godot_Control *base);
GDEXTENSION_LITE_DECL void godot_EditorResourceTooltipPlugin_request_thumbnail(const godot_EditorResourceTooltipPlugin *self, const godot_String *path, const godot_TextureRect *control);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_TOOLTIP_PLUGIN_H__
