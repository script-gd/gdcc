// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_LISTENER3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_LISTENER3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioListener3D *godot_new_AudioListener3D();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioListener3D_make_current(godot_AudioListener3D *self);
GDEXTENSION_LITE_DECL void godot_AudioListener3D_clear_current(godot_AudioListener3D *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioListener3D_is_current(const godot_AudioListener3D *self);
GDEXTENSION_LITE_DECL godot_Transform3D godot_AudioListener3D_get_listener_transform(const godot_AudioListener3D *self);
GDEXTENSION_LITE_DECL void godot_AudioListener3D_set_doppler_tracking(godot_AudioListener3D *self, godot_AudioListener3D_DopplerTracking mode);
GDEXTENSION_LITE_DECL godot_AudioListener3D_DopplerTracking godot_AudioListener3D_get_doppler_tracking(const godot_AudioListener3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_LISTENER3D_H__
