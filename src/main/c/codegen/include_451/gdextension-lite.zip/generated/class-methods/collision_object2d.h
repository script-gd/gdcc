// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_OBJECT2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_OBJECT2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL void godot_CollisionObject2D__input_event(godot_CollisionObject2D *self, const godot_Viewport *viewport, const godot_InputEvent *event, godot_int shape_idx);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D__mouse_enter(godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D__mouse_exit(godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D__mouse_shape_enter(godot_CollisionObject2D *self, godot_int shape_idx);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D__mouse_shape_exit(godot_CollisionObject2D *self, godot_int shape_idx);
GDEXTENSION_LITE_DECL godot_RID godot_CollisionObject2D_get_rid(const godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_set_collision_layer(godot_CollisionObject2D *self, godot_int layer);
GDEXTENSION_LITE_DECL godot_int godot_CollisionObject2D_get_collision_layer(const godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_set_collision_mask(godot_CollisionObject2D *self, godot_int mask);
GDEXTENSION_LITE_DECL godot_int godot_CollisionObject2D_get_collision_mask(const godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_set_collision_layer_value(godot_CollisionObject2D *self, godot_int layer_number, godot_bool value);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionObject2D_get_collision_layer_value(const godot_CollisionObject2D *self, godot_int layer_number);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_set_collision_mask_value(godot_CollisionObject2D *self, godot_int layer_number, godot_bool value);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionObject2D_get_collision_mask_value(const godot_CollisionObject2D *self, godot_int layer_number);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_set_collision_priority(godot_CollisionObject2D *self, godot_float priority);
GDEXTENSION_LITE_DECL godot_float godot_CollisionObject2D_get_collision_priority(const godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_set_disable_mode(godot_CollisionObject2D *self, godot_CollisionObject2D_DisableMode mode);
GDEXTENSION_LITE_DECL godot_CollisionObject2D_DisableMode godot_CollisionObject2D_get_disable_mode(const godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_set_pickable(godot_CollisionObject2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionObject2D_is_pickable(const godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL godot_int godot_CollisionObject2D_create_shape_owner(godot_CollisionObject2D *self, const godot_Object *owner);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_remove_shape_owner(godot_CollisionObject2D *self, godot_int owner_id);
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_CollisionObject2D_get_shape_owners(godot_CollisionObject2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_shape_owner_set_transform(godot_CollisionObject2D *self, godot_int owner_id, const godot_Transform2D *transform);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CollisionObject2D_shape_owner_get_transform(const godot_CollisionObject2D *self, godot_int owner_id);
GDEXTENSION_LITE_DECL godot_Object * godot_CollisionObject2D_shape_owner_get_owner(const godot_CollisionObject2D *self, godot_int owner_id);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_shape_owner_set_disabled(godot_CollisionObject2D *self, godot_int owner_id, godot_bool disabled);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionObject2D_is_shape_owner_disabled(const godot_CollisionObject2D *self, godot_int owner_id);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_shape_owner_set_one_way_collision(godot_CollisionObject2D *self, godot_int owner_id, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionObject2D_is_shape_owner_one_way_collision_enabled(const godot_CollisionObject2D *self, godot_int owner_id);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_shape_owner_set_one_way_collision_margin(godot_CollisionObject2D *self, godot_int owner_id, godot_float margin);
GDEXTENSION_LITE_DECL godot_float godot_CollisionObject2D_get_shape_owner_one_way_collision_margin(const godot_CollisionObject2D *self, godot_int owner_id);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_shape_owner_add_shape(godot_CollisionObject2D *self, godot_int owner_id, const godot_Shape2D *shape);
GDEXTENSION_LITE_DECL godot_int godot_CollisionObject2D_shape_owner_get_shape_count(const godot_CollisionObject2D *self, godot_int owner_id);
GDEXTENSION_LITE_DECL godot_Shape2D * godot_CollisionObject2D_shape_owner_get_shape(const godot_CollisionObject2D *self, godot_int owner_id, godot_int shape_id);
GDEXTENSION_LITE_DECL godot_int godot_CollisionObject2D_shape_owner_get_shape_index(const godot_CollisionObject2D *self, godot_int owner_id, godot_int shape_id);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_shape_owner_remove_shape(godot_CollisionObject2D *self, godot_int owner_id, godot_int shape_id);
GDEXTENSION_LITE_DECL void godot_CollisionObject2D_shape_owner_clear_shapes(godot_CollisionObject2D *self, godot_int owner_id);
GDEXTENSION_LITE_DECL godot_int godot_CollisionObject2D_shape_find_owner(const godot_CollisionObject2D *self, godot_int shape_index);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_OBJECT2D_H__
