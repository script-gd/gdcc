// This file was automatically generated
// Do not modify this file
#include "decal.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Decal *godot_new_Decal() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Decal);
}

// Methods
void godot_Decal_set_size(godot_Decal *self, const godot_Vector3 *size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_size, 3460891852, void, self, size)
}
godot_Vector3 godot_Decal_get_size(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_size, 3360562783, godot_Vector3, self)
}
void godot_Decal_set_texture(godot_Decal *self, godot_Decal_DecalTexture type, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_texture, 2086764391, void, self, &type, texture)
}
godot_Texture2D * godot_Decal_get_texture(const godot_Decal *self, godot_Decal_DecalTexture type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_texture, 3244119503, godot_Texture2D *, self, &type)
}
void godot_Decal_set_emission_energy(godot_Decal *self, godot_float energy) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_emission_energy, 373806689, void, self, &energy)
}
godot_float godot_Decal_get_emission_energy(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_emission_energy, 1740695150, godot_float, self)
}
void godot_Decal_set_albedo_mix(godot_Decal *self, godot_float energy) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_albedo_mix, 373806689, void, self, &energy)
}
godot_float godot_Decal_get_albedo_mix(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_albedo_mix, 1740695150, godot_float, self)
}
void godot_Decal_set_modulate(godot_Decal *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_modulate, 2920490490, void, self, color)
}
godot_Color godot_Decal_get_modulate(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_modulate, 3444240500, godot_Color, self)
}
void godot_Decal_set_upper_fade(godot_Decal *self, godot_float fade) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_upper_fade, 373806689, void, self, &fade)
}
godot_float godot_Decal_get_upper_fade(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_upper_fade, 1740695150, godot_float, self)
}
void godot_Decal_set_lower_fade(godot_Decal *self, godot_float fade) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_lower_fade, 373806689, void, self, &fade)
}
godot_float godot_Decal_get_lower_fade(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_lower_fade, 1740695150, godot_float, self)
}
void godot_Decal_set_normal_fade(godot_Decal *self, godot_float fade) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_normal_fade, 373806689, void, self, &fade)
}
godot_float godot_Decal_get_normal_fade(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_normal_fade, 1740695150, godot_float, self)
}
void godot_Decal_set_enable_distance_fade(godot_Decal *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_enable_distance_fade, 2586408642, void, self, &enable)
}
godot_bool godot_Decal_is_distance_fade_enabled(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, is_distance_fade_enabled, 36873697, godot_bool, self)
}
void godot_Decal_set_distance_fade_begin(godot_Decal *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_distance_fade_begin, 373806689, void, self, &distance)
}
godot_float godot_Decal_get_distance_fade_begin(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_distance_fade_begin, 1740695150, godot_float, self)
}
void godot_Decal_set_distance_fade_length(godot_Decal *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_distance_fade_length, 373806689, void, self, &distance)
}
godot_float godot_Decal_get_distance_fade_length(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_distance_fade_length, 1740695150, godot_float, self)
}
void godot_Decal_set_cull_mask(godot_Decal *self, godot_int mask) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Decal, set_cull_mask, 1286410249, void, self, &mask)
}
godot_int godot_Decal_get_cull_mask(const godot_Decal *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Decal, get_cull_mask, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
