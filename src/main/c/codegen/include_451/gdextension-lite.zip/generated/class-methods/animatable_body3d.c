// This file was automatically generated
// Do not modify this file
#include "animatable_body3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimatableBody3D *godot_new_AnimatableBody3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimatableBody3D);
}

// Methods
void godot_AnimatableBody3D_set_sync_to_physics(godot_AnimatableBody3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatableBody3D, set_sync_to_physics, 2586408642, void, self, &enable)
}
godot_bool godot_AnimatableBody3D_is_sync_to_physics_enabled(const godot_AnimatableBody3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatableBody3D, is_sync_to_physics_enabled, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
