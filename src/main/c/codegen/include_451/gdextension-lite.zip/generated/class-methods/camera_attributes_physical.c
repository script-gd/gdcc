// This file was automatically generated
// Do not modify this file
#include "camera_attributes_physical.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CameraAttributesPhysical *godot_new_CameraAttributesPhysical() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CameraAttributesPhysical);
}

// Methods
void godot_CameraAttributesPhysical_set_aperture(godot_CameraAttributesPhysical *self, godot_float aperture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPhysical, set_aperture, 373806689, void, self, &aperture)
}
godot_float godot_CameraAttributesPhysical_get_aperture(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_aperture, 1740695150, godot_float, self)
}
void godot_CameraAttributesPhysical_set_shutter_speed(godot_CameraAttributesPhysical *self, godot_float shutter_speed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPhysical, set_shutter_speed, 373806689, void, self, &shutter_speed)
}
godot_float godot_CameraAttributesPhysical_get_shutter_speed(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_shutter_speed, 1740695150, godot_float, self)
}
void godot_CameraAttributesPhysical_set_focal_length(godot_CameraAttributesPhysical *self, godot_float focal_length) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPhysical, set_focal_length, 373806689, void, self, &focal_length)
}
godot_float godot_CameraAttributesPhysical_get_focal_length(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_focal_length, 1740695150, godot_float, self)
}
void godot_CameraAttributesPhysical_set_focus_distance(godot_CameraAttributesPhysical *self, godot_float focus_distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPhysical, set_focus_distance, 373806689, void, self, &focus_distance)
}
godot_float godot_CameraAttributesPhysical_get_focus_distance(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_focus_distance, 1740695150, godot_float, self)
}
void godot_CameraAttributesPhysical_set_near(godot_CameraAttributesPhysical *self, godot_float near) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPhysical, set_near, 373806689, void, self, &near)
}
godot_float godot_CameraAttributesPhysical_get_near(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_near, 1740695150, godot_float, self)
}
void godot_CameraAttributesPhysical_set_far(godot_CameraAttributesPhysical *self, godot_float far) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPhysical, set_far, 373806689, void, self, &far)
}
godot_float godot_CameraAttributesPhysical_get_far(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_far, 1740695150, godot_float, self)
}
godot_float godot_CameraAttributesPhysical_get_fov(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_fov, 1740695150, godot_float, self)
}
void godot_CameraAttributesPhysical_set_auto_exposure_max_exposure_value(godot_CameraAttributesPhysical *self, godot_float exposure_value_max) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPhysical, set_auto_exposure_max_exposure_value, 373806689, void, self, &exposure_value_max)
}
godot_float godot_CameraAttributesPhysical_get_auto_exposure_max_exposure_value(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_auto_exposure_max_exposure_value, 1740695150, godot_float, self)
}
void godot_CameraAttributesPhysical_set_auto_exposure_min_exposure_value(godot_CameraAttributesPhysical *self, godot_float exposure_value_min) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPhysical, set_auto_exposure_min_exposure_value, 373806689, void, self, &exposure_value_min)
}
godot_float godot_CameraAttributesPhysical_get_auto_exposure_min_exposure_value(const godot_CameraAttributesPhysical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPhysical, get_auto_exposure_min_exposure_value, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
