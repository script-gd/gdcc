// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGSPHERE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGSPHERE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CSGSphere3D *godot_new_CSGSphere3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CSGSphere3D_set_radius(godot_CSGSphere3D *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CSGSphere3D_get_radius(const godot_CSGSphere3D *self);
GDEXTENSION_LITE_DECL void godot_CSGSphere3D_set_radial_segments(godot_CSGSphere3D *self, godot_int radial_segments);
GDEXTENSION_LITE_DECL godot_int godot_CSGSphere3D_get_radial_segments(const godot_CSGSphere3D *self);
GDEXTENSION_LITE_DECL void godot_CSGSphere3D_set_rings(godot_CSGSphere3D *self, godot_int rings);
GDEXTENSION_LITE_DECL godot_int godot_CSGSphere3D_get_rings(const godot_CSGSphere3D *self);
GDEXTENSION_LITE_DECL void godot_CSGSphere3D_set_smooth_faces(godot_CSGSphere3D *self, godot_bool smooth_faces);
GDEXTENSION_LITE_DECL godot_bool godot_CSGSphere3D_get_smooth_faces(const godot_CSGSphere3D *self);
GDEXTENSION_LITE_DECL void godot_CSGSphere3D_set_material(godot_CSGSphere3D *self, const godot_Material *material);
GDEXTENSION_LITE_DECL godot_Material * godot_CSGSphere3D_get_material(const godot_CSGSphere3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGSPHERE3D_H__
