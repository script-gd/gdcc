// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_TREE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_TREE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationTree *godot_new_AnimationTree();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationTree_set_tree_root(godot_AnimationTree *self, const godot_AnimationRootNode *animation_node);
GDEXTENSION_LITE_DECL godot_AnimationRootNode * godot_AnimationTree_get_tree_root(const godot_AnimationTree *self);
GDEXTENSION_LITE_DECL void godot_AnimationTree_set_advance_expression_base_node(godot_AnimationTree *self, const godot_NodePath *path);
GDEXTENSION_LITE_DECL godot_NodePath godot_AnimationTree_get_advance_expression_base_node(const godot_AnimationTree *self);
GDEXTENSION_LITE_DECL void godot_AnimationTree_set_animation_player(godot_AnimationTree *self, const godot_NodePath *path);
GDEXTENSION_LITE_DECL godot_NodePath godot_AnimationTree_get_animation_player(const godot_AnimationTree *self);
GDEXTENSION_LITE_DECL void godot_AnimationTree_set_process_callback(godot_AnimationTree *self, godot_AnimationTree_AnimationProcessCallback mode);
GDEXTENSION_LITE_DECL godot_AnimationTree_AnimationProcessCallback godot_AnimationTree_get_process_callback(const godot_AnimationTree *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_TREE_H__
