// This file was automatically generated
// Do not modify this file
#include "cylinder_mesh.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CylinderMesh *godot_new_CylinderMesh() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CylinderMesh);
}

// Methods
void godot_CylinderMesh_set_top_radius(godot_CylinderMesh *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderMesh, set_top_radius, 373806689, void, self, &radius)
}
godot_float godot_CylinderMesh_get_top_radius(const godot_CylinderMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderMesh, get_top_radius, 1740695150, godot_float, self)
}
void godot_CylinderMesh_set_bottom_radius(godot_CylinderMesh *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderMesh, set_bottom_radius, 373806689, void, self, &radius)
}
godot_float godot_CylinderMesh_get_bottom_radius(const godot_CylinderMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderMesh, get_bottom_radius, 1740695150, godot_float, self)
}
void godot_CylinderMesh_set_height(godot_CylinderMesh *self, godot_float height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderMesh, set_height, 373806689, void, self, &height)
}
godot_float godot_CylinderMesh_get_height(const godot_CylinderMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderMesh, get_height, 1740695150, godot_float, self)
}
void godot_CylinderMesh_set_radial_segments(godot_CylinderMesh *self, godot_int segments) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderMesh, set_radial_segments, 1286410249, void, self, &segments)
}
godot_int godot_CylinderMesh_get_radial_segments(const godot_CylinderMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderMesh, get_radial_segments, 3905245786, godot_int, self)
}
void godot_CylinderMesh_set_rings(godot_CylinderMesh *self, godot_int rings) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderMesh, set_rings, 1286410249, void, self, &rings)
}
godot_int godot_CylinderMesh_get_rings(const godot_CylinderMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderMesh, get_rings, 3905245786, godot_int, self)
}
void godot_CylinderMesh_set_cap_top(godot_CylinderMesh *self, godot_bool cap_top) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderMesh, set_cap_top, 2586408642, void, self, &cap_top)
}
godot_bool godot_CylinderMesh_is_cap_top(const godot_CylinderMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderMesh, is_cap_top, 36873697, godot_bool, self)
}
void godot_CylinderMesh_set_cap_bottom(godot_CylinderMesh *self, godot_bool cap_bottom) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderMesh, set_cap_bottom, 2586408642, void, self, &cap_bottom)
}
godot_bool godot_CylinderMesh_is_cap_bottom(const godot_CylinderMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderMesh, is_cap_bottom, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
