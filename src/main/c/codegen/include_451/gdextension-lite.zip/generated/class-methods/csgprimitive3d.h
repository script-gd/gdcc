// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGPRIMITIVE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGPRIMITIVE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL void godot_CSGPrimitive3D_set_flip_faces(godot_CSGPrimitive3D *self, godot_bool flip_faces);
GDEXTENSION_LITE_DECL godot_bool godot_CSGPrimitive3D_get_flip_faces(godot_CSGPrimitive3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGPRIMITIVE3D_H__
