// This file was automatically generated
// Do not modify this file
#include "canvas_item_material.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CanvasItemMaterial *godot_new_CanvasItemMaterial() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CanvasItemMaterial);
}

// Methods
void godot_CanvasItemMaterial_set_blend_mode(godot_CanvasItemMaterial *self, godot_CanvasItemMaterial_BlendMode blend_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItemMaterial, set_blend_mode, 1786054936, void, self, &blend_mode)
}
godot_CanvasItemMaterial_BlendMode godot_CanvasItemMaterial_get_blend_mode(const godot_CanvasItemMaterial *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItemMaterial, get_blend_mode, 3318684035, godot_CanvasItemMaterial_BlendMode, self)
}
void godot_CanvasItemMaterial_set_light_mode(godot_CanvasItemMaterial *self, godot_CanvasItemMaterial_LightMode light_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItemMaterial, set_light_mode, 628074070, void, self, &light_mode)
}
godot_CanvasItemMaterial_LightMode godot_CanvasItemMaterial_get_light_mode(const godot_CanvasItemMaterial *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItemMaterial, get_light_mode, 3863292382, godot_CanvasItemMaterial_LightMode, self)
}
void godot_CanvasItemMaterial_set_particles_animation(godot_CanvasItemMaterial *self, godot_bool particles_anim) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItemMaterial, set_particles_animation, 2586408642, void, self, &particles_anim)
}
godot_bool godot_CanvasItemMaterial_get_particles_animation(const godot_CanvasItemMaterial *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItemMaterial, get_particles_animation, 36873697, godot_bool, self)
}
void godot_CanvasItemMaterial_set_particles_anim_h_frames(godot_CanvasItemMaterial *self, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItemMaterial, set_particles_anim_h_frames, 1286410249, void, self, &frames)
}
godot_int godot_CanvasItemMaterial_get_particles_anim_h_frames(const godot_CanvasItemMaterial *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItemMaterial, get_particles_anim_h_frames, 3905245786, godot_int, self)
}
void godot_CanvasItemMaterial_set_particles_anim_v_frames(godot_CanvasItemMaterial *self, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItemMaterial, set_particles_anim_v_frames, 1286410249, void, self, &frames)
}
godot_int godot_CanvasItemMaterial_get_particles_anim_v_frames(const godot_CanvasItemMaterial *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItemMaterial, get_particles_anim_v_frames, 3905245786, godot_int, self)
}
void godot_CanvasItemMaterial_set_particles_anim_loop(godot_CanvasItemMaterial *self, godot_bool loop) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItemMaterial, set_particles_anim_loop, 2586408642, void, self, &loop)
}
godot_bool godot_CanvasItemMaterial_get_particles_anim_loop(const godot_CanvasItemMaterial *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItemMaterial, get_particles_anim_loop, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
