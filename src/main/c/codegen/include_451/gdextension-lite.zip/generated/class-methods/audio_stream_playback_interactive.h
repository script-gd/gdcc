// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_INTERACTIVE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_INTERACTIVE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaybackInteractive_switch_to_clip_by_name(godot_AudioStreamPlaybackInteractive *self, const godot_StringName *clip_name);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaybackInteractive_switch_to_clip(godot_AudioStreamPlaybackInteractive *self, godot_int clip_index);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPlaybackInteractive_get_current_clip_index(const godot_AudioStreamPlaybackInteractive *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_INTERACTIVE_H__
