// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_SPECTRUM_ANALYZER_INSTANCE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_SPECTRUM_ANALYZER_INSTANCE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL godot_Vector2 godot_AudioEffectSpectrumAnalyzerInstance_get_magnitude_for_frequency_range(const godot_AudioEffectSpectrumAnalyzerInstance *self, godot_float from_hz, godot_float to_hz, godot_AudioEffectSpectrumAnalyzerInstance_MagnitudeMode mode);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_SPECTRUM_ANALYZER_INSTANCE_H__
