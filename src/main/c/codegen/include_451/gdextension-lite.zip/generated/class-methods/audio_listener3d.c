// This file was automatically generated
// Do not modify this file
#include "audio_listener3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioListener3D *godot_new_AudioListener3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioListener3D);
}

// Methods
void godot_AudioListener3D_make_current(godot_AudioListener3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioListener3D, make_current, 3218959716, void, self)
}
void godot_AudioListener3D_clear_current(godot_AudioListener3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioListener3D, clear_current, 3218959716, void, self)
}
godot_bool godot_AudioListener3D_is_current(const godot_AudioListener3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioListener3D, is_current, 36873697, godot_bool, self)
}
godot_Transform3D godot_AudioListener3D_get_listener_transform(const godot_AudioListener3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioListener3D, get_listener_transform, 3229777777, godot_Transform3D, self)
}
void godot_AudioListener3D_set_doppler_tracking(godot_AudioListener3D *self, godot_AudioListener3D_DopplerTracking mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioListener3D, set_doppler_tracking, 2365921740, void, self, &mode)
}
godot_AudioListener3D_DopplerTracking godot_AudioListener3D_get_doppler_tracking(const godot_AudioListener3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioListener3D, get_doppler_tracking, 550229039, godot_AudioListener3D_DopplerTracking, self)
}


#ifdef __cplusplus
}
#endif
