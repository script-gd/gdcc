// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_ANIMATION_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_ANIMATION_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeAnimation *godot_new_AnimationNodeAnimation();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeAnimation_set_animation(godot_AnimationNodeAnimation *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimationNodeAnimation_get_animation(const godot_AnimationNodeAnimation *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeAnimation_set_play_mode(godot_AnimationNodeAnimation *self, godot_AnimationNodeAnimation_PlayMode mode);
GDEXTENSION_LITE_DECL godot_AnimationNodeAnimation_PlayMode godot_AnimationNodeAnimation_get_play_mode(const godot_AnimationNodeAnimation *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeAnimation_set_advance_on_start(godot_AnimationNodeAnimation *self, godot_bool advance_on_start);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeAnimation_is_advance_on_start(const godot_AnimationNodeAnimation *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeAnimation_set_use_custom_timeline(godot_AnimationNodeAnimation *self, godot_bool use_custom_timeline);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeAnimation_is_using_custom_timeline(const godot_AnimationNodeAnimation *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeAnimation_set_timeline_length(godot_AnimationNodeAnimation *self, godot_float timeline_length);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeAnimation_get_timeline_length(const godot_AnimationNodeAnimation *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeAnimation_set_stretch_time_scale(godot_AnimationNodeAnimation *self, godot_bool stretch_time_scale);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeAnimation_is_stretching_time_scale(const godot_AnimationNodeAnimation *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeAnimation_set_start_offset(godot_AnimationNodeAnimation *self, godot_float start_offset);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeAnimation_get_start_offset(const godot_AnimationNodeAnimation *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeAnimation_set_loop_mode(godot_AnimationNodeAnimation *self, godot_Animation_LoopMode loop_mode);
GDEXTENSION_LITE_DECL godot_Animation_LoopMode godot_AnimationNodeAnimation_get_loop_mode(const godot_AnimationNodeAnimation *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_ANIMATION_H__
