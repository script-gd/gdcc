// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_ATTRIBUTES_PHYSICAL_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_ATTRIBUTES_PHYSICAL_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CameraAttributesPhysical *godot_new_CameraAttributesPhysical();

// Methods
GDEXTENSION_LITE_DECL void godot_CameraAttributesPhysical_set_aperture(godot_CameraAttributesPhysical *self, godot_float aperture);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_aperture(const godot_CameraAttributesPhysical *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributesPhysical_set_shutter_speed(godot_CameraAttributesPhysical *self, godot_float shutter_speed);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_shutter_speed(const godot_CameraAttributesPhysical *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributesPhysical_set_focal_length(godot_CameraAttributesPhysical *self, godot_float focal_length);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_focal_length(const godot_CameraAttributesPhysical *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributesPhysical_set_focus_distance(godot_CameraAttributesPhysical *self, godot_float focus_distance);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_focus_distance(const godot_CameraAttributesPhysical *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributesPhysical_set_near(godot_CameraAttributesPhysical *self, godot_float near);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_near(const godot_CameraAttributesPhysical *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributesPhysical_set_far(godot_CameraAttributesPhysical *self, godot_float far);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_far(const godot_CameraAttributesPhysical *self);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_fov(const godot_CameraAttributesPhysical *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributesPhysical_set_auto_exposure_max_exposure_value(godot_CameraAttributesPhysical *self, godot_float exposure_value_max);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_auto_exposure_max_exposure_value(const godot_CameraAttributesPhysical *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributesPhysical_set_auto_exposure_min_exposure_value(godot_CameraAttributesPhysical *self, godot_float exposure_value_min);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributesPhysical_get_auto_exposure_min_exposure_value(const godot_CameraAttributesPhysical *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_ATTRIBUTES_PHYSICAL_H__
