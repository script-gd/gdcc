// This file was automatically generated
// Do not modify this file
#include "concave_polygon_shape3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ConcavePolygonShape3D *godot_new_ConcavePolygonShape3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ConcavePolygonShape3D);
}

// Methods
void godot_ConcavePolygonShape3D_set_faces(godot_ConcavePolygonShape3D *self, const godot_PackedVector3Array *faces) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConcavePolygonShape3D, set_faces, 334873810, void, self, faces)
}
godot_PackedVector3Array godot_ConcavePolygonShape3D_get_faces(const godot_ConcavePolygonShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConcavePolygonShape3D, get_faces, 497664490, godot_PackedVector3Array, self)
}
void godot_ConcavePolygonShape3D_set_backface_collision_enabled(godot_ConcavePolygonShape3D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConcavePolygonShape3D, set_backface_collision_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_ConcavePolygonShape3D_is_backface_collision_enabled(const godot_ConcavePolygonShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConcavePolygonShape3D, is_backface_collision_enabled, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
