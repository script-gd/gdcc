// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_DIRECTORY_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_DIRECTORY_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorFileSystemDirectory *godot_new_EditorFileSystemDirectory();

// Methods
GDEXTENSION_LITE_DECL godot_int godot_EditorFileSystemDirectory_get_subdir_count(const godot_EditorFileSystemDirectory *self);
GDEXTENSION_LITE_DECL godot_EditorFileSystemDirectory * godot_EditorFileSystemDirectory_get_subdir(godot_EditorFileSystemDirectory *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_int godot_EditorFileSystemDirectory_get_file_count(const godot_EditorFileSystemDirectory *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileSystemDirectory_get_file(const godot_EditorFileSystemDirectory *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileSystemDirectory_get_file_path(const godot_EditorFileSystemDirectory *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_StringName godot_EditorFileSystemDirectory_get_file_type(const godot_EditorFileSystemDirectory *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileSystemDirectory_get_file_script_class_name(const godot_EditorFileSystemDirectory *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileSystemDirectory_get_file_script_class_extends(const godot_EditorFileSystemDirectory *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFileSystemDirectory_get_file_import_is_valid(const godot_EditorFileSystemDirectory *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileSystemDirectory_get_name(godot_EditorFileSystemDirectory *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileSystemDirectory_get_path(const godot_EditorFileSystemDirectory *self);
GDEXTENSION_LITE_DECL godot_EditorFileSystemDirectory * godot_EditorFileSystemDirectory_get_parent(godot_EditorFileSystemDirectory *self);
GDEXTENSION_LITE_DECL godot_int godot_EditorFileSystemDirectory_find_file_index(const godot_EditorFileSystemDirectory *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_int godot_EditorFileSystemDirectory_find_dir_index(const godot_EditorFileSystemDirectory *self, const godot_String *name);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_DIRECTORY_H__
