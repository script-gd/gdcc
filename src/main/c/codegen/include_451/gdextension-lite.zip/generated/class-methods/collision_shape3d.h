// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_SHAPE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_SHAPE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CollisionShape3D *godot_new_CollisionShape3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CollisionShape3D_resource_changed(godot_CollisionShape3D *self, const godot_Resource *resource);
GDEXTENSION_LITE_DECL void godot_CollisionShape3D_set_shape(godot_CollisionShape3D *self, const godot_Shape3D *shape);
GDEXTENSION_LITE_DECL godot_Shape3D * godot_CollisionShape3D_get_shape(const godot_CollisionShape3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionShape3D_set_disabled(godot_CollisionShape3D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionShape3D_is_disabled(const godot_CollisionShape3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionShape3D_make_convex_from_siblings(godot_CollisionShape3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionShape3D_set_debug_color(godot_CollisionShape3D *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CollisionShape3D_get_debug_color(const godot_CollisionShape3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionShape3D_set_enable_debug_fill(godot_CollisionShape3D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionShape3D_get_enable_debug_fill(const godot_CollisionShape3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_SHAPE3D_H__
