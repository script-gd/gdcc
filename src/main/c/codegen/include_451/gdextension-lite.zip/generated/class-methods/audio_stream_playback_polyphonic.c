// This file was automatically generated
// Do not modify this file
#include "audio_stream_playback_polyphonic.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_int godot_AudioStreamPlaybackPolyphonic_play_stream(godot_AudioStreamPlaybackPolyphonic *self, const godot_AudioStream *stream, godot_float from_offset, godot_float volume_db, godot_float pitch_scale, godot_AudioServer_PlaybackType playback_type, const godot_StringName *bus) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaybackPolyphonic, play_stream, 1846744803, godot_int, self, stream, &from_offset, &volume_db, &pitch_scale, &playback_type, bus)
}
void godot_AudioStreamPlaybackPolyphonic_set_stream_volume(godot_AudioStreamPlaybackPolyphonic *self, godot_int stream, godot_float volume_db) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaybackPolyphonic, set_stream_volume, 1602489585, void, self, &stream, &volume_db)
}
void godot_AudioStreamPlaybackPolyphonic_set_stream_pitch_scale(godot_AudioStreamPlaybackPolyphonic *self, godot_int stream, godot_float pitch_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaybackPolyphonic, set_stream_pitch_scale, 1602489585, void, self, &stream, &pitch_scale)
}
godot_bool godot_AudioStreamPlaybackPolyphonic_is_stream_playing(const godot_AudioStreamPlaybackPolyphonic *self, godot_int stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaybackPolyphonic, is_stream_playing, 1116898809, godot_bool, self, &stream)
}
void godot_AudioStreamPlaybackPolyphonic_stop_stream(godot_AudioStreamPlaybackPolyphonic *self, godot_int stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaybackPolyphonic, stop_stream, 1286410249, void, self, &stream)
}


#ifdef __cplusplus
}
#endif
