// This file was automatically generated
// Do not modify this file
#include "audio_stream_playback_ogg_vorbis.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamPlaybackOggVorbis *godot_new_AudioStreamPlaybackOggVorbis() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamPlaybackOggVorbis);
}


#ifdef __cplusplus
}
#endif
