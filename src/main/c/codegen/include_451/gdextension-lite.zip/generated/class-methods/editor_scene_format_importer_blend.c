// This file was automatically generated
// Do not modify this file
#include "editor_scene_format_importer_blend.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorSceneFormatImporterBlend *godot_new_EditorSceneFormatImporterBlend() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorSceneFormatImporterBlend);
}


#ifdef __cplusplus
}
#endif
