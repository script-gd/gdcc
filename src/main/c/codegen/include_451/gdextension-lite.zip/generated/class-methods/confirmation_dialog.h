// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONFIRMATION_DIALOG_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONFIRMATION_DIALOG_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ConfirmationDialog *godot_new_ConfirmationDialog();

// Methods
GDEXTENSION_LITE_DECL godot_Button * godot_ConfirmationDialog_get_cancel_button(godot_ConfirmationDialog *self);
GDEXTENSION_LITE_DECL void godot_ConfirmationDialog_set_cancel_button_text(godot_ConfirmationDialog *self, const godot_String *text);
GDEXTENSION_LITE_DECL godot_String godot_ConfirmationDialog_get_cancel_button_text(const godot_ConfirmationDialog *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONFIRMATION_DIALOG_H__
