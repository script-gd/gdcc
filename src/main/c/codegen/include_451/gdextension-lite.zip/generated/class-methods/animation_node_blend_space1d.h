// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_BLEND_SPACE1D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_BLEND_SPACE1D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeBlendSpace1D *godot_new_AnimationNodeBlendSpace1D();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_add_blend_point(godot_AnimationNodeBlendSpace1D *self, const godot_AnimationRootNode *node, godot_float pos, godot_int at_index);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_set_blend_point_position(godot_AnimationNodeBlendSpace1D *self, godot_int point, godot_float pos);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeBlendSpace1D_get_blend_point_position(const godot_AnimationNodeBlendSpace1D *self, godot_int point);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_set_blend_point_node(godot_AnimationNodeBlendSpace1D *self, godot_int point, const godot_AnimationRootNode *node);
GDEXTENSION_LITE_DECL godot_AnimationRootNode * godot_AnimationNodeBlendSpace1D_get_blend_point_node(const godot_AnimationNodeBlendSpace1D *self, godot_int point);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_remove_blend_point(godot_AnimationNodeBlendSpace1D *self, godot_int point);
GDEXTENSION_LITE_DECL godot_int godot_AnimationNodeBlendSpace1D_get_blend_point_count(const godot_AnimationNodeBlendSpace1D *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_set_min_space(godot_AnimationNodeBlendSpace1D *self, godot_float min_space);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeBlendSpace1D_get_min_space(const godot_AnimationNodeBlendSpace1D *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_set_max_space(godot_AnimationNodeBlendSpace1D *self, godot_float max_space);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeBlendSpace1D_get_max_space(const godot_AnimationNodeBlendSpace1D *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_set_snap(godot_AnimationNodeBlendSpace1D *self, godot_float snap);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeBlendSpace1D_get_snap(const godot_AnimationNodeBlendSpace1D *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_set_value_label(godot_AnimationNodeBlendSpace1D *self, const godot_String *text);
GDEXTENSION_LITE_DECL godot_String godot_AnimationNodeBlendSpace1D_get_value_label(const godot_AnimationNodeBlendSpace1D *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_set_blend_mode(godot_AnimationNodeBlendSpace1D *self, godot_AnimationNodeBlendSpace1D_BlendMode mode);
GDEXTENSION_LITE_DECL godot_AnimationNodeBlendSpace1D_BlendMode godot_AnimationNodeBlendSpace1D_get_blend_mode(const godot_AnimationNodeBlendSpace1D *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeBlendSpace1D_set_use_sync(godot_AnimationNodeBlendSpace1D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeBlendSpace1D_is_using_sync(const godot_AnimationNodeBlendSpace1D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_BLEND_SPACE1D_H__
