// This file was automatically generated
// Do not modify this file
#include "audio_effect_reverb.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectReverb *godot_new_AudioEffectReverb() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectReverb);
}

// Methods
void godot_AudioEffectReverb_set_predelay_msec(godot_AudioEffectReverb *self, godot_float msec) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectReverb, set_predelay_msec, 373806689, void, self, &msec)
}
godot_float godot_AudioEffectReverb_get_predelay_msec(const godot_AudioEffectReverb *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectReverb, get_predelay_msec, 1740695150, godot_float, self)
}
void godot_AudioEffectReverb_set_predelay_feedback(godot_AudioEffectReverb *self, godot_float feedback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectReverb, set_predelay_feedback, 373806689, void, self, &feedback)
}
godot_float godot_AudioEffectReverb_get_predelay_feedback(const godot_AudioEffectReverb *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectReverb, get_predelay_feedback, 1740695150, godot_float, self)
}
void godot_AudioEffectReverb_set_room_size(godot_AudioEffectReverb *self, godot_float size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectReverb, set_room_size, 373806689, void, self, &size)
}
godot_float godot_AudioEffectReverb_get_room_size(const godot_AudioEffectReverb *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectReverb, get_room_size, 1740695150, godot_float, self)
}
void godot_AudioEffectReverb_set_damping(godot_AudioEffectReverb *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectReverb, set_damping, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectReverb_get_damping(const godot_AudioEffectReverb *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectReverb, get_damping, 1740695150, godot_float, self)
}
void godot_AudioEffectReverb_set_spread(godot_AudioEffectReverb *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectReverb, set_spread, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectReverb_get_spread(const godot_AudioEffectReverb *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectReverb, get_spread, 1740695150, godot_float, self)
}
void godot_AudioEffectReverb_set_dry(godot_AudioEffectReverb *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectReverb, set_dry, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectReverb_get_dry(const godot_AudioEffectReverb *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectReverb, get_dry, 1740695150, godot_float, self)
}
void godot_AudioEffectReverb_set_wet(godot_AudioEffectReverb *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectReverb, set_wet, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectReverb_get_wet(const godot_AudioEffectReverb *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectReverb, get_wet, 1740695150, godot_float, self)
}
void godot_AudioEffectReverb_set_hpf(godot_AudioEffectReverb *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectReverb, set_hpf, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectReverb_get_hpf(const godot_AudioEffectReverb *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectReverb, get_hpf, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
