// This file was automatically generated
// Do not modify this file
#include "container.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Container *godot_new_Container() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Container);
}

// Methods
godot_PackedInt32Array godot_Container__get_allowed_size_flags_horizontal(const godot_Container *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Container, _get_allowed_size_flags_horizontal, 1930428628, godot_PackedInt32Array, self)
}
godot_PackedInt32Array godot_Container__get_allowed_size_flags_vertical(const godot_Container *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Container, _get_allowed_size_flags_vertical, 1930428628, godot_PackedInt32Array, self)
}
void godot_Container_queue_sort(godot_Container *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Container, queue_sort, 3218959716, void, self)
}
void godot_Container_fit_child_in_rect(godot_Container *self, const godot_Control *child, const godot_Rect2 *rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Container, fit_child_in_rect, 1993438598, void, self, child, rect)
}


#ifdef __cplusplus
}
#endif
