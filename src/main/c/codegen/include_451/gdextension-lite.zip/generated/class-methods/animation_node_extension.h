// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_EXTENSION_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_EXTENSION_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeExtension *godot_new_AnimationNodeExtension();

// Methods
GDEXTENSION_LITE_DECL godot_PackedFloat32Array godot_AnimationNodeExtension__process_animation_node(godot_AnimationNodeExtension *self, const godot_PackedFloat64Array *playback_info, godot_bool test_only);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeExtension_is_looping(const godot_PackedFloat32Array *node_info);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeExtension_get_remaining_time(const godot_PackedFloat32Array *node_info, godot_bool break_loop);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_EXTENSION_H__
