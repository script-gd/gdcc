// This file was automatically generated
// Do not modify this file
#include "collision_polygon2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CollisionPolygon2D *godot_new_CollisionPolygon2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CollisionPolygon2D);
}

// Methods
void godot_CollisionPolygon2D_set_polygon(godot_CollisionPolygon2D *self, const godot_PackedVector2Array *polygon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon2D, set_polygon, 1509147220, void, self, polygon)
}
godot_PackedVector2Array godot_CollisionPolygon2D_get_polygon(const godot_CollisionPolygon2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon2D, get_polygon, 2961356807, godot_PackedVector2Array, self)
}
void godot_CollisionPolygon2D_set_build_mode(godot_CollisionPolygon2D *self, godot_CollisionPolygon2D_BuildMode build_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon2D, set_build_mode, 2780803135, void, self, &build_mode)
}
godot_CollisionPolygon2D_BuildMode godot_CollisionPolygon2D_get_build_mode(const godot_CollisionPolygon2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon2D, get_build_mode, 3044948800, godot_CollisionPolygon2D_BuildMode, self)
}
void godot_CollisionPolygon2D_set_disabled(godot_CollisionPolygon2D *self, godot_bool disabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon2D, set_disabled, 2586408642, void, self, &disabled)
}
godot_bool godot_CollisionPolygon2D_is_disabled(const godot_CollisionPolygon2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon2D, is_disabled, 36873697, godot_bool, self)
}
void godot_CollisionPolygon2D_set_one_way_collision(godot_CollisionPolygon2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon2D, set_one_way_collision, 2586408642, void, self, &enabled)
}
godot_bool godot_CollisionPolygon2D_is_one_way_collision_enabled(const godot_CollisionPolygon2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon2D, is_one_way_collision_enabled, 36873697, godot_bool, self)
}
void godot_CollisionPolygon2D_set_one_way_collision_margin(godot_CollisionPolygon2D *self, godot_float margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon2D, set_one_way_collision_margin, 373806689, void, self, &margin)
}
godot_float godot_CollisionPolygon2D_get_one_way_collision_margin(const godot_CollisionPolygon2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon2D, get_one_way_collision_margin, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
