// This file was automatically generated
// Do not modify this file
#include "audio_stream_randomizer.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamRandomizer *godot_new_AudioStreamRandomizer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamRandomizer);
}

// Methods
void godot_AudioStreamRandomizer_add_stream(godot_AudioStreamRandomizer *self, godot_int index, const godot_AudioStream *stream, godot_float weight) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, add_stream, 1892018854, void, self, &index, stream, &weight)
}
void godot_AudioStreamRandomizer_move_stream(godot_AudioStreamRandomizer *self, godot_int index_from, godot_int index_to) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, move_stream, 3937882851, void, self, &index_from, &index_to)
}
void godot_AudioStreamRandomizer_remove_stream(godot_AudioStreamRandomizer *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, remove_stream, 1286410249, void, self, &index)
}
void godot_AudioStreamRandomizer_set_stream(godot_AudioStreamRandomizer *self, godot_int index, const godot_AudioStream *stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, set_stream, 111075094, void, self, &index, stream)
}
godot_AudioStream * godot_AudioStreamRandomizer_get_stream(const godot_AudioStreamRandomizer *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamRandomizer, get_stream, 2739380747, godot_AudioStream *, self, &index)
}
void godot_AudioStreamRandomizer_set_stream_probability_weight(godot_AudioStreamRandomizer *self, godot_int index, godot_float weight) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, set_stream_probability_weight, 1602489585, void, self, &index, &weight)
}
godot_float godot_AudioStreamRandomizer_get_stream_probability_weight(const godot_AudioStreamRandomizer *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamRandomizer, get_stream_probability_weight, 2339986948, godot_float, self, &index)
}
void godot_AudioStreamRandomizer_set_streams_count(godot_AudioStreamRandomizer *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, set_streams_count, 1286410249, void, self, &count)
}
godot_int godot_AudioStreamRandomizer_get_streams_count(const godot_AudioStreamRandomizer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamRandomizer, get_streams_count, 3905245786, godot_int, self)
}
void godot_AudioStreamRandomizer_set_random_pitch(godot_AudioStreamRandomizer *self, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, set_random_pitch, 373806689, void, self, &scale)
}
godot_float godot_AudioStreamRandomizer_get_random_pitch(const godot_AudioStreamRandomizer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamRandomizer, get_random_pitch, 1740695150, godot_float, self)
}
void godot_AudioStreamRandomizer_set_random_volume_offset_db(godot_AudioStreamRandomizer *self, godot_float db_offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, set_random_volume_offset_db, 373806689, void, self, &db_offset)
}
godot_float godot_AudioStreamRandomizer_get_random_volume_offset_db(const godot_AudioStreamRandomizer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamRandomizer, get_random_volume_offset_db, 1740695150, godot_float, self)
}
void godot_AudioStreamRandomizer_set_playback_mode(godot_AudioStreamRandomizer *self, godot_AudioStreamRandomizer_PlaybackMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamRandomizer, set_playback_mode, 3950967023, void, self, &mode)
}
godot_AudioStreamRandomizer_PlaybackMode godot_AudioStreamRandomizer_get_playback_mode(const godot_AudioStreamRandomizer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamRandomizer, get_playback_mode, 3943055077, godot_AudioStreamRandomizer_PlaybackMode, self)
}


#ifdef __cplusplus
}
#endif
