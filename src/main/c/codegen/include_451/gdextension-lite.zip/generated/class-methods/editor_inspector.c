// This file was automatically generated
// Do not modify this file
#include "editor_inspector.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorInspector *godot_new_EditorInspector() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorInspector);
}

// Methods
void godot_EditorInspector_edit(godot_EditorInspector *self, const godot_Object *object) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInspector, edit, 3975164845, void, self, object)
}
godot_String godot_EditorInspector_get_selected_path(const godot_EditorInspector *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInspector, get_selected_path, 201670096, godot_String, self)
}
godot_Object * godot_EditorInspector_get_edited_object(godot_EditorInspector *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInspector, get_edited_object, 2050059866, godot_Object *, self)
}
godot_EditorProperty * godot_EditorInspector_instantiate_property_editor(const godot_Object *object, godot_Variant_Type type, const godot_String *path, godot_PropertyHint hint, const godot_String *hint_text, godot_int usage, godot_bool wide) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInspector, instantiate_property_editor, 1429914152, godot_EditorProperty *, NULL, object, &type, path, &hint, hint_text, &usage, &wide)
}


#ifdef __cplusplus
}
#endif
