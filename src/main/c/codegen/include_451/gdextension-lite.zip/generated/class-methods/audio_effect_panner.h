// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PANNER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PANNER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectPanner *godot_new_AudioEffectPanner();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectPanner_set_pan(godot_AudioEffectPanner *self, godot_float cpanume);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectPanner_get_pan(const godot_AudioEffectPanner *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PANNER_H__
