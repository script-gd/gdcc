// This file was automatically generated
// Do not modify this file
#include "accept_dialog.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AcceptDialog *godot_new_AcceptDialog() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AcceptDialog);
}

// Methods
godot_Button * godot_AcceptDialog_get_ok_button(godot_AcceptDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, get_ok_button, 1856205918, godot_Button *, self)
}
godot_Label * godot_AcceptDialog_get_label(godot_AcceptDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, get_label, 566733104, godot_Label *, self)
}
void godot_AcceptDialog_set_hide_on_ok(godot_AcceptDialog *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AcceptDialog, set_hide_on_ok, 2586408642, void, self, &enabled)
}
godot_bool godot_AcceptDialog_get_hide_on_ok(const godot_AcceptDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, get_hide_on_ok, 36873697, godot_bool, self)
}
void godot_AcceptDialog_set_close_on_escape(godot_AcceptDialog *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AcceptDialog, set_close_on_escape, 2586408642, void, self, &enabled)
}
godot_bool godot_AcceptDialog_get_close_on_escape(const godot_AcceptDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, get_close_on_escape, 36873697, godot_bool, self)
}
godot_Button * godot_AcceptDialog_add_button(godot_AcceptDialog *self, const godot_String *text, godot_bool right, const godot_String *action) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, add_button, 3328440682, godot_Button *, self, text, &right, action)
}
godot_Button * godot_AcceptDialog_add_cancel_button(godot_AcceptDialog *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, add_cancel_button, 242045556, godot_Button *, self, name)
}
void godot_AcceptDialog_remove_button(godot_AcceptDialog *self, const godot_Button *button) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AcceptDialog, remove_button, 2068354942, void, self, button)
}
void godot_AcceptDialog_register_text_enter(godot_AcceptDialog *self, const godot_LineEdit *line_edit) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AcceptDialog, register_text_enter, 3714008017, void, self, line_edit)
}
void godot_AcceptDialog_set_text(godot_AcceptDialog *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AcceptDialog, set_text, 83702148, void, self, text)
}
godot_String godot_AcceptDialog_get_text(const godot_AcceptDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, get_text, 201670096, godot_String, self)
}
void godot_AcceptDialog_set_autowrap(godot_AcceptDialog *self, godot_bool autowrap) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AcceptDialog, set_autowrap, 2586408642, void, self, &autowrap)
}
godot_bool godot_AcceptDialog_has_autowrap(godot_AcceptDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, has_autowrap, 2240911060, godot_bool, self)
}
void godot_AcceptDialog_set_ok_button_text(godot_AcceptDialog *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AcceptDialog, set_ok_button_text, 83702148, void, self, text)
}
godot_String godot_AcceptDialog_get_ok_button_text(const godot_AcceptDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AcceptDialog, get_ok_button_text, 201670096, godot_String, self)
}


#ifdef __cplusplus
}
#endif
