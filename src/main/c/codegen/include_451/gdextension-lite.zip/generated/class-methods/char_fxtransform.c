// This file was automatically generated
// Do not modify this file
#include "char_fxtransform.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CharFXTransform *godot_new_CharFXTransform() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CharFXTransform);
}

// Methods
godot_Transform2D godot_CharFXTransform_get_transform(godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_transform, 3761352769, godot_Transform2D, self)
}
void godot_CharFXTransform_set_transform(godot_CharFXTransform *self, const godot_Transform2D *transform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_transform, 2761652528, void, self, transform)
}
godot_Vector2i godot_CharFXTransform_get_range(godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_range, 2741790807, godot_Vector2i, self)
}
void godot_CharFXTransform_set_range(godot_CharFXTransform *self, const godot_Vector2i *range) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_range, 1130785943, void, self, range)
}
godot_float godot_CharFXTransform_get_elapsed_time(godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_elapsed_time, 191475506, godot_float, self)
}
void godot_CharFXTransform_set_elapsed_time(godot_CharFXTransform *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_elapsed_time, 373806689, void, self, &time)
}
godot_bool godot_CharFXTransform_is_visible(godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, is_visible, 2240911060, godot_bool, self)
}
void godot_CharFXTransform_set_visibility(godot_CharFXTransform *self, godot_bool visibility) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_visibility, 2586408642, void, self, &visibility)
}
godot_bool godot_CharFXTransform_is_outline(godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, is_outline, 2240911060, godot_bool, self)
}
void godot_CharFXTransform_set_outline(godot_CharFXTransform *self, godot_bool outline) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_outline, 2586408642, void, self, &outline)
}
godot_Vector2 godot_CharFXTransform_get_offset(godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_offset, 1497962370, godot_Vector2, self)
}
void godot_CharFXTransform_set_offset(godot_CharFXTransform *self, const godot_Vector2 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_offset, 743155724, void, self, offset)
}
godot_Color godot_CharFXTransform_get_color(godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_color, 3200896285, godot_Color, self)
}
void godot_CharFXTransform_set_color(godot_CharFXTransform *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_color, 2920490490, void, self, color)
}
godot_Dictionary godot_CharFXTransform_get_environment(godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_environment, 2382534195, godot_Dictionary, self)
}
void godot_CharFXTransform_set_environment(godot_CharFXTransform *self, const godot_Dictionary *environment) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_environment, 4155329257, void, self, environment)
}
godot_int godot_CharFXTransform_get_glyph_index(const godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_glyph_index, 3905245786, godot_int, self)
}
void godot_CharFXTransform_set_glyph_index(godot_CharFXTransform *self, godot_int glyph_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_glyph_index, 1286410249, void, self, &glyph_index)
}
godot_int godot_CharFXTransform_get_relative_index(const godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_relative_index, 3905245786, godot_int, self)
}
void godot_CharFXTransform_set_relative_index(godot_CharFXTransform *self, godot_int relative_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_relative_index, 1286410249, void, self, &relative_index)
}
godot_int godot_CharFXTransform_get_glyph_count(const godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_glyph_count, 3905245786, godot_int, self)
}
void godot_CharFXTransform_set_glyph_count(godot_CharFXTransform *self, godot_int glyph_count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_glyph_count, 1286410249, void, self, &glyph_count)
}
godot_int godot_CharFXTransform_get_glyph_flags(const godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_glyph_flags, 3905245786, godot_int, self)
}
void godot_CharFXTransform_set_glyph_flags(godot_CharFXTransform *self, godot_int glyph_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_glyph_flags, 1286410249, void, self, &glyph_flags)
}
godot_RID godot_CharFXTransform_get_font(const godot_CharFXTransform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharFXTransform, get_font, 2944877500, godot_RID, self)
}
void godot_CharFXTransform_set_font(godot_CharFXTransform *self, const godot_RID *font) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharFXTransform, set_font, 2722037293, void, self, font)
}


#ifdef __cplusplus
}
#endif
