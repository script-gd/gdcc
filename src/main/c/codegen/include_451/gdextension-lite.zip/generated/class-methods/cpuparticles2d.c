// This file was automatically generated
// Do not modify this file
#include "cpuparticles2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CPUParticles2D *godot_new_CPUParticles2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CPUParticles2D);
}

// Methods
void godot_CPUParticles2D_set_emitting(godot_CPUParticles2D *self, godot_bool emitting) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_emitting, 2586408642, void, self, &emitting)
}
void godot_CPUParticles2D_set_amount(godot_CPUParticles2D *self, godot_int amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_amount, 1286410249, void, self, &amount)
}
void godot_CPUParticles2D_set_lifetime(godot_CPUParticles2D *self, godot_float secs) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_lifetime, 373806689, void, self, &secs)
}
void godot_CPUParticles2D_set_one_shot(godot_CPUParticles2D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_one_shot, 2586408642, void, self, &enable)
}
void godot_CPUParticles2D_set_pre_process_time(godot_CPUParticles2D *self, godot_float secs) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_pre_process_time, 373806689, void, self, &secs)
}
void godot_CPUParticles2D_set_explosiveness_ratio(godot_CPUParticles2D *self, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_explosiveness_ratio, 373806689, void, self, &ratio)
}
void godot_CPUParticles2D_set_randomness_ratio(godot_CPUParticles2D *self, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_randomness_ratio, 373806689, void, self, &ratio)
}
void godot_CPUParticles2D_set_lifetime_randomness(godot_CPUParticles2D *self, godot_float random) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_lifetime_randomness, 373806689, void, self, &random)
}
void godot_CPUParticles2D_set_use_local_coordinates(godot_CPUParticles2D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_use_local_coordinates, 2586408642, void, self, &enable)
}
void godot_CPUParticles2D_set_fixed_fps(godot_CPUParticles2D *self, godot_int fps) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_fixed_fps, 1286410249, void, self, &fps)
}
void godot_CPUParticles2D_set_fractional_delta(godot_CPUParticles2D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_fractional_delta, 2586408642, void, self, &enable)
}
void godot_CPUParticles2D_set_speed_scale(godot_CPUParticles2D *self, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_speed_scale, 373806689, void, self, &scale)
}
void godot_CPUParticles2D_request_particles_process(godot_CPUParticles2D *self, godot_float process_time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, request_particles_process, 373806689, void, self, &process_time)
}
godot_bool godot_CPUParticles2D_is_emitting(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, is_emitting, 36873697, godot_bool, self)
}
godot_int godot_CPUParticles2D_get_amount(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_amount, 3905245786, godot_int, self)
}
godot_float godot_CPUParticles2D_get_lifetime(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_lifetime, 1740695150, godot_float, self)
}
godot_bool godot_CPUParticles2D_get_one_shot(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_one_shot, 36873697, godot_bool, self)
}
godot_float godot_CPUParticles2D_get_pre_process_time(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_pre_process_time, 1740695150, godot_float, self)
}
godot_float godot_CPUParticles2D_get_explosiveness_ratio(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_explosiveness_ratio, 1740695150, godot_float, self)
}
godot_float godot_CPUParticles2D_get_randomness_ratio(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_randomness_ratio, 1740695150, godot_float, self)
}
godot_float godot_CPUParticles2D_get_lifetime_randomness(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_lifetime_randomness, 1740695150, godot_float, self)
}
godot_bool godot_CPUParticles2D_get_use_local_coordinates(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_use_local_coordinates, 36873697, godot_bool, self)
}
godot_int godot_CPUParticles2D_get_fixed_fps(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_fixed_fps, 3905245786, godot_int, self)
}
godot_bool godot_CPUParticles2D_get_fractional_delta(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_fractional_delta, 36873697, godot_bool, self)
}
godot_float godot_CPUParticles2D_get_speed_scale(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_speed_scale, 1740695150, godot_float, self)
}
void godot_CPUParticles2D_set_use_fixed_seed(godot_CPUParticles2D *self, godot_bool use_fixed_seed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_use_fixed_seed, 2586408642, void, self, &use_fixed_seed)
}
godot_bool godot_CPUParticles2D_get_use_fixed_seed(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_use_fixed_seed, 36873697, godot_bool, self)
}
void godot_CPUParticles2D_set_seed(godot_CPUParticles2D *self, godot_int seed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_seed, 1286410249, void, self, &seed)
}
godot_int godot_CPUParticles2D_get_seed(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_seed, 3905245786, godot_int, self)
}
void godot_CPUParticles2D_set_draw_order(godot_CPUParticles2D *self, godot_CPUParticles2D_DrawOrder order) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_draw_order, 4183193490, void, self, &order)
}
godot_CPUParticles2D_DrawOrder godot_CPUParticles2D_get_draw_order(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_draw_order, 1668655735, godot_CPUParticles2D_DrawOrder, self)
}
void godot_CPUParticles2D_set_texture(godot_CPUParticles2D *self, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_texture, 4051416890, void, self, texture)
}
godot_Texture2D * godot_CPUParticles2D_get_texture(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_texture, 3635182373, godot_Texture2D *, self)
}
void godot_CPUParticles2D_restart(godot_CPUParticles2D *self, godot_bool keep_seed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, restart, 107499316, void, self, &keep_seed)
}
void godot_CPUParticles2D_set_direction(godot_CPUParticles2D *self, const godot_Vector2 *direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_direction, 743155724, void, self, direction)
}
godot_Vector2 godot_CPUParticles2D_get_direction(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_direction, 3341600327, godot_Vector2, self)
}
void godot_CPUParticles2D_set_spread(godot_CPUParticles2D *self, godot_float spread) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_spread, 373806689, void, self, &spread)
}
godot_float godot_CPUParticles2D_get_spread(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_spread, 1740695150, godot_float, self)
}
void godot_CPUParticles2D_set_param_min(godot_CPUParticles2D *self, godot_CPUParticles2D_Parameter param, godot_float value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_param_min, 3320615296, void, self, &param, &value)
}
godot_float godot_CPUParticles2D_get_param_min(const godot_CPUParticles2D *self, godot_CPUParticles2D_Parameter param) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_param_min, 2038050600, godot_float, self, &param)
}
void godot_CPUParticles2D_set_param_max(godot_CPUParticles2D *self, godot_CPUParticles2D_Parameter param, godot_float value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_param_max, 3320615296, void, self, &param, &value)
}
godot_float godot_CPUParticles2D_get_param_max(const godot_CPUParticles2D *self, godot_CPUParticles2D_Parameter param) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_param_max, 2038050600, godot_float, self, &param)
}
void godot_CPUParticles2D_set_param_curve(godot_CPUParticles2D *self, godot_CPUParticles2D_Parameter param, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_param_curve, 2959350143, void, self, &param, curve)
}
godot_Curve * godot_CPUParticles2D_get_param_curve(const godot_CPUParticles2D *self, godot_CPUParticles2D_Parameter param) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_param_curve, 2603158474, godot_Curve *, self, &param)
}
void godot_CPUParticles2D_set_color(godot_CPUParticles2D *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_color, 2920490490, void, self, color)
}
godot_Color godot_CPUParticles2D_get_color(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_color, 3444240500, godot_Color, self)
}
void godot_CPUParticles2D_set_color_ramp(godot_CPUParticles2D *self, const godot_Gradient *ramp) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_color_ramp, 2756054477, void, self, ramp)
}
godot_Gradient * godot_CPUParticles2D_get_color_ramp(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_color_ramp, 132272999, godot_Gradient *, self)
}
void godot_CPUParticles2D_set_color_initial_ramp(godot_CPUParticles2D *self, const godot_Gradient *ramp) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_color_initial_ramp, 2756054477, void, self, ramp)
}
godot_Gradient * godot_CPUParticles2D_get_color_initial_ramp(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_color_initial_ramp, 132272999, godot_Gradient *, self)
}
void godot_CPUParticles2D_set_particle_flag(godot_CPUParticles2D *self, godot_CPUParticles2D_ParticleFlags particle_flag, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_particle_flag, 4178137949, void, self, &particle_flag, &enable)
}
godot_bool godot_CPUParticles2D_get_particle_flag(const godot_CPUParticles2D *self, godot_CPUParticles2D_ParticleFlags particle_flag) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_particle_flag, 2829976507, godot_bool, self, &particle_flag)
}
void godot_CPUParticles2D_set_emission_shape(godot_CPUParticles2D *self, godot_CPUParticles2D_EmissionShape shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_emission_shape, 393763892, void, self, &shape)
}
godot_CPUParticles2D_EmissionShape godot_CPUParticles2D_get_emission_shape(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_emission_shape, 1740246024, godot_CPUParticles2D_EmissionShape, self)
}
void godot_CPUParticles2D_set_emission_sphere_radius(godot_CPUParticles2D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_emission_sphere_radius, 373806689, void, self, &radius)
}
godot_float godot_CPUParticles2D_get_emission_sphere_radius(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_emission_sphere_radius, 1740695150, godot_float, self)
}
void godot_CPUParticles2D_set_emission_rect_extents(godot_CPUParticles2D *self, const godot_Vector2 *extents) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_emission_rect_extents, 743155724, void, self, extents)
}
godot_Vector2 godot_CPUParticles2D_get_emission_rect_extents(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_emission_rect_extents, 3341600327, godot_Vector2, self)
}
void godot_CPUParticles2D_set_emission_points(godot_CPUParticles2D *self, const godot_PackedVector2Array *array) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_emission_points, 1509147220, void, self, array)
}
godot_PackedVector2Array godot_CPUParticles2D_get_emission_points(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_emission_points, 2961356807, godot_PackedVector2Array, self)
}
void godot_CPUParticles2D_set_emission_normals(godot_CPUParticles2D *self, const godot_PackedVector2Array *array) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_emission_normals, 1509147220, void, self, array)
}
godot_PackedVector2Array godot_CPUParticles2D_get_emission_normals(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_emission_normals, 2961356807, godot_PackedVector2Array, self)
}
void godot_CPUParticles2D_set_emission_colors(godot_CPUParticles2D *self, const godot_PackedColorArray *array) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_emission_colors, 3546319833, void, self, array)
}
godot_PackedColorArray godot_CPUParticles2D_get_emission_colors(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_emission_colors, 1392750486, godot_PackedColorArray, self)
}
godot_Vector2 godot_CPUParticles2D_get_gravity(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_gravity, 3341600327, godot_Vector2, self)
}
void godot_CPUParticles2D_set_gravity(godot_CPUParticles2D *self, const godot_Vector2 *accel_vec) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_gravity, 743155724, void, self, accel_vec)
}
godot_bool godot_CPUParticles2D_get_split_scale(godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_split_scale, 2240911060, godot_bool, self)
}
void godot_CPUParticles2D_set_split_scale(godot_CPUParticles2D *self, godot_bool split_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_split_scale, 2586408642, void, self, &split_scale)
}
godot_Curve * godot_CPUParticles2D_get_scale_curve_x(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_scale_curve_x, 2460114913, godot_Curve *, self)
}
void godot_CPUParticles2D_set_scale_curve_x(godot_CPUParticles2D *self, const godot_Curve *scale_curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_scale_curve_x, 270443179, void, self, scale_curve)
}
godot_Curve * godot_CPUParticles2D_get_scale_curve_y(const godot_CPUParticles2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CPUParticles2D, get_scale_curve_y, 2460114913, godot_Curve *, self)
}
void godot_CPUParticles2D_set_scale_curve_y(godot_CPUParticles2D *self, const godot_Curve *scale_curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, set_scale_curve_y, 270443179, void, self, scale_curve)
}
void godot_CPUParticles2D_convert_from_particles(godot_CPUParticles2D *self, const godot_Node *particles) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CPUParticles2D, convert_from_particles, 1078189570, void, self, particles)
}


#ifdef __cplusplus
}
#endif
