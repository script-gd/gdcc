// This file was automatically generated
// Do not modify this file
#include "audio_effect_distortion.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectDistortion *godot_new_AudioEffectDistortion() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectDistortion);
}

// Methods
void godot_AudioEffectDistortion_set_mode(godot_AudioEffectDistortion *self, godot_AudioEffectDistortion_Mode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDistortion, set_mode, 1314744793, void, self, &mode)
}
godot_AudioEffectDistortion_Mode godot_AudioEffectDistortion_get_mode(const godot_AudioEffectDistortion *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDistortion, get_mode, 809118343, godot_AudioEffectDistortion_Mode, self)
}
void godot_AudioEffectDistortion_set_pre_gain(godot_AudioEffectDistortion *self, godot_float pre_gain) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDistortion, set_pre_gain, 373806689, void, self, &pre_gain)
}
godot_float godot_AudioEffectDistortion_get_pre_gain(const godot_AudioEffectDistortion *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDistortion, get_pre_gain, 1740695150, godot_float, self)
}
void godot_AudioEffectDistortion_set_keep_hf_hz(godot_AudioEffectDistortion *self, godot_float keep_hf_hz) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDistortion, set_keep_hf_hz, 373806689, void, self, &keep_hf_hz)
}
godot_float godot_AudioEffectDistortion_get_keep_hf_hz(const godot_AudioEffectDistortion *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDistortion, get_keep_hf_hz, 1740695150, godot_float, self)
}
void godot_AudioEffectDistortion_set_drive(godot_AudioEffectDistortion *self, godot_float drive) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDistortion, set_drive, 373806689, void, self, &drive)
}
godot_float godot_AudioEffectDistortion_get_drive(const godot_AudioEffectDistortion *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDistortion, get_drive, 1740695150, godot_float, self)
}
void godot_AudioEffectDistortion_set_post_gain(godot_AudioEffectDistortion *self, godot_float post_gain) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDistortion, set_post_gain, 373806689, void, self, &post_gain)
}
godot_float godot_AudioEffectDistortion_get_post_gain(const godot_AudioEffectDistortion *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDistortion, get_post_gain, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
