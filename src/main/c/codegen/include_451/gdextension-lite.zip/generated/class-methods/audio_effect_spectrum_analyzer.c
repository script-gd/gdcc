// This file was automatically generated
// Do not modify this file
#include "audio_effect_spectrum_analyzer.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectSpectrumAnalyzer *godot_new_AudioEffectSpectrumAnalyzer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectSpectrumAnalyzer);
}

// Methods
void godot_AudioEffectSpectrumAnalyzer_set_buffer_length(godot_AudioEffectSpectrumAnalyzer *self, godot_float seconds) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectSpectrumAnalyzer, set_buffer_length, 373806689, void, self, &seconds)
}
godot_float godot_AudioEffectSpectrumAnalyzer_get_buffer_length(const godot_AudioEffectSpectrumAnalyzer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectSpectrumAnalyzer, get_buffer_length, 1740695150, godot_float, self)
}
void godot_AudioEffectSpectrumAnalyzer_set_tap_back_pos(godot_AudioEffectSpectrumAnalyzer *self, godot_float seconds) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectSpectrumAnalyzer, set_tap_back_pos, 373806689, void, self, &seconds)
}
godot_float godot_AudioEffectSpectrumAnalyzer_get_tap_back_pos(const godot_AudioEffectSpectrumAnalyzer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectSpectrumAnalyzer, get_tap_back_pos, 1740695150, godot_float, self)
}
void godot_AudioEffectSpectrumAnalyzer_set_fft_size(godot_AudioEffectSpectrumAnalyzer *self, godot_AudioEffectSpectrumAnalyzer_FFTSize size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectSpectrumAnalyzer, set_fft_size, 1202879215, void, self, &size)
}
godot_AudioEffectSpectrumAnalyzer_FFTSize godot_AudioEffectSpectrumAnalyzer_get_fft_size(const godot_AudioEffectSpectrumAnalyzer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectSpectrumAnalyzer, get_fft_size, 3925405343, godot_AudioEffectSpectrumAnalyzer_FFTSize, self)
}


#ifdef __cplusplus
}
#endif
