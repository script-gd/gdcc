// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_FORMAT_IMPORTER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_FORMAT_IMPORTER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorSceneFormatImporter *godot_new_EditorSceneFormatImporter();

// Methods
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorSceneFormatImporter__get_extensions(const godot_EditorSceneFormatImporter *self);
GDEXTENSION_LITE_DECL godot_Object * godot_EditorSceneFormatImporter__import_scene(godot_EditorSceneFormatImporter *self, const godot_String *path, godot_int flags, const godot_Dictionary *options);
GDEXTENSION_LITE_DECL void godot_EditorSceneFormatImporter__get_import_options(godot_EditorSceneFormatImporter *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Variant godot_EditorSceneFormatImporter__get_option_visibility(const godot_EditorSceneFormatImporter *self, const godot_String *path, godot_bool for_animation, const godot_String *option);
GDEXTENSION_LITE_DECL void godot_EditorSceneFormatImporter_add_import_option(godot_EditorSceneFormatImporter *self, const godot_String *name, const godot_Variant *value);
GDEXTENSION_LITE_DECL void godot_EditorSceneFormatImporter_add_import_option_advanced(godot_EditorSceneFormatImporter *self, godot_Variant_Type type, const godot_String *name, const godot_Variant *default_value, godot_PropertyHint hint, const godot_String *hint_string, godot_int usage_flags);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_FORMAT_IMPORTER_H__
