// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BACK_BUFFER_COPY_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BACK_BUFFER_COPY_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BackBufferCopy *godot_new_BackBufferCopy();

// Methods
GDEXTENSION_LITE_DECL void godot_BackBufferCopy_set_rect(godot_BackBufferCopy *self, const godot_Rect2 *rect);
GDEXTENSION_LITE_DECL godot_Rect2 godot_BackBufferCopy_get_rect(const godot_BackBufferCopy *self);
GDEXTENSION_LITE_DECL void godot_BackBufferCopy_set_copy_mode(godot_BackBufferCopy *self, godot_BackBufferCopy_CopyMode copy_mode);
GDEXTENSION_LITE_DECL godot_BackBufferCopy_CopyMode godot_BackBufferCopy_get_copy_mode(const godot_BackBufferCopy *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BACK_BUFFER_COPY_H__
