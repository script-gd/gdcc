// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONFIG_FILE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONFIG_FILE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ConfigFile *godot_new_ConfigFile();

// Methods
GDEXTENSION_LITE_DECL void godot_ConfigFile_set_value(godot_ConfigFile *self, const godot_String *section, const godot_String *key, const godot_Variant *value);
GDEXTENSION_LITE_DECL godot_Variant godot_ConfigFile_get_value(const godot_ConfigFile *self, const godot_String *section, const godot_String *key, const godot_Variant *default_value);
GDEXTENSION_LITE_DECL godot_bool godot_ConfigFile_has_section(const godot_ConfigFile *self, const godot_String *section);
GDEXTENSION_LITE_DECL godot_bool godot_ConfigFile_has_section_key(const godot_ConfigFile *self, const godot_String *section, const godot_String *key);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_ConfigFile_get_sections(const godot_ConfigFile *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_ConfigFile_get_section_keys(const godot_ConfigFile *self, const godot_String *section);
GDEXTENSION_LITE_DECL void godot_ConfigFile_erase_section(godot_ConfigFile *self, const godot_String *section);
GDEXTENSION_LITE_DECL void godot_ConfigFile_erase_section_key(godot_ConfigFile *self, const godot_String *section, const godot_String *key);
GDEXTENSION_LITE_DECL godot_Error godot_ConfigFile_load(godot_ConfigFile *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Error godot_ConfigFile_parse(godot_ConfigFile *self, const godot_String *data);
GDEXTENSION_LITE_DECL godot_Error godot_ConfigFile_save(godot_ConfigFile *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_String godot_ConfigFile_encode_to_text(const godot_ConfigFile *self);
GDEXTENSION_LITE_DECL godot_Error godot_ConfigFile_load_encrypted(godot_ConfigFile *self, const godot_String *path, const godot_PackedByteArray *key);
GDEXTENSION_LITE_DECL godot_Error godot_ConfigFile_load_encrypted_pass(godot_ConfigFile *self, const godot_String *path, const godot_String *password);
GDEXTENSION_LITE_DECL godot_Error godot_ConfigFile_save_encrypted(godot_ConfigFile *self, const godot_String *path, const godot_PackedByteArray *key);
GDEXTENSION_LITE_DECL godot_Error godot_ConfigFile_save_encrypted_pass(godot_ConfigFile *self, const godot_String *path, const godot_String *password);
GDEXTENSION_LITE_DECL void godot_ConfigFile_clear(godot_ConfigFile *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONFIG_FILE_H__
