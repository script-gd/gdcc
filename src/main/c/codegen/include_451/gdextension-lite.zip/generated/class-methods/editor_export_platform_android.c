// This file was automatically generated
// Do not modify this file
#include "editor_export_platform_android.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlatformAndroid *godot_new_EditorExportPlatformAndroid() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlatformAndroid);
}


#ifdef __cplusplus
}
#endif
