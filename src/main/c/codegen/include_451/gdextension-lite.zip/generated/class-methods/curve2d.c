// This file was automatically generated
// Do not modify this file
#include "curve2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Curve2D *godot_new_Curve2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Curve2D);
}

// Methods
godot_int godot_Curve2D_get_point_count(const godot_Curve2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_point_count, 3905245786, godot_int, self)
}
void godot_Curve2D_set_point_count(godot_Curve2D *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve2D, set_point_count, 1286410249, void, self, &count)
}
void godot_Curve2D_add_point(godot_Curve2D *self, const godot_Vector2 *position, const godot_Vector2 *in, const godot_Vector2 *out, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve2D, add_point, 4175465202, void, self, position, in, out, &index)
}
void godot_Curve2D_set_point_position(godot_Curve2D *self, godot_int idx, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve2D, set_point_position, 163021252, void, self, &idx, position)
}
godot_Vector2 godot_Curve2D_get_point_position(const godot_Curve2D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_point_position, 2299179447, godot_Vector2, self, &idx)
}
void godot_Curve2D_set_point_in(godot_Curve2D *self, godot_int idx, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve2D, set_point_in, 163021252, void, self, &idx, position)
}
godot_Vector2 godot_Curve2D_get_point_in(const godot_Curve2D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_point_in, 2299179447, godot_Vector2, self, &idx)
}
void godot_Curve2D_set_point_out(godot_Curve2D *self, godot_int idx, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve2D, set_point_out, 163021252, void, self, &idx, position)
}
godot_Vector2 godot_Curve2D_get_point_out(const godot_Curve2D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_point_out, 2299179447, godot_Vector2, self, &idx)
}
void godot_Curve2D_remove_point(godot_Curve2D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve2D, remove_point, 1286410249, void, self, &idx)
}
void godot_Curve2D_clear_points(godot_Curve2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve2D, clear_points, 3218959716, void, self)
}
godot_Vector2 godot_Curve2D_sample(const godot_Curve2D *self, godot_int idx, godot_float t) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, sample, 26514310, godot_Vector2, self, &idx, &t)
}
godot_Vector2 godot_Curve2D_samplef(const godot_Curve2D *self, godot_float fofs) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, samplef, 3588506812, godot_Vector2, self, &fofs)
}
void godot_Curve2D_set_bake_interval(godot_Curve2D *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve2D, set_bake_interval, 373806689, void, self, &distance)
}
godot_float godot_Curve2D_get_bake_interval(const godot_Curve2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_bake_interval, 1740695150, godot_float, self)
}
godot_float godot_Curve2D_get_baked_length(const godot_Curve2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_baked_length, 1740695150, godot_float, self)
}
godot_Vector2 godot_Curve2D_sample_baked(const godot_Curve2D *self, godot_float offset, godot_bool cubic) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, sample_baked, 3464257706, godot_Vector2, self, &offset, &cubic)
}
godot_Transform2D godot_Curve2D_sample_baked_with_rotation(const godot_Curve2D *self, godot_float offset, godot_bool cubic) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, sample_baked_with_rotation, 3296056341, godot_Transform2D, self, &offset, &cubic)
}
godot_PackedVector2Array godot_Curve2D_get_baked_points(const godot_Curve2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_baked_points, 2961356807, godot_PackedVector2Array, self)
}
godot_Vector2 godot_Curve2D_get_closest_point(const godot_Curve2D *self, const godot_Vector2 *to_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_closest_point, 2656412154, godot_Vector2, self, to_point)
}
godot_float godot_Curve2D_get_closest_offset(const godot_Curve2D *self, const godot_Vector2 *to_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, get_closest_offset, 2276447920, godot_float, self, to_point)
}
godot_PackedVector2Array godot_Curve2D_tessellate(const godot_Curve2D *self, godot_int max_stages, godot_float tolerance_degrees) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, tessellate, 958145977, godot_PackedVector2Array, self, &max_stages, &tolerance_degrees)
}
godot_PackedVector2Array godot_Curve2D_tessellate_even_length(const godot_Curve2D *self, godot_int max_stages, godot_float tolerance_length) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve2D, tessellate_even_length, 2319761637, godot_PackedVector2Array, self, &max_stages, &tolerance_length)
}


#ifdef __cplusplus
}
#endif
