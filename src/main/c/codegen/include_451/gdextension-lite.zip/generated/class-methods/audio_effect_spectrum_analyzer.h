// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_SPECTRUM_ANALYZER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_SPECTRUM_ANALYZER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectSpectrumAnalyzer *godot_new_AudioEffectSpectrumAnalyzer();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectSpectrumAnalyzer_set_buffer_length(godot_AudioEffectSpectrumAnalyzer *self, godot_float seconds);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectSpectrumAnalyzer_get_buffer_length(const godot_AudioEffectSpectrumAnalyzer *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectSpectrumAnalyzer_set_tap_back_pos(godot_AudioEffectSpectrumAnalyzer *self, godot_float seconds);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectSpectrumAnalyzer_get_tap_back_pos(const godot_AudioEffectSpectrumAnalyzer *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectSpectrumAnalyzer_set_fft_size(godot_AudioEffectSpectrumAnalyzer *self, godot_AudioEffectSpectrumAnalyzer_FFTSize size);
GDEXTENSION_LITE_DECL godot_AudioEffectSpectrumAnalyzer_FFTSize godot_AudioEffectSpectrumAnalyzer_get_fft_size(const godot_AudioEffectSpectrumAnalyzer *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_SPECTRUM_ANALYZER_H__
