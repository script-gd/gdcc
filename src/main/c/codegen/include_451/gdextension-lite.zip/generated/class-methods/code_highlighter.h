// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CODE_HIGHLIGHTER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CODE_HIGHLIGHTER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CodeHighlighter *godot_new_CodeHighlighter();

// Methods
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_add_keyword_color(godot_CodeHighlighter *self, const godot_String *keyword, const godot_Color *color);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_remove_keyword_color(godot_CodeHighlighter *self, const godot_String *keyword);
GDEXTENSION_LITE_DECL godot_bool godot_CodeHighlighter_has_keyword_color(const godot_CodeHighlighter *self, const godot_String *keyword);
GDEXTENSION_LITE_DECL godot_Color godot_CodeHighlighter_get_keyword_color(const godot_CodeHighlighter *self, const godot_String *keyword);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_set_keyword_colors(godot_CodeHighlighter *self, const godot_Dictionary *keywords);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_clear_keyword_colors(godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL godot_Dictionary godot_CodeHighlighter_get_keyword_colors(const godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_add_member_keyword_color(godot_CodeHighlighter *self, const godot_String *member_keyword, const godot_Color *color);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_remove_member_keyword_color(godot_CodeHighlighter *self, const godot_String *member_keyword);
GDEXTENSION_LITE_DECL godot_bool godot_CodeHighlighter_has_member_keyword_color(const godot_CodeHighlighter *self, const godot_String *member_keyword);
GDEXTENSION_LITE_DECL godot_Color godot_CodeHighlighter_get_member_keyword_color(const godot_CodeHighlighter *self, const godot_String *member_keyword);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_set_member_keyword_colors(godot_CodeHighlighter *self, const godot_Dictionary *member_keyword);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_clear_member_keyword_colors(godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL godot_Dictionary godot_CodeHighlighter_get_member_keyword_colors(const godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_add_color_region(godot_CodeHighlighter *self, const godot_String *start_key, const godot_String *end_key, const godot_Color *color, godot_bool line_only);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_remove_color_region(godot_CodeHighlighter *self, const godot_String *start_key);
GDEXTENSION_LITE_DECL godot_bool godot_CodeHighlighter_has_color_region(const godot_CodeHighlighter *self, const godot_String *start_key);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_set_color_regions(godot_CodeHighlighter *self, const godot_Dictionary *color_regions);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_clear_color_regions(godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL godot_Dictionary godot_CodeHighlighter_get_color_regions(const godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_set_function_color(godot_CodeHighlighter *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CodeHighlighter_get_function_color(const godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_set_number_color(godot_CodeHighlighter *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CodeHighlighter_get_number_color(const godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_set_symbol_color(godot_CodeHighlighter *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CodeHighlighter_get_symbol_color(const godot_CodeHighlighter *self);
GDEXTENSION_LITE_DECL void godot_CodeHighlighter_set_member_variable_color(godot_CodeHighlighter *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CodeHighlighter_get_member_variable_color(const godot_CodeHighlighter *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CODE_HIGHLIGHTER_H__
