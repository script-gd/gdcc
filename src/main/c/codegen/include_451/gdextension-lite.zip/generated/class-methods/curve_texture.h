// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_TEXTURE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_TEXTURE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CurveTexture *godot_new_CurveTexture();

// Methods
GDEXTENSION_LITE_DECL void godot_CurveTexture_set_width(godot_CurveTexture *self, godot_int width);
GDEXTENSION_LITE_DECL void godot_CurveTexture_set_curve(godot_CurveTexture *self, const godot_Curve *curve);
GDEXTENSION_LITE_DECL godot_Curve * godot_CurveTexture_get_curve(const godot_CurveTexture *self);
GDEXTENSION_LITE_DECL void godot_CurveTexture_set_texture_mode(godot_CurveTexture *self, godot_CurveTexture_TextureMode texture_mode);
GDEXTENSION_LITE_DECL godot_CurveTexture_TextureMode godot_CurveTexture_get_texture_mode(const godot_CurveTexture *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_TEXTURE_H__
