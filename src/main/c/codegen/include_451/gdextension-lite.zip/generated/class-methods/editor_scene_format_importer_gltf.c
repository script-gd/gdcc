// This file was automatically generated
// Do not modify this file
#include "editor_scene_format_importer_gltf.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorSceneFormatImporterGLTF *godot_new_EditorSceneFormatImporterGLTF() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorSceneFormatImporterGLTF);
}


#ifdef __cplusplus
}
#endif
