// This file was automatically generated
// Do not modify this file
#include "animation_node_state_machine_transition.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeStateMachineTransition *godot_new_AnimationNodeStateMachineTransition() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeStateMachineTransition);
}

// Methods
void godot_AnimationNodeStateMachineTransition_set_switch_mode(godot_AnimationNodeStateMachineTransition *self, godot_AnimationNodeStateMachineTransition_SwitchMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_switch_mode, 2074906633, void, self, &mode)
}
godot_AnimationNodeStateMachineTransition_SwitchMode godot_AnimationNodeStateMachineTransition_get_switch_mode(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, get_switch_mode, 2138562085, godot_AnimationNodeStateMachineTransition_SwitchMode, self)
}
void godot_AnimationNodeStateMachineTransition_set_advance_mode(godot_AnimationNodeStateMachineTransition *self, godot_AnimationNodeStateMachineTransition_AdvanceMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_advance_mode, 1210869868, void, self, &mode)
}
godot_AnimationNodeStateMachineTransition_AdvanceMode godot_AnimationNodeStateMachineTransition_get_advance_mode(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, get_advance_mode, 61101689, godot_AnimationNodeStateMachineTransition_AdvanceMode, self)
}
void godot_AnimationNodeStateMachineTransition_set_advance_condition(godot_AnimationNodeStateMachineTransition *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_advance_condition, 3304788590, void, self, name)
}
godot_StringName godot_AnimationNodeStateMachineTransition_get_advance_condition(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, get_advance_condition, 2002593661, godot_StringName, self)
}
void godot_AnimationNodeStateMachineTransition_set_xfade_time(godot_AnimationNodeStateMachineTransition *self, godot_float secs) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_xfade_time, 373806689, void, self, &secs)
}
godot_float godot_AnimationNodeStateMachineTransition_get_xfade_time(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, get_xfade_time, 1740695150, godot_float, self)
}
void godot_AnimationNodeStateMachineTransition_set_xfade_curve(godot_AnimationNodeStateMachineTransition *self, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_xfade_curve, 270443179, void, self, curve)
}
godot_Curve * godot_AnimationNodeStateMachineTransition_get_xfade_curve(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, get_xfade_curve, 2460114913, godot_Curve *, self)
}
void godot_AnimationNodeStateMachineTransition_set_break_loop_at_end(godot_AnimationNodeStateMachineTransition *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_break_loop_at_end, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeStateMachineTransition_is_loop_broken_at_end(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, is_loop_broken_at_end, 36873697, godot_bool, self)
}
void godot_AnimationNodeStateMachineTransition_set_reset(godot_AnimationNodeStateMachineTransition *self, godot_bool reset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_reset, 2586408642, void, self, &reset)
}
godot_bool godot_AnimationNodeStateMachineTransition_is_reset(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, is_reset, 36873697, godot_bool, self)
}
void godot_AnimationNodeStateMachineTransition_set_priority(godot_AnimationNodeStateMachineTransition *self, godot_int priority) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_priority, 1286410249, void, self, &priority)
}
godot_int godot_AnimationNodeStateMachineTransition_get_priority(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, get_priority, 3905245786, godot_int, self)
}
void godot_AnimationNodeStateMachineTransition_set_advance_expression(godot_AnimationNodeStateMachineTransition *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachineTransition, set_advance_expression, 83702148, void, self, text)
}
godot_String godot_AnimationNodeStateMachineTransition_get_advance_expression(const godot_AnimationNodeStateMachineTransition *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachineTransition, get_advance_expression, 201670096, godot_String, self)
}


#ifdef __cplusplus
}
#endif
