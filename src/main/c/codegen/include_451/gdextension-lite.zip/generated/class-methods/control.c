// This file was automatically generated
// Do not modify this file
#include "control.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Control *godot_new_Control() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Control);
}

// Methods
godot_bool godot_Control__has_point(const godot_Control *self, const godot_Vector2 *point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _has_point, 556197845, godot_bool, self, point)
}
godot_TypedArray(godot_Vector3i) godot_Control__structured_text_parser(const godot_Control *self, const godot_Array *args, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _structured_text_parser, 1292548940, godot_TypedArray(godot_Vector3i), self, args, text)
}
godot_Vector2 godot_Control__get_minimum_size(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _get_minimum_size, 3341600327, godot_Vector2, self)
}
godot_String godot_Control__get_tooltip(const godot_Control *self, const godot_Vector2 *at_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _get_tooltip, 3674420000, godot_String, self, at_position)
}
godot_Variant godot_Control__get_drag_data(godot_Control *self, const godot_Vector2 *at_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _get_drag_data, 2233896889, godot_Variant, self, at_position)
}
godot_bool godot_Control__can_drop_data(const godot_Control *self, const godot_Vector2 *at_position, const godot_Variant *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _can_drop_data, 2603004011, godot_bool, self, at_position, data)
}
void godot_Control__drop_data(godot_Control *self, const godot_Vector2 *at_position, const godot_Variant *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, _drop_data, 3699746064, void, self, at_position, data)
}
godot_Object * godot_Control__make_custom_tooltip(const godot_Control *self, const godot_String *for_text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _make_custom_tooltip, 1976279298, godot_Object *, self, for_text)
}
godot_String godot_Control__accessibility_get_contextual_info(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _accessibility_get_contextual_info, 201670096, godot_String, self)
}
godot_String godot_Control__get_accessibility_container_name(const godot_Control *self, const godot_Node *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, _get_accessibility_container_name, 2174079723, godot_String, self, node)
}
void godot_Control__gui_input(godot_Control *self, const godot_InputEvent *event) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, _gui_input, 3754044979, void, self, event)
}
void godot_Control_accept_event(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, accept_event, 3218959716, void, self)
}
godot_Vector2 godot_Control_get_minimum_size(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_minimum_size, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_combined_minimum_size(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_combined_minimum_size, 3341600327, godot_Vector2, self)
}
void godot_Control_set_anchors_preset(godot_Control *self, godot_Control_LayoutPreset preset, godot_bool keep_offsets) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_anchors_preset, 509135270, void, self, &preset, &keep_offsets)
}
void godot_Control_set_offsets_preset(godot_Control *self, godot_Control_LayoutPreset preset, godot_Control_LayoutPresetMode resize_mode, godot_int margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_offsets_preset, 3724524307, void, self, &preset, &resize_mode, &margin)
}
void godot_Control_set_anchors_and_offsets_preset(godot_Control *self, godot_Control_LayoutPreset preset, godot_Control_LayoutPresetMode resize_mode, godot_int margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_anchors_and_offsets_preset, 3724524307, void, self, &preset, &resize_mode, &margin)
}
void godot_Control_set_anchor(godot_Control *self, godot_Side side, godot_float anchor, godot_bool keep_offset, godot_bool push_opposite_anchor) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_anchor, 2302782885, void, self, &side, &anchor, &keep_offset, &push_opposite_anchor)
}
godot_float godot_Control_get_anchor(const godot_Control *self, godot_Side side) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_anchor, 2869120046, godot_float, self, &side)
}
void godot_Control_set_offset(godot_Control *self, godot_Side side, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_offset, 4290182280, void, self, &side, &offset)
}
godot_float godot_Control_get_offset(const godot_Control *self, godot_Side offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_offset, 2869120046, godot_float, self, &offset)
}
void godot_Control_set_anchor_and_offset(godot_Control *self, godot_Side side, godot_float anchor, godot_float offset, godot_bool push_opposite_anchor) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_anchor_and_offset, 4031722181, void, self, &side, &anchor, &offset, &push_opposite_anchor)
}
void godot_Control_set_begin(godot_Control *self, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_begin, 743155724, void, self, position)
}
void godot_Control_set_end(godot_Control *self, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_end, 743155724, void, self, position)
}
void godot_Control_set_position(godot_Control *self, const godot_Vector2 *position, godot_bool keep_offsets) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_position, 2436320129, void, self, position, &keep_offsets)
}
void godot_Control_set_size(godot_Control *self, const godot_Vector2 *size, godot_bool keep_offsets) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_size, 2436320129, void, self, size, &keep_offsets)
}
void godot_Control_reset_size(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, reset_size, 3218959716, void, self)
}
void godot_Control_set_custom_minimum_size(godot_Control *self, const godot_Vector2 *size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_custom_minimum_size, 743155724, void, self, size)
}
void godot_Control_set_global_position(godot_Control *self, const godot_Vector2 *position, godot_bool keep_offsets) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_global_position, 2436320129, void, self, position, &keep_offsets)
}
void godot_Control_set_rotation(godot_Control *self, godot_float radians) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_rotation, 373806689, void, self, &radians)
}
void godot_Control_set_rotation_degrees(godot_Control *self, godot_float degrees) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_rotation_degrees, 373806689, void, self, &degrees)
}
void godot_Control_set_scale(godot_Control *self, const godot_Vector2 *scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_scale, 743155724, void, self, scale)
}
void godot_Control_set_pivot_offset(godot_Control *self, const godot_Vector2 *pivot_offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_pivot_offset, 743155724, void, self, pivot_offset)
}
godot_Vector2 godot_Control_get_begin(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_begin, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_end(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_end, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_position(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_position, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_size(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_size, 3341600327, godot_Vector2, self)
}
godot_float godot_Control_get_rotation(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_rotation, 1740695150, godot_float, self)
}
godot_float godot_Control_get_rotation_degrees(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_rotation_degrees, 1740695150, godot_float, self)
}
godot_Vector2 godot_Control_get_scale(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_scale, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_pivot_offset(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_pivot_offset, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_custom_minimum_size(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_custom_minimum_size, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_parent_area_size(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_parent_area_size, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_global_position(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_global_position, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Control_get_screen_position(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_screen_position, 3341600327, godot_Vector2, self)
}
godot_Rect2 godot_Control_get_rect(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_rect, 1639390495, godot_Rect2, self)
}
godot_Rect2 godot_Control_get_global_rect(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_global_rect, 1639390495, godot_Rect2, self)
}
void godot_Control_set_focus_mode(godot_Control *self, godot_Control_FocusMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_focus_mode, 3232914922, void, self, &mode)
}
godot_Control_FocusMode godot_Control_get_focus_mode(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_focus_mode, 2132829277, godot_Control_FocusMode, self)
}
godot_Control_FocusMode godot_Control_get_focus_mode_with_override(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_focus_mode_with_override, 2132829277, godot_Control_FocusMode, self)
}
void godot_Control_set_focus_behavior_recursive(godot_Control *self, godot_Control_FocusBehaviorRecursive focus_behavior_recursive) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_focus_behavior_recursive, 4256832521, void, self, &focus_behavior_recursive)
}
godot_Control_FocusBehaviorRecursive godot_Control_get_focus_behavior_recursive(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_focus_behavior_recursive, 2435707181, godot_Control_FocusBehaviorRecursive, self)
}
godot_bool godot_Control_has_focus(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_focus, 36873697, godot_bool, self)
}
void godot_Control_grab_focus(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, grab_focus, 3218959716, void, self)
}
void godot_Control_release_focus(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, release_focus, 3218959716, void, self)
}
godot_Control * godot_Control_find_prev_valid_focus(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, find_prev_valid_focus, 2783021301, godot_Control *, self)
}
godot_Control * godot_Control_find_next_valid_focus(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, find_next_valid_focus, 2783021301, godot_Control *, self)
}
godot_Control * godot_Control_find_valid_focus_neighbor(const godot_Control *self, godot_Side side) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, find_valid_focus_neighbor, 1543910170, godot_Control *, self, &side)
}
void godot_Control_set_h_size_flags(godot_Control *self, const godot_Control_SizeFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_h_size_flags, 394851643, void, self, flags)
}
godot_Control_SizeFlags godot_Control_get_h_size_flags(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_h_size_flags, 3781367401, godot_Control_SizeFlags, self)
}
void godot_Control_set_stretch_ratio(godot_Control *self, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_stretch_ratio, 373806689, void, self, &ratio)
}
godot_float godot_Control_get_stretch_ratio(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_stretch_ratio, 1740695150, godot_float, self)
}
void godot_Control_set_v_size_flags(godot_Control *self, const godot_Control_SizeFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_v_size_flags, 394851643, void, self, flags)
}
godot_Control_SizeFlags godot_Control_get_v_size_flags(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_v_size_flags, 3781367401, godot_Control_SizeFlags, self)
}
void godot_Control_set_theme(godot_Control *self, const godot_Theme *theme) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_theme, 2326690814, void, self, theme)
}
godot_Theme * godot_Control_get_theme(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme, 3846893731, godot_Theme *, self)
}
void godot_Control_set_theme_type_variation(godot_Control *self, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_theme_type_variation, 3304788590, void, self, theme_type)
}
godot_StringName godot_Control_get_theme_type_variation(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_type_variation, 2002593661, godot_StringName, self)
}
void godot_Control_begin_bulk_theme_override(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, begin_bulk_theme_override, 3218959716, void, self)
}
void godot_Control_end_bulk_theme_override(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, end_bulk_theme_override, 3218959716, void, self)
}
void godot_Control_add_theme_icon_override(godot_Control *self, const godot_StringName *name, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, add_theme_icon_override, 1373065600, void, self, name, texture)
}
void godot_Control_add_theme_stylebox_override(godot_Control *self, const godot_StringName *name, const godot_StyleBox *stylebox) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, add_theme_stylebox_override, 4188838905, void, self, name, stylebox)
}
void godot_Control_add_theme_font_override(godot_Control *self, const godot_StringName *name, const godot_Font *font) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, add_theme_font_override, 3518018674, void, self, name, font)
}
void godot_Control_add_theme_font_size_override(godot_Control *self, const godot_StringName *name, godot_int font_size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, add_theme_font_size_override, 2415702435, void, self, name, &font_size)
}
void godot_Control_add_theme_color_override(godot_Control *self, const godot_StringName *name, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, add_theme_color_override, 4260178595, void, self, name, color)
}
void godot_Control_add_theme_constant_override(godot_Control *self, const godot_StringName *name, godot_int constant) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, add_theme_constant_override, 2415702435, void, self, name, &constant)
}
void godot_Control_remove_theme_icon_override(godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, remove_theme_icon_override, 3304788590, void, self, name)
}
void godot_Control_remove_theme_stylebox_override(godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, remove_theme_stylebox_override, 3304788590, void, self, name)
}
void godot_Control_remove_theme_font_override(godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, remove_theme_font_override, 3304788590, void, self, name)
}
void godot_Control_remove_theme_font_size_override(godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, remove_theme_font_size_override, 3304788590, void, self, name)
}
void godot_Control_remove_theme_color_override(godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, remove_theme_color_override, 3304788590, void, self, name)
}
void godot_Control_remove_theme_constant_override(godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, remove_theme_constant_override, 3304788590, void, self, name)
}
godot_Texture2D * godot_Control_get_theme_icon(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_icon, 3163973443, godot_Texture2D *, self, name, theme_type)
}
godot_StyleBox * godot_Control_get_theme_stylebox(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_stylebox, 604739069, godot_StyleBox *, self, name, theme_type)
}
godot_Font * godot_Control_get_theme_font(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_font, 2826986490, godot_Font *, self, name, theme_type)
}
godot_int godot_Control_get_theme_font_size(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_font_size, 1327056374, godot_int, self, name, theme_type)
}
godot_Color godot_Control_get_theme_color(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_color, 2798751242, godot_Color, self, name, theme_type)
}
godot_int godot_Control_get_theme_constant(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_constant, 1327056374, godot_int, self, name, theme_type)
}
godot_bool godot_Control_has_theme_icon_override(const godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_icon_override, 2619796661, godot_bool, self, name)
}
godot_bool godot_Control_has_theme_stylebox_override(const godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_stylebox_override, 2619796661, godot_bool, self, name)
}
godot_bool godot_Control_has_theme_font_override(const godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_font_override, 2619796661, godot_bool, self, name)
}
godot_bool godot_Control_has_theme_font_size_override(const godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_font_size_override, 2619796661, godot_bool, self, name)
}
godot_bool godot_Control_has_theme_color_override(const godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_color_override, 2619796661, godot_bool, self, name)
}
godot_bool godot_Control_has_theme_constant_override(const godot_Control *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_constant_override, 2619796661, godot_bool, self, name)
}
godot_bool godot_Control_has_theme_icon(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_icon, 866386512, godot_bool, self, name, theme_type)
}
godot_bool godot_Control_has_theme_stylebox(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_stylebox, 866386512, godot_bool, self, name, theme_type)
}
godot_bool godot_Control_has_theme_font(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_font, 866386512, godot_bool, self, name, theme_type)
}
godot_bool godot_Control_has_theme_font_size(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_font_size, 866386512, godot_bool, self, name, theme_type)
}
godot_bool godot_Control_has_theme_color(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_color, 866386512, godot_bool, self, name, theme_type)
}
godot_bool godot_Control_has_theme_constant(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, has_theme_constant, 866386512, godot_bool, self, name, theme_type)
}
godot_float godot_Control_get_theme_default_base_scale(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_default_base_scale, 1740695150, godot_float, self)
}
godot_Font * godot_Control_get_theme_default_font(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_default_font, 3229501585, godot_Font *, self)
}
godot_int godot_Control_get_theme_default_font_size(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_theme_default_font_size, 3905245786, godot_int, self)
}
godot_Control * godot_Control_get_parent_control(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_parent_control, 2783021301, godot_Control *, self)
}
void godot_Control_set_h_grow_direction(godot_Control *self, godot_Control_GrowDirection direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_h_grow_direction, 2022385301, void, self, &direction)
}
godot_Control_GrowDirection godot_Control_get_h_grow_direction(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_h_grow_direction, 3635610155, godot_Control_GrowDirection, self)
}
void godot_Control_set_v_grow_direction(godot_Control *self, godot_Control_GrowDirection direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_v_grow_direction, 2022385301, void, self, &direction)
}
godot_Control_GrowDirection godot_Control_get_v_grow_direction(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_v_grow_direction, 3635610155, godot_Control_GrowDirection, self)
}
void godot_Control_set_tooltip_auto_translate_mode(godot_Control *self, godot_Node_AutoTranslateMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_tooltip_auto_translate_mode, 776149714, void, self, &mode)
}
godot_Node_AutoTranslateMode godot_Control_get_tooltip_auto_translate_mode(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_tooltip_auto_translate_mode, 2498906432, godot_Node_AutoTranslateMode, self)
}
void godot_Control_set_tooltip_text(godot_Control *self, const godot_String *hint) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_tooltip_text, 83702148, void, self, hint)
}
godot_String godot_Control_get_tooltip_text(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_tooltip_text, 201670096, godot_String, self)
}
godot_String godot_Control_get_tooltip(const godot_Control *self, const godot_Vector2 *at_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_tooltip, 2895288280, godot_String, self, at_position)
}
void godot_Control_set_default_cursor_shape(godot_Control *self, godot_Control_CursorShape shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_default_cursor_shape, 217062046, void, self, &shape)
}
godot_Control_CursorShape godot_Control_get_default_cursor_shape(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_default_cursor_shape, 2359535750, godot_Control_CursorShape, self)
}
godot_Control_CursorShape godot_Control_get_cursor_shape(const godot_Control *self, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_cursor_shape, 1395773853, godot_Control_CursorShape, self, position)
}
void godot_Control_set_focus_neighbor(godot_Control *self, godot_Side side, const godot_NodePath *neighbor) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_focus_neighbor, 2024461774, void, self, &side, neighbor)
}
godot_NodePath godot_Control_get_focus_neighbor(const godot_Control *self, godot_Side side) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_focus_neighbor, 2757935761, godot_NodePath, self, &side)
}
void godot_Control_set_focus_next(godot_Control *self, const godot_NodePath *next) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_focus_next, 1348162250, void, self, next)
}
godot_NodePath godot_Control_get_focus_next(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_focus_next, 4075236667, godot_NodePath, self)
}
void godot_Control_set_focus_previous(godot_Control *self, const godot_NodePath *previous) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_focus_previous, 1348162250, void, self, previous)
}
godot_NodePath godot_Control_get_focus_previous(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_focus_previous, 4075236667, godot_NodePath, self)
}
void godot_Control_force_drag(godot_Control *self, const godot_Variant *data, const godot_Control *preview) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, force_drag, 3191844692, void, self, data, preview)
}
void godot_Control_accessibility_drag(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, accessibility_drag, 3218959716, void, self)
}
void godot_Control_accessibility_drop(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, accessibility_drop, 3218959716, void, self)
}
void godot_Control_set_accessibility_name(godot_Control *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_accessibility_name, 83702148, void, self, name)
}
godot_String godot_Control_get_accessibility_name(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_accessibility_name, 201670096, godot_String, self)
}
void godot_Control_set_accessibility_description(godot_Control *self, const godot_String *description) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_accessibility_description, 83702148, void, self, description)
}
godot_String godot_Control_get_accessibility_description(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_accessibility_description, 201670096, godot_String, self)
}
void godot_Control_set_accessibility_live(godot_Control *self, godot_DisplayServer_AccessibilityLiveMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_accessibility_live, 1720261470, void, self, &mode)
}
godot_DisplayServer_AccessibilityLiveMode godot_Control_get_accessibility_live(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_accessibility_live, 3311037003, godot_DisplayServer_AccessibilityLiveMode, self)
}
void godot_Control_set_accessibility_controls_nodes(godot_Control *self, const godot_TypedArray(godot_NodePath) *node_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_accessibility_controls_nodes, 381264803, void, self, node_path)
}
godot_TypedArray(godot_NodePath) godot_Control_get_accessibility_controls_nodes(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_accessibility_controls_nodes, 3995934104, godot_TypedArray(godot_NodePath), self)
}
void godot_Control_set_accessibility_described_by_nodes(godot_Control *self, const godot_TypedArray(godot_NodePath) *node_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_accessibility_described_by_nodes, 381264803, void, self, node_path)
}
godot_TypedArray(godot_NodePath) godot_Control_get_accessibility_described_by_nodes(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_accessibility_described_by_nodes, 3995934104, godot_TypedArray(godot_NodePath), self)
}
void godot_Control_set_accessibility_labeled_by_nodes(godot_Control *self, const godot_TypedArray(godot_NodePath) *node_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_accessibility_labeled_by_nodes, 381264803, void, self, node_path)
}
godot_TypedArray(godot_NodePath) godot_Control_get_accessibility_labeled_by_nodes(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_accessibility_labeled_by_nodes, 3995934104, godot_TypedArray(godot_NodePath), self)
}
void godot_Control_set_accessibility_flow_to_nodes(godot_Control *self, const godot_TypedArray(godot_NodePath) *node_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_accessibility_flow_to_nodes, 381264803, void, self, node_path)
}
godot_TypedArray(godot_NodePath) godot_Control_get_accessibility_flow_to_nodes(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_accessibility_flow_to_nodes, 3995934104, godot_TypedArray(godot_NodePath), self)
}
void godot_Control_set_mouse_filter(godot_Control *self, godot_Control_MouseFilter filter) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_mouse_filter, 3891156122, void, self, &filter)
}
godot_Control_MouseFilter godot_Control_get_mouse_filter(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_mouse_filter, 1572545674, godot_Control_MouseFilter, self)
}
godot_Control_MouseFilter godot_Control_get_mouse_filter_with_override(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_mouse_filter_with_override, 1572545674, godot_Control_MouseFilter, self)
}
void godot_Control_set_mouse_behavior_recursive(godot_Control *self, godot_Control_MouseBehaviorRecursive mouse_behavior_recursive) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_mouse_behavior_recursive, 849284636, void, self, &mouse_behavior_recursive)
}
godot_Control_MouseBehaviorRecursive godot_Control_get_mouse_behavior_recursive(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_mouse_behavior_recursive, 3779367402, godot_Control_MouseBehaviorRecursive, self)
}
void godot_Control_set_force_pass_scroll_events(godot_Control *self, godot_bool force_pass_scroll_events) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_force_pass_scroll_events, 2586408642, void, self, &force_pass_scroll_events)
}
godot_bool godot_Control_is_force_pass_scroll_events(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, is_force_pass_scroll_events, 36873697, godot_bool, self)
}
void godot_Control_set_clip_contents(godot_Control *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_clip_contents, 2586408642, void, self, &enable)
}
godot_bool godot_Control_is_clipping_contents(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, is_clipping_contents, 2240911060, godot_bool, self)
}
void godot_Control_grab_click_focus(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, grab_click_focus, 3218959716, void, self)
}
void godot_Control_set_drag_forwarding(godot_Control *self, const godot_Callable *drag_func, const godot_Callable *can_drop_func, const godot_Callable *drop_func) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_drag_forwarding, 1076571380, void, self, drag_func, can_drop_func, drop_func)
}
void godot_Control_set_drag_preview(godot_Control *self, const godot_Control *control) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_drag_preview, 1496901182, void, self, control)
}
godot_bool godot_Control_is_drag_successful(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, is_drag_successful, 36873697, godot_bool, self)
}
void godot_Control_warp_mouse(godot_Control *self, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, warp_mouse, 743155724, void, self, position)
}
void godot_Control_set_shortcut_context(godot_Control *self, const godot_Node *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_shortcut_context, 1078189570, void, self, node)
}
godot_Node * godot_Control_get_shortcut_context(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_shortcut_context, 3160264692, godot_Node *, self)
}
void godot_Control_update_minimum_size(godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, update_minimum_size, 3218959716, void, self)
}
void godot_Control_set_layout_direction(godot_Control *self, godot_Control_LayoutDirection direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_layout_direction, 3310692370, void, self, &direction)
}
godot_Control_LayoutDirection godot_Control_get_layout_direction(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, get_layout_direction, 1546772008, godot_Control_LayoutDirection, self)
}
godot_bool godot_Control_is_layout_rtl(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, is_layout_rtl, 36873697, godot_bool, self)
}
void godot_Control_set_auto_translate(godot_Control *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_auto_translate, 2586408642, void, self, &enable)
}
godot_bool godot_Control_is_auto_translating(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, is_auto_translating, 36873697, godot_bool, self)
}
void godot_Control_set_localize_numeral_system(godot_Control *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Control, set_localize_numeral_system, 2586408642, void, self, &enable)
}
godot_bool godot_Control_is_localizing_numeral_system(const godot_Control *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Control, is_localizing_numeral_system, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
