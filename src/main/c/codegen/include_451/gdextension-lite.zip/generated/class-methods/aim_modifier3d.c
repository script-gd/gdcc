// This file was automatically generated
// Do not modify this file
#include "aim_modifier3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AimModifier3D *godot_new_AimModifier3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AimModifier3D);
}

// Methods
void godot_AimModifier3D_set_forward_axis(godot_AimModifier3D *self, godot_int index, godot_SkeletonModifier3D_BoneAxis axis) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AimModifier3D, set_forward_axis, 2496831085, void, self, &index, &axis)
}
godot_SkeletonModifier3D_BoneAxis godot_AimModifier3D_get_forward_axis(const godot_AimModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AimModifier3D, get_forward_axis, 3949866735, godot_SkeletonModifier3D_BoneAxis, self, &index)
}
void godot_AimModifier3D_set_use_euler(godot_AimModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AimModifier3D, set_use_euler, 300928843, void, self, &index, &enabled)
}
godot_bool godot_AimModifier3D_is_using_euler(const godot_AimModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AimModifier3D, is_using_euler, 1116898809, godot_bool, self, &index)
}
void godot_AimModifier3D_set_primary_rotation_axis(godot_AimModifier3D *self, godot_int index, godot_Vector3_Axis axis) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AimModifier3D, set_primary_rotation_axis, 776736805, void, self, &index, &axis)
}
godot_Vector3_Axis godot_AimModifier3D_get_primary_rotation_axis(const godot_AimModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AimModifier3D, get_primary_rotation_axis, 4131134770, godot_Vector3_Axis, self, &index)
}
void godot_AimModifier3D_set_use_secondary_rotation(godot_AimModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AimModifier3D, set_use_secondary_rotation, 300928843, void, self, &index, &enabled)
}
godot_bool godot_AimModifier3D_is_using_secondary_rotation(const godot_AimModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AimModifier3D, is_using_secondary_rotation, 1116898809, godot_bool, self, &index)
}


#ifdef __cplusplus
}
#endif
