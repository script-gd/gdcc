// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamPlayback *godot_new_AudioStreamPlayback();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback__start(godot_AudioStreamPlayback *self, godot_float from_pos);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback__stop(godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlayback__is_playing(const godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPlayback__get_loop_count(const godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlayback__get_playback_position(const godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback__seek(godot_AudioStreamPlayback *self, godot_float position);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPlayback__mix(godot_AudioStreamPlayback *self, godot_AudioFrame* buffer, godot_float rate_scale, godot_int frames);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback__tag_used_streams(godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback__set_parameter(godot_AudioStreamPlayback *self, const godot_StringName *name, const godot_Variant *value);
GDEXTENSION_LITE_DECL godot_Variant godot_AudioStreamPlayback__get_parameter(const godot_AudioStreamPlayback *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback_set_sample_playback(godot_AudioStreamPlayback *self, const godot_AudioSamplePlayback *playback_sample);
GDEXTENSION_LITE_DECL godot_AudioSamplePlayback * godot_AudioStreamPlayback_get_sample_playback(const godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_AudioStreamPlayback_mix_audio(godot_AudioStreamPlayback *self, godot_float rate_scale, godot_int frames);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback_start(godot_AudioStreamPlayback *self, godot_float from_pos);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback_seek(godot_AudioStreamPlayback *self, godot_float time);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayback_stop(godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPlayback_get_loop_count(const godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlayback_get_playback_position(const godot_AudioStreamPlayback *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlayback_is_playing(const godot_AudioStreamPlayback *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_H__
