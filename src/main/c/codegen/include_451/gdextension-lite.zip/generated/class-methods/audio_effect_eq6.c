// This file was automatically generated
// Do not modify this file
#include "audio_effect_eq6.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectEQ6 *godot_new_AudioEffectEQ6() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectEQ6);
}


#ifdef __cplusplus
}
#endif
