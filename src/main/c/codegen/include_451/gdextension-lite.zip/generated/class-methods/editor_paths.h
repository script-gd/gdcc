// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PATHS_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PATHS_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorPaths *godot_new_EditorPaths();

// Methods
GDEXTENSION_LITE_DECL godot_String godot_EditorPaths_get_data_dir(const godot_EditorPaths *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorPaths_get_config_dir(const godot_EditorPaths *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorPaths_get_cache_dir(const godot_EditorPaths *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorPaths_is_self_contained(const godot_EditorPaths *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorPaths_get_self_contained_file(const godot_EditorPaths *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorPaths_get_project_settings_dir(const godot_EditorPaths *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PATHS_H__
