// This file was automatically generated
// Do not modify this file
#include "capsule_shape2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CapsuleShape2D *godot_new_CapsuleShape2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CapsuleShape2D);
}

// Methods
void godot_CapsuleShape2D_set_radius(godot_CapsuleShape2D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleShape2D, set_radius, 373806689, void, self, &radius)
}
godot_float godot_CapsuleShape2D_get_radius(const godot_CapsuleShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleShape2D, get_radius, 1740695150, godot_float, self)
}
void godot_CapsuleShape2D_set_height(godot_CapsuleShape2D *self, godot_float height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleShape2D, set_height, 373806689, void, self, &height)
}
godot_float godot_CapsuleShape2D_get_height(const godot_CapsuleShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleShape2D, get_height, 1740695150, godot_float, self)
}
void godot_CapsuleShape2D_set_mid_height(godot_CapsuleShape2D *self, godot_float mid_height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleShape2D, set_mid_height, 373806689, void, self, &mid_height)
}
godot_float godot_CapsuleShape2D_get_mid_height(const godot_CapsuleShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleShape2D, get_mid_height, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
