// This file was automatically generated
// Do not modify this file
#include "audio_stream_generator.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamGenerator *godot_new_AudioStreamGenerator() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamGenerator);
}

// Methods
void godot_AudioStreamGenerator_set_mix_rate(godot_AudioStreamGenerator *self, godot_float hz) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamGenerator, set_mix_rate, 373806689, void, self, &hz)
}
godot_float godot_AudioStreamGenerator_get_mix_rate(const godot_AudioStreamGenerator *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamGenerator, get_mix_rate, 1740695150, godot_float, self)
}
void godot_AudioStreamGenerator_set_mix_rate_mode(godot_AudioStreamGenerator *self, godot_AudioStreamGenerator_AudioStreamGeneratorMixRate mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamGenerator, set_mix_rate_mode, 3354885803, void, self, &mode)
}
godot_AudioStreamGenerator_AudioStreamGeneratorMixRate godot_AudioStreamGenerator_get_mix_rate_mode(const godot_AudioStreamGenerator *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamGenerator, get_mix_rate_mode, 3537132591, godot_AudioStreamGenerator_AudioStreamGeneratorMixRate, self)
}
void godot_AudioStreamGenerator_set_buffer_length(godot_AudioStreamGenerator *self, godot_float seconds) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamGenerator, set_buffer_length, 373806689, void, self, &seconds)
}
godot_float godot_AudioStreamGenerator_get_buffer_length(const godot_AudioStreamGenerator *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamGenerator, get_buffer_length, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
