// This file was automatically generated
// Do not modify this file
#include "compressed_texture_layered.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_Error godot_CompressedTextureLayered_load(godot_CompressedTextureLayered *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompressedTextureLayered, load, 166001499, godot_Error, self, path)
}
godot_String godot_CompressedTextureLayered_get_load_path(const godot_CompressedTextureLayered *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompressedTextureLayered, get_load_path, 201670096, godot_String, self)
}


#ifdef __cplusplus
}
#endif
