// This file was automatically generated
// Do not modify this file
#include "cubemap.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Cubemap *godot_new_Cubemap() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Cubemap);
}

// Methods
godot_Resource * godot_Cubemap_create_placeholder(const godot_Cubemap *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Cubemap, create_placeholder, 121922552, godot_Resource *, self)
}


#ifdef __cplusplus
}
#endif
