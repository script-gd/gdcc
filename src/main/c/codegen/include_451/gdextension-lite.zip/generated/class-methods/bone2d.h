// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Bone2D *godot_new_Bone2D();

// Methods
GDEXTENSION_LITE_DECL void godot_Bone2D_set_rest(godot_Bone2D *self, const godot_Transform2D *rest);
GDEXTENSION_LITE_DECL godot_Transform2D godot_Bone2D_get_rest(const godot_Bone2D *self);
GDEXTENSION_LITE_DECL void godot_Bone2D_apply_rest(godot_Bone2D *self);
GDEXTENSION_LITE_DECL godot_Transform2D godot_Bone2D_get_skeleton_rest(const godot_Bone2D *self);
GDEXTENSION_LITE_DECL godot_int godot_Bone2D_get_index_in_skeleton(const godot_Bone2D *self);
GDEXTENSION_LITE_DECL void godot_Bone2D_set_autocalculate_length_and_angle(godot_Bone2D *self, godot_bool auto_calculate);
GDEXTENSION_LITE_DECL godot_bool godot_Bone2D_get_autocalculate_length_and_angle(const godot_Bone2D *self);
GDEXTENSION_LITE_DECL void godot_Bone2D_set_length(godot_Bone2D *self, godot_float length);
GDEXTENSION_LITE_DECL godot_float godot_Bone2D_get_length(const godot_Bone2D *self);
GDEXTENSION_LITE_DECL void godot_Bone2D_set_bone_angle(godot_Bone2D *self, godot_float angle);
GDEXTENSION_LITE_DECL godot_float godot_Bone2D_get_bone_angle(const godot_Bone2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE2D_H__
