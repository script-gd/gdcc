// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_NODE3DGIZMO_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_NODE3DGIZMO_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorNode3DGizmo *godot_new_EditorNode3DGizmo();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo__redraw(godot_EditorNode3DGizmo *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorNode3DGizmo__get_handle_name(const godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary);
GDEXTENSION_LITE_DECL godot_bool godot_EditorNode3DGizmo__is_handle_highlighted(const godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary);
GDEXTENSION_LITE_DECL godot_Variant godot_EditorNode3DGizmo__get_handle_value(const godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo__begin_handle_action(godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo__set_handle(godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary, const godot_Camera3D *camera, const godot_Vector2 *point);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo__commit_handle(godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary, const godot_Variant *restore, godot_bool cancel);
GDEXTENSION_LITE_DECL godot_int godot_EditorNode3DGizmo__subgizmos_intersect_ray(const godot_EditorNode3DGizmo *self, const godot_Camera3D *camera, const godot_Vector2 *point);
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_EditorNode3DGizmo__subgizmos_intersect_frustum(const godot_EditorNode3DGizmo *self, const godot_Camera3D *camera, const godot_TypedArray(godot_Plane) *frustum);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo__set_subgizmo_transform(godot_EditorNode3DGizmo *self, godot_int id, const godot_Transform3D *transform);
GDEXTENSION_LITE_DECL godot_Transform3D godot_EditorNode3DGizmo__get_subgizmo_transform(const godot_EditorNode3DGizmo *self, godot_int id);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo__commit_subgizmos(godot_EditorNode3DGizmo *self, const godot_PackedInt32Array *ids, const godot_TypedArray(godot_Transform3D) *restores, godot_bool cancel);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_add_lines(godot_EditorNode3DGizmo *self, const godot_PackedVector3Array *lines, const godot_Material *material, godot_bool billboard, const godot_Color *modulate);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_add_mesh(godot_EditorNode3DGizmo *self, const godot_Mesh *mesh, const godot_Material *material, const godot_Transform3D *transform, const godot_SkinReference *skeleton);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_add_collision_segments(godot_EditorNode3DGizmo *self, const godot_PackedVector3Array *segments);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_add_collision_triangles(godot_EditorNode3DGizmo *self, const godot_TriangleMesh *triangles);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_add_unscaled_billboard(godot_EditorNode3DGizmo *self, const godot_Material *material, godot_float default_scale, const godot_Color *modulate);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_add_handles(godot_EditorNode3DGizmo *self, const godot_PackedVector3Array *handles, const godot_Material *material, const godot_PackedInt32Array *ids, godot_bool billboard, godot_bool secondary);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_set_node_3d(godot_EditorNode3DGizmo *self, const godot_Node *node);
GDEXTENSION_LITE_DECL godot_Node3D * godot_EditorNode3DGizmo_get_node_3d(const godot_EditorNode3DGizmo *self);
GDEXTENSION_LITE_DECL godot_EditorNode3DGizmoPlugin * godot_EditorNode3DGizmo_get_plugin(const godot_EditorNode3DGizmo *self);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_clear(godot_EditorNode3DGizmo *self);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmo_set_hidden(godot_EditorNode3DGizmo *self, godot_bool hidden);
GDEXTENSION_LITE_DECL godot_bool godot_EditorNode3DGizmo_is_subgizmo_selected(const godot_EditorNode3DGizmo *self, godot_int id);
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_EditorNode3DGizmo_get_subgizmo_selection(const godot_EditorNode3DGizmo *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_NODE3DGIZMO_H__
