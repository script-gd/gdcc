// This file was automatically generated
// Do not modify this file
#include "editor_resource_picker.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorResourcePicker *godot_new_EditorResourcePicker() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorResourcePicker);
}

// Methods
void godot_EditorResourcePicker__set_create_options(godot_EditorResourcePicker *self, const godot_Object *menu_node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePicker, _set_create_options, 3975164845, void, self, menu_node)
}
godot_bool godot_EditorResourcePicker__handle_menu_selected(godot_EditorResourcePicker *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePicker, _handle_menu_selected, 3067735520, godot_bool, self, &id)
}
void godot_EditorResourcePicker_set_base_type(godot_EditorResourcePicker *self, const godot_String *base_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePicker, set_base_type, 83702148, void, self, base_type)
}
godot_String godot_EditorResourcePicker_get_base_type(const godot_EditorResourcePicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePicker, get_base_type, 201670096, godot_String, self)
}
godot_PackedStringArray godot_EditorResourcePicker_get_allowed_types(const godot_EditorResourcePicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePicker, get_allowed_types, 1139954409, godot_PackedStringArray, self)
}
void godot_EditorResourcePicker_set_edited_resource(godot_EditorResourcePicker *self, const godot_Resource *resource) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePicker, set_edited_resource, 968641751, void, self, resource)
}
godot_Resource * godot_EditorResourcePicker_get_edited_resource(godot_EditorResourcePicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePicker, get_edited_resource, 2674603643, godot_Resource *, self)
}
void godot_EditorResourcePicker_set_toggle_mode(godot_EditorResourcePicker *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePicker, set_toggle_mode, 2586408642, void, self, &enable)
}
godot_bool godot_EditorResourcePicker_is_toggle_mode(const godot_EditorResourcePicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePicker, is_toggle_mode, 36873697, godot_bool, self)
}
void godot_EditorResourcePicker_set_toggle_pressed(godot_EditorResourcePicker *self, godot_bool pressed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePicker, set_toggle_pressed, 2586408642, void, self, &pressed)
}
void godot_EditorResourcePicker_set_editable(godot_EditorResourcePicker *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePicker, set_editable, 2586408642, void, self, &enable)
}
godot_bool godot_EditorResourcePicker_is_editable(const godot_EditorResourcePicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePicker, is_editable, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
