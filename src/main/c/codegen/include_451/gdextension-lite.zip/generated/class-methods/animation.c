// This file was automatically generated
// Do not modify this file
#include "animation.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Animation *godot_new_Animation() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Animation);
}

// Methods
godot_int godot_Animation_add_track(godot_Animation *self, godot_Animation_TrackType type, godot_int at_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, add_track, 3843682357, godot_int, self, &type, &at_position)
}
void godot_Animation_remove_track(godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, remove_track, 1286410249, void, self, &track_idx)
}
godot_int godot_Animation_get_track_count(const godot_Animation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_track_count, 3905245786, godot_int, self)
}
godot_Animation_TrackType godot_Animation_track_get_type(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_get_type, 3445944217, godot_Animation_TrackType, self, &track_idx)
}
godot_NodePath godot_Animation_track_get_path(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_get_path, 408788394, godot_NodePath, self, &track_idx)
}
void godot_Animation_track_set_path(godot_Animation *self, godot_int track_idx, const godot_NodePath *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_set_path, 2761262315, void, self, &track_idx, path)
}
godot_int godot_Animation_find_track(const godot_Animation *self, const godot_NodePath *path, godot_Animation_TrackType type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, find_track, 245376003, godot_int, self, path, &type)
}
void godot_Animation_track_move_up(godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_move_up, 1286410249, void, self, &track_idx)
}
void godot_Animation_track_move_down(godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_move_down, 1286410249, void, self, &track_idx)
}
void godot_Animation_track_move_to(godot_Animation *self, godot_int track_idx, godot_int to_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_move_to, 3937882851, void, self, &track_idx, &to_idx)
}
void godot_Animation_track_swap(godot_Animation *self, godot_int track_idx, godot_int with_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_swap, 3937882851, void, self, &track_idx, &with_idx)
}
void godot_Animation_track_set_imported(godot_Animation *self, godot_int track_idx, godot_bool imported) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_set_imported, 300928843, void, self, &track_idx, &imported)
}
godot_bool godot_Animation_track_is_imported(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_is_imported, 1116898809, godot_bool, self, &track_idx)
}
void godot_Animation_track_set_enabled(godot_Animation *self, godot_int track_idx, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_set_enabled, 300928843, void, self, &track_idx, &enabled)
}
godot_bool godot_Animation_track_is_enabled(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_is_enabled, 1116898809, godot_bool, self, &track_idx)
}
godot_int godot_Animation_position_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Vector3 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, position_track_insert_key, 2540608232, godot_int, self, &track_idx, &time, position)
}
godot_int godot_Animation_rotation_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Quaternion *rotation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, rotation_track_insert_key, 4165004800, godot_int, self, &track_idx, &time, rotation)
}
godot_int godot_Animation_scale_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Vector3 *scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, scale_track_insert_key, 2540608232, godot_int, self, &track_idx, &time, scale)
}
godot_int godot_Animation_blend_shape_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, blend_shape_track_insert_key, 1534913637, godot_int, self, &track_idx, &time, &amount)
}
godot_Vector3 godot_Animation_position_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, position_track_interpolate, 3530011197, godot_Vector3, self, &track_idx, &time_sec, &backward)
}
godot_Quaternion godot_Animation_rotation_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, rotation_track_interpolate, 2915876792, godot_Quaternion, self, &track_idx, &time_sec, &backward)
}
godot_Vector3 godot_Animation_scale_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, scale_track_interpolate, 3530011197, godot_Vector3, self, &track_idx, &time_sec, &backward)
}
godot_float godot_Animation_blend_shape_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, blend_shape_track_interpolate, 2482365182, godot_float, self, &track_idx, &time_sec, &backward)
}
godot_int godot_Animation_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Variant *key, godot_float transition) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_insert_key, 808952278, godot_int, self, &track_idx, &time, key, &transition)
}
void godot_Animation_track_remove_key(godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_remove_key, 3937882851, void, self, &track_idx, &key_idx)
}
void godot_Animation_track_remove_key_at_time(godot_Animation *self, godot_int track_idx, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_remove_key_at_time, 1602489585, void, self, &track_idx, &time)
}
void godot_Animation_track_set_key_value(godot_Animation *self, godot_int track_idx, godot_int key, const godot_Variant *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_set_key_value, 2060538656, void, self, &track_idx, &key, value)
}
void godot_Animation_track_set_key_transition(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float transition) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_set_key_transition, 3506521499, void, self, &track_idx, &key_idx, &transition)
}
void godot_Animation_track_set_key_time(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_set_key_time, 3506521499, void, self, &track_idx, &key_idx, &time)
}
godot_float godot_Animation_track_get_key_transition(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_get_key_transition, 3085491603, godot_float, self, &track_idx, &key_idx)
}
godot_int godot_Animation_track_get_key_count(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_get_key_count, 923996154, godot_int, self, &track_idx)
}
godot_Variant godot_Animation_track_get_key_value(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_get_key_value, 678354945, godot_Variant, self, &track_idx, &key_idx)
}
godot_float godot_Animation_track_get_key_time(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_get_key_time, 3085491603, godot_float, self, &track_idx, &key_idx)
}
godot_int godot_Animation_track_find_key(const godot_Animation *self, godot_int track_idx, godot_float time, godot_Animation_FindMode find_mode, godot_bool limit, godot_bool backward) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_find_key, 4230953007, godot_int, self, &track_idx, &time, &find_mode, &limit, &backward)
}
void godot_Animation_track_set_interpolation_type(godot_Animation *self, godot_int track_idx, godot_Animation_InterpolationType interpolation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_set_interpolation_type, 4112932513, void, self, &track_idx, &interpolation)
}
godot_Animation_InterpolationType godot_Animation_track_get_interpolation_type(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_get_interpolation_type, 1530756894, godot_Animation_InterpolationType, self, &track_idx)
}
void godot_Animation_track_set_interpolation_loop_wrap(godot_Animation *self, godot_int track_idx, godot_bool interpolation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, track_set_interpolation_loop_wrap, 300928843, void, self, &track_idx, &interpolation)
}
godot_bool godot_Animation_track_get_interpolation_loop_wrap(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_get_interpolation_loop_wrap, 1116898809, godot_bool, self, &track_idx)
}
godot_bool godot_Animation_track_is_compressed(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, track_is_compressed, 1116898809, godot_bool, self, &track_idx)
}
void godot_Animation_value_track_set_update_mode(godot_Animation *self, godot_int track_idx, godot_Animation_UpdateMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, value_track_set_update_mode, 2854058312, void, self, &track_idx, &mode)
}
godot_Animation_UpdateMode godot_Animation_value_track_get_update_mode(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, value_track_get_update_mode, 1440326473, godot_Animation_UpdateMode, self, &track_idx)
}
godot_Variant godot_Animation_value_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, value_track_interpolate, 747269075, godot_Variant, self, &track_idx, &time_sec, &backward)
}
godot_StringName godot_Animation_method_track_get_name(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, method_track_get_name, 351665558, godot_StringName, self, &track_idx, &key_idx)
}
godot_Array godot_Animation_method_track_get_params(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, method_track_get_params, 2345056839, godot_Array, self, &track_idx, &key_idx)
}
godot_int godot_Animation_bezier_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, godot_float value, const godot_Vector2 *in_handle, const godot_Vector2 *out_handle) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, bezier_track_insert_key, 3656773645, godot_int, self, &track_idx, &time, &value, in_handle, out_handle)
}
void godot_Animation_bezier_track_set_key_value(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, bezier_track_set_key_value, 3506521499, void, self, &track_idx, &key_idx, &value)
}
void godot_Animation_bezier_track_set_key_in_handle(godot_Animation *self, godot_int track_idx, godot_int key_idx, const godot_Vector2 *in_handle, godot_float balanced_value_time_ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, bezier_track_set_key_in_handle, 1719223284, void, self, &track_idx, &key_idx, in_handle, &balanced_value_time_ratio)
}
void godot_Animation_bezier_track_set_key_out_handle(godot_Animation *self, godot_int track_idx, godot_int key_idx, const godot_Vector2 *out_handle, godot_float balanced_value_time_ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, bezier_track_set_key_out_handle, 1719223284, void, self, &track_idx, &key_idx, out_handle, &balanced_value_time_ratio)
}
godot_float godot_Animation_bezier_track_get_key_value(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, bezier_track_get_key_value, 3085491603, godot_float, self, &track_idx, &key_idx)
}
godot_Vector2 godot_Animation_bezier_track_get_key_in_handle(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, bezier_track_get_key_in_handle, 3016396712, godot_Vector2, self, &track_idx, &key_idx)
}
godot_Vector2 godot_Animation_bezier_track_get_key_out_handle(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, bezier_track_get_key_out_handle, 3016396712, godot_Vector2, self, &track_idx, &key_idx)
}
godot_float godot_Animation_bezier_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, bezier_track_interpolate, 1900462983, godot_float, self, &track_idx, &time)
}
godot_int godot_Animation_audio_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Resource *stream, godot_float start_offset, godot_float end_offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, audio_track_insert_key, 4021027286, godot_int, self, &track_idx, &time, stream, &start_offset, &end_offset)
}
void godot_Animation_audio_track_set_key_stream(godot_Animation *self, godot_int track_idx, godot_int key_idx, const godot_Resource *stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, audio_track_set_key_stream, 3886397084, void, self, &track_idx, &key_idx, stream)
}
void godot_Animation_audio_track_set_key_start_offset(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, audio_track_set_key_start_offset, 3506521499, void, self, &track_idx, &key_idx, &offset)
}
void godot_Animation_audio_track_set_key_end_offset(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, audio_track_set_key_end_offset, 3506521499, void, self, &track_idx, &key_idx, &offset)
}
godot_Resource * godot_Animation_audio_track_get_key_stream(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, audio_track_get_key_stream, 635277205, godot_Resource *, self, &track_idx, &key_idx)
}
godot_float godot_Animation_audio_track_get_key_start_offset(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, audio_track_get_key_start_offset, 3085491603, godot_float, self, &track_idx, &key_idx)
}
godot_float godot_Animation_audio_track_get_key_end_offset(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, audio_track_get_key_end_offset, 3085491603, godot_float, self, &track_idx, &key_idx)
}
void godot_Animation_audio_track_set_use_blend(godot_Animation *self, godot_int track_idx, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, audio_track_set_use_blend, 300928843, void, self, &track_idx, &enable)
}
godot_bool godot_Animation_audio_track_is_use_blend(const godot_Animation *self, godot_int track_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, audio_track_is_use_blend, 1116898809, godot_bool, self, &track_idx)
}
godot_int godot_Animation_animation_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_StringName *animation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, animation_track_insert_key, 158676774, godot_int, self, &track_idx, &time, animation)
}
void godot_Animation_animation_track_set_key_animation(godot_Animation *self, godot_int track_idx, godot_int key_idx, const godot_StringName *animation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, animation_track_set_key_animation, 117615382, void, self, &track_idx, &key_idx, animation)
}
godot_StringName godot_Animation_animation_track_get_key_animation(const godot_Animation *self, godot_int track_idx, godot_int key_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, animation_track_get_key_animation, 351665558, godot_StringName, self, &track_idx, &key_idx)
}
void godot_Animation_add_marker(godot_Animation *self, const godot_StringName *name, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, add_marker, 4135858297, void, self, name, &time)
}
void godot_Animation_remove_marker(godot_Animation *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, remove_marker, 3304788590, void, self, name)
}
godot_bool godot_Animation_has_marker(const godot_Animation *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, has_marker, 2619796661, godot_bool, self, name)
}
godot_StringName godot_Animation_get_marker_at_time(const godot_Animation *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_marker_at_time, 4079494655, godot_StringName, self, &time)
}
godot_StringName godot_Animation_get_next_marker(const godot_Animation *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_next_marker, 4079494655, godot_StringName, self, &time)
}
godot_StringName godot_Animation_get_prev_marker(const godot_Animation *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_prev_marker, 4079494655, godot_StringName, self, &time)
}
godot_float godot_Animation_get_marker_time(const godot_Animation *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_marker_time, 2349060816, godot_float, self, name)
}
godot_PackedStringArray godot_Animation_get_marker_names(const godot_Animation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_marker_names, 1139954409, godot_PackedStringArray, self)
}
godot_Color godot_Animation_get_marker_color(const godot_Animation *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_marker_color, 3742943038, godot_Color, self, name)
}
void godot_Animation_set_marker_color(godot_Animation *self, const godot_StringName *name, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, set_marker_color, 4260178595, void, self, name, color)
}
void godot_Animation_set_length(godot_Animation *self, godot_float time_sec) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, set_length, 373806689, void, self, &time_sec)
}
godot_float godot_Animation_get_length(const godot_Animation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_length, 1740695150, godot_float, self)
}
void godot_Animation_set_loop_mode(godot_Animation *self, godot_Animation_LoopMode loop_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, set_loop_mode, 3155355575, void, self, &loop_mode)
}
godot_Animation_LoopMode godot_Animation_get_loop_mode(const godot_Animation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_loop_mode, 1988889481, godot_Animation_LoopMode, self)
}
void godot_Animation_set_step(godot_Animation *self, godot_float size_sec) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, set_step, 373806689, void, self, &size_sec)
}
godot_float godot_Animation_get_step(const godot_Animation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, get_step, 1740695150, godot_float, self)
}
void godot_Animation_clear(godot_Animation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, clear, 3218959716, void, self)
}
void godot_Animation_copy_track(godot_Animation *self, godot_int track_idx, const godot_Animation *to_animation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, copy_track, 148001024, void, self, &track_idx, to_animation)
}
void godot_Animation_optimize(godot_Animation *self, godot_float allowed_velocity_err, godot_float allowed_angular_err, godot_int precision) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, optimize, 3303583852, void, self, &allowed_velocity_err, &allowed_angular_err, &precision)
}
void godot_Animation_compress(godot_Animation *self, godot_int page_size, godot_int fps, godot_float split_tolerance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Animation, compress, 3608408117, void, self, &page_size, &fps, &split_tolerance)
}
godot_bool godot_Animation_is_capture_included(const godot_Animation *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Animation, is_capture_included, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
