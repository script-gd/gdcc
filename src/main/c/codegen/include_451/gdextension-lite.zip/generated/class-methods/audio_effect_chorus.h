// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_CHORUS_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_CHORUS_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectChorus *godot_new_AudioEffectChorus();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_voice_count(godot_AudioEffectChorus *self, godot_int voices);
GDEXTENSION_LITE_DECL godot_int godot_AudioEffectChorus_get_voice_count(const godot_AudioEffectChorus *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_voice_delay_ms(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float delay_ms);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectChorus_get_voice_delay_ms(const godot_AudioEffectChorus *self, godot_int voice_idx);
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_voice_rate_hz(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float rate_hz);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectChorus_get_voice_rate_hz(const godot_AudioEffectChorus *self, godot_int voice_idx);
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_voice_depth_ms(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float depth_ms);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectChorus_get_voice_depth_ms(const godot_AudioEffectChorus *self, godot_int voice_idx);
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_voice_level_db(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float level_db);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectChorus_get_voice_level_db(const godot_AudioEffectChorus *self, godot_int voice_idx);
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_voice_cutoff_hz(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float cutoff_hz);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectChorus_get_voice_cutoff_hz(const godot_AudioEffectChorus *self, godot_int voice_idx);
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_voice_pan(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float pan);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectChorus_get_voice_pan(const godot_AudioEffectChorus *self, godot_int voice_idx);
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_wet(godot_AudioEffectChorus *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectChorus_get_wet(const godot_AudioEffectChorus *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectChorus_set_dry(godot_AudioEffectChorus *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectChorus_get_dry(const godot_AudioEffectChorus *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_CHORUS_H__
