// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIR_ACCESS_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIR_ACCESS_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL godot_DirAccess * godot_DirAccess_open(const godot_String *path);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_get_open_error();
GDEXTENSION_LITE_DECL godot_DirAccess * godot_DirAccess_create_temp(const godot_String *prefix, godot_bool keep);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_list_dir_begin(godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_String godot_DirAccess_get_next(godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_current_is_dir(const godot_DirAccess *self);
GDEXTENSION_LITE_DECL void godot_DirAccess_list_dir_end(godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_DirAccess_get_files(godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_DirAccess_get_files_at(const godot_String *path);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_DirAccess_get_directories(godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_DirAccess_get_directories_at(const godot_String *path);
GDEXTENSION_LITE_DECL godot_int godot_DirAccess_get_drive_count();
GDEXTENSION_LITE_DECL godot_String godot_DirAccess_get_drive_name(godot_int idx);
GDEXTENSION_LITE_DECL godot_int godot_DirAccess_get_current_drive(godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_change_dir(godot_DirAccess *self, const godot_String *to_dir);
GDEXTENSION_LITE_DECL godot_String godot_DirAccess_get_current_dir(const godot_DirAccess *self, godot_bool include_drive);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_make_dir(godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_make_dir_absolute(const godot_String *path);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_make_dir_recursive(godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_make_dir_recursive_absolute(const godot_String *path);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_file_exists(godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_dir_exists(godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_dir_exists_absolute(const godot_String *path);
GDEXTENSION_LITE_DECL godot_int godot_DirAccess_get_space_left(godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_copy(godot_DirAccess *self, const godot_String *from, const godot_String *to, godot_int chmod_flags);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_copy_absolute(const godot_String *from, const godot_String *to, godot_int chmod_flags);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_rename(godot_DirAccess *self, const godot_String *from, const godot_String *to);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_rename_absolute(const godot_String *from, const godot_String *to);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_remove(godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_remove_absolute(const godot_String *path);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_is_link(godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_String godot_DirAccess_read_link(godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Error godot_DirAccess_create_link(godot_DirAccess *self, const godot_String *source, const godot_String *target);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_is_bundle(const godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_DirAccess_set_include_navigational(godot_DirAccess *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_get_include_navigational(const godot_DirAccess *self);
GDEXTENSION_LITE_DECL void godot_DirAccess_set_include_hidden(godot_DirAccess *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_get_include_hidden(const godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_String godot_DirAccess_get_filesystem_type(const godot_DirAccess *self);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_is_case_sensitive(const godot_DirAccess *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_bool godot_DirAccess_is_equivalent(const godot_DirAccess *self, const godot_String *path_a, const godot_String *path_b);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DIR_ACCESS_H__
