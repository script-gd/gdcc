// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CompressedTexture3D *godot_new_CompressedTexture3D();

// Methods
GDEXTENSION_LITE_DECL godot_Error godot_CompressedTexture3D_load(godot_CompressedTexture3D *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_String godot_CompressedTexture3D_get_load_path(const godot_CompressedTexture3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE3D_H__
