// This file was automatically generated
// Do not modify this file
#include "audio_stream_ogg_vorbis.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamOggVorbis *godot_new_AudioStreamOggVorbis() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamOggVorbis);
}

// Methods
godot_AudioStreamOggVorbis * godot_AudioStreamOggVorbis_load_from_buffer(const godot_PackedByteArray *stream_data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, load_from_buffer, 354904730, godot_AudioStreamOggVorbis *, NULL, stream_data)
}
godot_AudioStreamOggVorbis * godot_AudioStreamOggVorbis_load_from_file(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, load_from_file, 797568536, godot_AudioStreamOggVorbis *, NULL, path)
}
void godot_AudioStreamOggVorbis_set_packet_sequence(godot_AudioStreamOggVorbis *self, const godot_OggPacketSequence *packet_sequence) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamOggVorbis, set_packet_sequence, 438882457, void, self, packet_sequence)
}
godot_OggPacketSequence * godot_AudioStreamOggVorbis_get_packet_sequence(const godot_AudioStreamOggVorbis *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, get_packet_sequence, 2801636033, godot_OggPacketSequence *, self)
}
void godot_AudioStreamOggVorbis_set_loop(godot_AudioStreamOggVorbis *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamOggVorbis, set_loop, 2586408642, void, self, &enable)
}
godot_bool godot_AudioStreamOggVorbis_has_loop(const godot_AudioStreamOggVorbis *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, has_loop, 36873697, godot_bool, self)
}
void godot_AudioStreamOggVorbis_set_loop_offset(godot_AudioStreamOggVorbis *self, godot_float seconds) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamOggVorbis, set_loop_offset, 373806689, void, self, &seconds)
}
godot_float godot_AudioStreamOggVorbis_get_loop_offset(const godot_AudioStreamOggVorbis *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, get_loop_offset, 1740695150, godot_float, self)
}
void godot_AudioStreamOggVorbis_set_bpm(godot_AudioStreamOggVorbis *self, godot_float bpm) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamOggVorbis, set_bpm, 373806689, void, self, &bpm)
}
godot_float godot_AudioStreamOggVorbis_get_bpm(const godot_AudioStreamOggVorbis *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, get_bpm, 1740695150, godot_float, self)
}
void godot_AudioStreamOggVorbis_set_beat_count(godot_AudioStreamOggVorbis *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamOggVorbis, set_beat_count, 1286410249, void, self, &count)
}
godot_int godot_AudioStreamOggVorbis_get_beat_count(const godot_AudioStreamOggVorbis *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, get_beat_count, 3905245786, godot_int, self)
}
void godot_AudioStreamOggVorbis_set_bar_beats(godot_AudioStreamOggVorbis *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamOggVorbis, set_bar_beats, 1286410249, void, self, &count)
}
godot_int godot_AudioStreamOggVorbis_get_bar_beats(const godot_AudioStreamOggVorbis *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, get_bar_beats, 3905245786, godot_int, self)
}
void godot_AudioStreamOggVorbis_set_tags(godot_AudioStreamOggVorbis *self, const godot_Dictionary *tags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamOggVorbis, set_tags, 4155329257, void, self, tags)
}
godot_Dictionary godot_AudioStreamOggVorbis_get_tags(const godot_AudioStreamOggVorbis *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamOggVorbis, get_tags, 3102165223, godot_Dictionary, self)
}


#ifdef __cplusplus
}
#endif
