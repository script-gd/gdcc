// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ATLAS_TEXTURE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ATLAS_TEXTURE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AtlasTexture *godot_new_AtlasTexture();

// Methods
GDEXTENSION_LITE_DECL void godot_AtlasTexture_set_atlas(godot_AtlasTexture *self, const godot_Texture2D *atlas);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_AtlasTexture_get_atlas(const godot_AtlasTexture *self);
GDEXTENSION_LITE_DECL void godot_AtlasTexture_set_region(godot_AtlasTexture *self, const godot_Rect2 *region);
GDEXTENSION_LITE_DECL godot_Rect2 godot_AtlasTexture_get_region(const godot_AtlasTexture *self);
GDEXTENSION_LITE_DECL void godot_AtlasTexture_set_margin(godot_AtlasTexture *self, const godot_Rect2 *margin);
GDEXTENSION_LITE_DECL godot_Rect2 godot_AtlasTexture_get_margin(const godot_AtlasTexture *self);
GDEXTENSION_LITE_DECL void godot_AtlasTexture_set_filter_clip(godot_AtlasTexture *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AtlasTexture_has_filter_clip(const godot_AtlasTexture *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ATLAS_TEXTURE_H__
