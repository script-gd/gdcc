// This file was automatically generated
// Do not modify this file
#include "editor_export_platform_linux_bsd.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlatformLinuxBSD *godot_new_EditorExportPlatformLinuxBSD() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlatformLinuxBSD);
}


#ifdef __cplusplus
}
#endif
