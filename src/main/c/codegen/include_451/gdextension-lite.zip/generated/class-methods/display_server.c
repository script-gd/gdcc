// This file was automatically generated
// Do not modify this file
#include "display_server.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
godot_DisplayServer *godot_DisplayServer_singleton() {
	GDEXTENSION_LITE_GET_SINGLETON_IMPL(DisplayServer, "DisplayServer");
}

// Methods
godot_bool godot_DisplayServer_has_feature(const godot_DisplayServer *self, godot_DisplayServer_Feature feature) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, has_feature, 334065950, godot_bool, self, &feature)
}
godot_String godot_DisplayServer_get_name(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_name, 201670096, godot_String, self)
}
void godot_DisplayServer_help_set_search_callbacks(godot_DisplayServer *self, const godot_Callable *search_callback, const godot_Callable *action_callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, help_set_search_callbacks, 1687350599, void, self, search_callback, action_callback)
}
void godot_DisplayServer_global_menu_set_popup_callbacks(godot_DisplayServer *self, const godot_String *menu_root, const godot_Callable *open_callback, const godot_Callable *close_callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_popup_callbacks, 3893727526, void, self, menu_root, open_callback, close_callback)
}
godot_int godot_DisplayServer_global_menu_add_submenu_item(godot_DisplayServer *self, const godot_String *menu_root, const godot_String *label, const godot_String *submenu, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_submenu_item, 2828985934, godot_int, self, menu_root, label, submenu, &index)
}
godot_int godot_DisplayServer_global_menu_add_item(godot_DisplayServer *self, const godot_String *menu_root, const godot_String *label, const godot_Callable *callback, const godot_Callable *key_callback, const godot_Variant *tag, godot_Key accelerator, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_item, 3616842746, godot_int, self, menu_root, label, callback, key_callback, tag, &accelerator, &index)
}
godot_int godot_DisplayServer_global_menu_add_check_item(godot_DisplayServer *self, const godot_String *menu_root, const godot_String *label, const godot_Callable *callback, const godot_Callable *key_callback, const godot_Variant *tag, godot_Key accelerator, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_check_item, 3616842746, godot_int, self, menu_root, label, callback, key_callback, tag, &accelerator, &index)
}
godot_int godot_DisplayServer_global_menu_add_icon_item(godot_DisplayServer *self, const godot_String *menu_root, const godot_Texture2D *icon, const godot_String *label, const godot_Callable *callback, const godot_Callable *key_callback, const godot_Variant *tag, godot_Key accelerator, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_icon_item, 3867083847, godot_int, self, menu_root, icon, label, callback, key_callback, tag, &accelerator, &index)
}
godot_int godot_DisplayServer_global_menu_add_icon_check_item(godot_DisplayServer *self, const godot_String *menu_root, const godot_Texture2D *icon, const godot_String *label, const godot_Callable *callback, const godot_Callable *key_callback, const godot_Variant *tag, godot_Key accelerator, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_icon_check_item, 3867083847, godot_int, self, menu_root, icon, label, callback, key_callback, tag, &accelerator, &index)
}
godot_int godot_DisplayServer_global_menu_add_radio_check_item(godot_DisplayServer *self, const godot_String *menu_root, const godot_String *label, const godot_Callable *callback, const godot_Callable *key_callback, const godot_Variant *tag, godot_Key accelerator, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_radio_check_item, 3616842746, godot_int, self, menu_root, label, callback, key_callback, tag, &accelerator, &index)
}
godot_int godot_DisplayServer_global_menu_add_icon_radio_check_item(godot_DisplayServer *self, const godot_String *menu_root, const godot_Texture2D *icon, const godot_String *label, const godot_Callable *callback, const godot_Callable *key_callback, const godot_Variant *tag, godot_Key accelerator, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_icon_radio_check_item, 3867083847, godot_int, self, menu_root, icon, label, callback, key_callback, tag, &accelerator, &index)
}
godot_int godot_DisplayServer_global_menu_add_multistate_item(godot_DisplayServer *self, const godot_String *menu_root, const godot_String *label, godot_int max_states, godot_int default_state, const godot_Callable *callback, const godot_Callable *key_callback, const godot_Variant *tag, godot_Key accelerator, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_multistate_item, 3297554655, godot_int, self, menu_root, label, &max_states, &default_state, callback, key_callback, tag, &accelerator, &index)
}
godot_int godot_DisplayServer_global_menu_add_separator(godot_DisplayServer *self, const godot_String *menu_root, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_add_separator, 3214812433, godot_int, self, menu_root, &index)
}
godot_int godot_DisplayServer_global_menu_get_item_index_from_text(const godot_DisplayServer *self, const godot_String *menu_root, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_index_from_text, 2878152881, godot_int, self, menu_root, text)
}
godot_int godot_DisplayServer_global_menu_get_item_index_from_tag(const godot_DisplayServer *self, const godot_String *menu_root, const godot_Variant *tag) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_index_from_tag, 2941063483, godot_int, self, menu_root, tag)
}
godot_bool godot_DisplayServer_global_menu_is_item_checked(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_is_item_checked, 3511468594, godot_bool, self, menu_root, &idx)
}
godot_bool godot_DisplayServer_global_menu_is_item_checkable(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_is_item_checkable, 3511468594, godot_bool, self, menu_root, &idx)
}
godot_bool godot_DisplayServer_global_menu_is_item_radio_checkable(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_is_item_radio_checkable, 3511468594, godot_bool, self, menu_root, &idx)
}
godot_Callable godot_DisplayServer_global_menu_get_item_callback(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_callback, 748666903, godot_Callable, self, menu_root, &idx)
}
godot_Callable godot_DisplayServer_global_menu_get_item_key_callback(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_key_callback, 748666903, godot_Callable, self, menu_root, &idx)
}
godot_Variant godot_DisplayServer_global_menu_get_item_tag(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_tag, 330672633, godot_Variant, self, menu_root, &idx)
}
godot_String godot_DisplayServer_global_menu_get_item_text(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_text, 591067909, godot_String, self, menu_root, &idx)
}
godot_String godot_DisplayServer_global_menu_get_item_submenu(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_submenu, 591067909, godot_String, self, menu_root, &idx)
}
godot_Key godot_DisplayServer_global_menu_get_item_accelerator(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_accelerator, 936065394, godot_Key, self, menu_root, &idx)
}
godot_bool godot_DisplayServer_global_menu_is_item_disabled(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_is_item_disabled, 3511468594, godot_bool, self, menu_root, &idx)
}
godot_bool godot_DisplayServer_global_menu_is_item_hidden(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_is_item_hidden, 3511468594, godot_bool, self, menu_root, &idx)
}
godot_String godot_DisplayServer_global_menu_get_item_tooltip(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_tooltip, 591067909, godot_String, self, menu_root, &idx)
}
godot_int godot_DisplayServer_global_menu_get_item_state(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_state, 3422818498, godot_int, self, menu_root, &idx)
}
godot_int godot_DisplayServer_global_menu_get_item_max_states(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_max_states, 3422818498, godot_int, self, menu_root, &idx)
}
godot_Texture2D * godot_DisplayServer_global_menu_get_item_icon(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_icon, 3591713183, godot_Texture2D *, self, menu_root, &idx)
}
godot_int godot_DisplayServer_global_menu_get_item_indentation_level(const godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_indentation_level, 3422818498, godot_int, self, menu_root, &idx)
}
void godot_DisplayServer_global_menu_set_item_checked(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_bool checked) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_checked, 4108344793, void, self, menu_root, &idx, &checked)
}
void godot_DisplayServer_global_menu_set_item_checkable(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_bool checkable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_checkable, 4108344793, void, self, menu_root, &idx, &checkable)
}
void godot_DisplayServer_global_menu_set_item_radio_checkable(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_bool checkable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_radio_checkable, 4108344793, void, self, menu_root, &idx, &checkable)
}
void godot_DisplayServer_global_menu_set_item_callback(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, const godot_Callable *callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_callback, 3809915389, void, self, menu_root, &idx, callback)
}
void godot_DisplayServer_global_menu_set_item_hover_callbacks(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, const godot_Callable *callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_hover_callbacks, 3809915389, void, self, menu_root, &idx, callback)
}
void godot_DisplayServer_global_menu_set_item_key_callback(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, const godot_Callable *key_callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_key_callback, 3809915389, void, self, menu_root, &idx, key_callback)
}
void godot_DisplayServer_global_menu_set_item_tag(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, const godot_Variant *tag) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_tag, 453659863, void, self, menu_root, &idx, tag)
}
void godot_DisplayServer_global_menu_set_item_text(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_text, 965966136, void, self, menu_root, &idx, text)
}
void godot_DisplayServer_global_menu_set_item_submenu(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, const godot_String *submenu) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_submenu, 965966136, void, self, menu_root, &idx, submenu)
}
void godot_DisplayServer_global_menu_set_item_accelerator(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_Key keycode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_accelerator, 566943293, void, self, menu_root, &idx, &keycode)
}
void godot_DisplayServer_global_menu_set_item_disabled(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_bool disabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_disabled, 4108344793, void, self, menu_root, &idx, &disabled)
}
void godot_DisplayServer_global_menu_set_item_hidden(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_bool hidden) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_hidden, 4108344793, void, self, menu_root, &idx, &hidden)
}
void godot_DisplayServer_global_menu_set_item_tooltip(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, const godot_String *tooltip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_tooltip, 965966136, void, self, menu_root, &idx, tooltip)
}
void godot_DisplayServer_global_menu_set_item_state(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_int state) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_state, 3474840532, void, self, menu_root, &idx, &state)
}
void godot_DisplayServer_global_menu_set_item_max_states(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_int max_states) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_max_states, 3474840532, void, self, menu_root, &idx, &max_states)
}
void godot_DisplayServer_global_menu_set_item_icon(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, const godot_Texture2D *icon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_icon, 3201338066, void, self, menu_root, &idx, icon)
}
void godot_DisplayServer_global_menu_set_item_indentation_level(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx, godot_int level) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_set_item_indentation_level, 3474840532, void, self, menu_root, &idx, &level)
}
godot_int godot_DisplayServer_global_menu_get_item_count(const godot_DisplayServer *self, const godot_String *menu_root) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_item_count, 1321353865, godot_int, self, menu_root)
}
void godot_DisplayServer_global_menu_remove_item(godot_DisplayServer *self, const godot_String *menu_root, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_remove_item, 2956805083, void, self, menu_root, &idx)
}
void godot_DisplayServer_global_menu_clear(godot_DisplayServer *self, const godot_String *menu_root) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, global_menu_clear, 83702148, void, self, menu_root)
}
godot_Dictionary godot_DisplayServer_global_menu_get_system_menu_roots(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, global_menu_get_system_menu_roots, 3102165223, godot_Dictionary, self)
}
godot_bool godot_DisplayServer_tts_is_speaking(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, tts_is_speaking, 36873697, godot_bool, self)
}
godot_bool godot_DisplayServer_tts_is_paused(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, tts_is_paused, 36873697, godot_bool, self)
}
godot_TypedArray(godot_Dictionary) godot_DisplayServer_tts_get_voices(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, tts_get_voices, 3995934104, godot_TypedArray(godot_Dictionary), self)
}
godot_PackedStringArray godot_DisplayServer_tts_get_voices_for_language(const godot_DisplayServer *self, const godot_String *language) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, tts_get_voices_for_language, 4291131558, godot_PackedStringArray, self, language)
}
void godot_DisplayServer_tts_speak(godot_DisplayServer *self, const godot_String *text, const godot_String *voice, godot_int volume, godot_float pitch, godot_float rate, godot_int utterance_id, godot_bool interrupt) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, tts_speak, 903992738, void, self, text, voice, &volume, &pitch, &rate, &utterance_id, &interrupt)
}
void godot_DisplayServer_tts_pause(godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, tts_pause, 3218959716, void, self)
}
void godot_DisplayServer_tts_resume(godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, tts_resume, 3218959716, void, self)
}
void godot_DisplayServer_tts_stop(godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, tts_stop, 3218959716, void, self)
}
void godot_DisplayServer_tts_set_utterance_callback(godot_DisplayServer *self, godot_DisplayServer_TTSUtteranceEvent event, const godot_Callable *callable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, tts_set_utterance_callback, 109679083, void, self, &event, callable)
}
godot_bool godot_DisplayServer_is_dark_mode_supported(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, is_dark_mode_supported, 36873697, godot_bool, self)
}
godot_bool godot_DisplayServer_is_dark_mode(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, is_dark_mode, 36873697, godot_bool, self)
}
godot_Color godot_DisplayServer_get_accent_color(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_accent_color, 3444240500, godot_Color, self)
}
godot_Color godot_DisplayServer_get_base_color(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_base_color, 3444240500, godot_Color, self)
}
void godot_DisplayServer_set_system_theme_change_callback(godot_DisplayServer *self, const godot_Callable *callable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, set_system_theme_change_callback, 1611583062, void, self, callable)
}
void godot_DisplayServer_mouse_set_mode(godot_DisplayServer *self, godot_DisplayServer_MouseMode mouse_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, mouse_set_mode, 348288463, void, self, &mouse_mode)
}
godot_DisplayServer_MouseMode godot_DisplayServer_mouse_get_mode(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, mouse_get_mode, 1353961651, godot_DisplayServer_MouseMode, self)
}
void godot_DisplayServer_warp_mouse(godot_DisplayServer *self, const godot_Vector2i *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, warp_mouse, 1130785943, void, self, position)
}
godot_Vector2i godot_DisplayServer_mouse_get_position(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, mouse_get_position, 3690982128, godot_Vector2i, self)
}
godot_MouseButtonMask godot_DisplayServer_mouse_get_button_state(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, mouse_get_button_state, 2512161324, godot_MouseButtonMask, self)
}
void godot_DisplayServer_clipboard_set(godot_DisplayServer *self, const godot_String *clipboard) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, clipboard_set, 83702148, void, self, clipboard)
}
godot_String godot_DisplayServer_clipboard_get(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, clipboard_get, 201670096, godot_String, self)
}
godot_Image * godot_DisplayServer_clipboard_get_image(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, clipboard_get_image, 4190603485, godot_Image *, self)
}
godot_bool godot_DisplayServer_clipboard_has(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, clipboard_has, 36873697, godot_bool, self)
}
godot_bool godot_DisplayServer_clipboard_has_image(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, clipboard_has_image, 36873697, godot_bool, self)
}
void godot_DisplayServer_clipboard_set_primary(godot_DisplayServer *self, const godot_String *clipboard_primary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, clipboard_set_primary, 83702148, void, self, clipboard_primary)
}
godot_String godot_DisplayServer_clipboard_get_primary(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, clipboard_get_primary, 201670096, godot_String, self)
}
godot_TypedArray(godot_Rect2) godot_DisplayServer_get_display_cutouts(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_display_cutouts, 3995934104, godot_TypedArray(godot_Rect2), self)
}
godot_Rect2i godot_DisplayServer_get_display_safe_area(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_display_safe_area, 410525958, godot_Rect2i, self)
}
godot_int godot_DisplayServer_get_screen_count(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_screen_count, 3905245786, godot_int, self)
}
godot_int godot_DisplayServer_get_primary_screen(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_primary_screen, 3905245786, godot_int, self)
}
godot_int godot_DisplayServer_get_keyboard_focus_screen(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_keyboard_focus_screen, 3905245786, godot_int, self)
}
godot_int godot_DisplayServer_get_screen_from_rect(const godot_DisplayServer *self, const godot_Rect2 *rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_screen_from_rect, 741354659, godot_int, self, rect)
}
godot_Vector2i godot_DisplayServer_screen_get_position(const godot_DisplayServer *self, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_position, 1725937825, godot_Vector2i, self, &screen)
}
godot_Vector2i godot_DisplayServer_screen_get_size(const godot_DisplayServer *self, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_size, 1725937825, godot_Vector2i, self, &screen)
}
godot_Rect2i godot_DisplayServer_screen_get_usable_rect(const godot_DisplayServer *self, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_usable_rect, 2439012528, godot_Rect2i, self, &screen)
}
godot_int godot_DisplayServer_screen_get_dpi(const godot_DisplayServer *self, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_dpi, 181039630, godot_int, self, &screen)
}
godot_float godot_DisplayServer_screen_get_scale(const godot_DisplayServer *self, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_scale, 909105437, godot_float, self, &screen)
}
godot_bool godot_DisplayServer_is_touchscreen_available(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, is_touchscreen_available, 36873697, godot_bool, self)
}
godot_float godot_DisplayServer_screen_get_max_scale(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_max_scale, 1740695150, godot_float, self)
}
godot_float godot_DisplayServer_screen_get_refresh_rate(const godot_DisplayServer *self, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_refresh_rate, 909105437, godot_float, self, &screen)
}
godot_Color godot_DisplayServer_screen_get_pixel(const godot_DisplayServer *self, const godot_Vector2i *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_pixel, 1532707496, godot_Color, self, position)
}
godot_Image * godot_DisplayServer_screen_get_image(const godot_DisplayServer *self, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_image, 3813388802, godot_Image *, self, &screen)
}
godot_Image * godot_DisplayServer_screen_get_image_rect(const godot_DisplayServer *self, const godot_Rect2i *rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_image_rect, 2601441065, godot_Image *, self, rect)
}
void godot_DisplayServer_screen_set_orientation(godot_DisplayServer *self, godot_DisplayServer_ScreenOrientation orientation, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, screen_set_orientation, 2211511631, void, self, &orientation, &screen)
}
godot_DisplayServer_ScreenOrientation godot_DisplayServer_screen_get_orientation(const godot_DisplayServer *self, godot_int screen) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_get_orientation, 133818562, godot_DisplayServer_ScreenOrientation, self, &screen)
}
void godot_DisplayServer_screen_set_keep_on(godot_DisplayServer *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, screen_set_keep_on, 2586408642, void, self, &enable)
}
godot_bool godot_DisplayServer_screen_is_kept_on(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, screen_is_kept_on, 36873697, godot_bool, self)
}
godot_PackedInt32Array godot_DisplayServer_get_window_list(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_window_list, 1930428628, godot_PackedInt32Array, self)
}
godot_int godot_DisplayServer_get_window_at_screen_position(const godot_DisplayServer *self, const godot_Vector2i *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_window_at_screen_position, 2485466453, godot_int, self, position)
}
godot_int godot_DisplayServer_window_get_native_handle(const godot_DisplayServer *self, godot_DisplayServer_HandleType handle_type, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_native_handle, 1096425680, godot_int, self, &handle_type, &window_id)
}
godot_int godot_DisplayServer_window_get_active_popup(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_active_popup, 3905245786, godot_int, self)
}
void godot_DisplayServer_window_set_popup_safe_rect(godot_DisplayServer *self, godot_int window, const godot_Rect2i *rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_popup_safe_rect, 3317281434, void, self, &window, rect)
}
godot_Rect2i godot_DisplayServer_window_get_popup_safe_rect(const godot_DisplayServer *self, godot_int window) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_popup_safe_rect, 2161169500, godot_Rect2i, self, &window)
}
void godot_DisplayServer_window_set_title(godot_DisplayServer *self, const godot_String *title, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_title, 441246282, void, self, title, &window_id)
}
godot_Vector2i godot_DisplayServer_window_get_title_size(const godot_DisplayServer *self, const godot_String *title, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_title_size, 2925301799, godot_Vector2i, self, title, &window_id)
}
void godot_DisplayServer_window_set_mouse_passthrough(godot_DisplayServer *self, const godot_PackedVector2Array *region, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_mouse_passthrough, 1993637420, void, self, region, &window_id)
}
godot_int godot_DisplayServer_window_get_current_screen(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_current_screen, 1591665591, godot_int, self, &window_id)
}
void godot_DisplayServer_window_set_current_screen(godot_DisplayServer *self, godot_int screen, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_current_screen, 2230941749, void, self, &screen, &window_id)
}
godot_Vector2i godot_DisplayServer_window_get_position(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_position, 763922886, godot_Vector2i, self, &window_id)
}
godot_Vector2i godot_DisplayServer_window_get_position_with_decorations(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_position_with_decorations, 763922886, godot_Vector2i, self, &window_id)
}
void godot_DisplayServer_window_set_position(godot_DisplayServer *self, const godot_Vector2i *position, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_position, 2019273902, void, self, position, &window_id)
}
godot_Vector2i godot_DisplayServer_window_get_size(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_size, 763922886, godot_Vector2i, self, &window_id)
}
void godot_DisplayServer_window_set_size(godot_DisplayServer *self, const godot_Vector2i *size, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_size, 2019273902, void, self, size, &window_id)
}
void godot_DisplayServer_window_set_rect_changed_callback(godot_DisplayServer *self, const godot_Callable *callback, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_rect_changed_callback, 1091192925, void, self, callback, &window_id)
}
void godot_DisplayServer_window_set_window_event_callback(godot_DisplayServer *self, const godot_Callable *callback, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_window_event_callback, 1091192925, void, self, callback, &window_id)
}
void godot_DisplayServer_window_set_input_event_callback(godot_DisplayServer *self, const godot_Callable *callback, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_input_event_callback, 1091192925, void, self, callback, &window_id)
}
void godot_DisplayServer_window_set_input_text_callback(godot_DisplayServer *self, const godot_Callable *callback, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_input_text_callback, 1091192925, void, self, callback, &window_id)
}
void godot_DisplayServer_window_set_drop_files_callback(godot_DisplayServer *self, const godot_Callable *callback, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_drop_files_callback, 1091192925, void, self, callback, &window_id)
}
godot_int godot_DisplayServer_window_get_attached_instance_id(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_attached_instance_id, 1591665591, godot_int, self, &window_id)
}
godot_Vector2i godot_DisplayServer_window_get_max_size(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_max_size, 763922886, godot_Vector2i, self, &window_id)
}
void godot_DisplayServer_window_set_max_size(godot_DisplayServer *self, const godot_Vector2i *max_size, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_max_size, 2019273902, void, self, max_size, &window_id)
}
godot_Vector2i godot_DisplayServer_window_get_min_size(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_min_size, 763922886, godot_Vector2i, self, &window_id)
}
void godot_DisplayServer_window_set_min_size(godot_DisplayServer *self, const godot_Vector2i *min_size, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_min_size, 2019273902, void, self, min_size, &window_id)
}
godot_Vector2i godot_DisplayServer_window_get_size_with_decorations(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_size_with_decorations, 763922886, godot_Vector2i, self, &window_id)
}
godot_DisplayServer_WindowMode godot_DisplayServer_window_get_mode(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_mode, 2185728461, godot_DisplayServer_WindowMode, self, &window_id)
}
void godot_DisplayServer_window_set_mode(godot_DisplayServer *self, godot_DisplayServer_WindowMode mode, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_mode, 1319965401, void, self, &mode, &window_id)
}
void godot_DisplayServer_window_set_flag(godot_DisplayServer *self, godot_DisplayServer_WindowFlags flag, godot_bool enabled, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_flag, 254894155, void, self, &flag, &enabled, &window_id)
}
godot_bool godot_DisplayServer_window_get_flag(const godot_DisplayServer *self, godot_DisplayServer_WindowFlags flag, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_flag, 802816991, godot_bool, self, &flag, &window_id)
}
void godot_DisplayServer_window_set_window_buttons_offset(godot_DisplayServer *self, const godot_Vector2i *offset, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_window_buttons_offset, 2019273902, void, self, offset, &window_id)
}
godot_Vector3i godot_DisplayServer_window_get_safe_title_margins(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_safe_title_margins, 2295066620, godot_Vector3i, self, &window_id)
}
void godot_DisplayServer_window_request_attention(godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_request_attention, 1995695955, void, self, &window_id)
}
void godot_DisplayServer_window_move_to_foreground(godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_move_to_foreground, 1995695955, void, self, &window_id)
}
godot_bool godot_DisplayServer_window_is_focused(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_is_focused, 1051549951, godot_bool, self, &window_id)
}
godot_bool godot_DisplayServer_window_can_draw(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_can_draw, 1051549951, godot_bool, self, &window_id)
}
void godot_DisplayServer_window_set_transient(godot_DisplayServer *self, godot_int window_id, godot_int parent_window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_transient, 3937882851, void, self, &window_id, &parent_window_id)
}
void godot_DisplayServer_window_set_exclusive(godot_DisplayServer *self, godot_int window_id, godot_bool exclusive) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_exclusive, 300928843, void, self, &window_id, &exclusive)
}
void godot_DisplayServer_window_set_ime_active(godot_DisplayServer *self, godot_bool active, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_ime_active, 1661950165, void, self, &active, &window_id)
}
void godot_DisplayServer_window_set_ime_position(godot_DisplayServer *self, const godot_Vector2i *position, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_ime_position, 2019273902, void, self, position, &window_id)
}
void godot_DisplayServer_window_set_vsync_mode(godot_DisplayServer *self, godot_DisplayServer_VSyncMode vsync_mode, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_set_vsync_mode, 2179333492, void, self, &vsync_mode, &window_id)
}
godot_DisplayServer_VSyncMode godot_DisplayServer_window_get_vsync_mode(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_get_vsync_mode, 578873795, godot_DisplayServer_VSyncMode, self, &window_id)
}
godot_bool godot_DisplayServer_window_is_maximize_allowed(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_is_maximize_allowed, 1051549951, godot_bool, self, &window_id)
}
godot_bool godot_DisplayServer_window_maximize_on_title_dbl_click(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_maximize_on_title_dbl_click, 36873697, godot_bool, self)
}
godot_bool godot_DisplayServer_window_minimize_on_title_dbl_click(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, window_minimize_on_title_dbl_click, 36873697, godot_bool, self)
}
void godot_DisplayServer_window_start_drag(godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_start_drag, 1995695955, void, self, &window_id)
}
void godot_DisplayServer_window_start_resize(godot_DisplayServer *self, godot_DisplayServer_WindowResizeEdge edge, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, window_start_resize, 4009722312, void, self, &edge, &window_id)
}
godot_int godot_DisplayServer_accessibility_should_increase_contrast(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_should_increase_contrast, 3905245786, godot_int, self)
}
godot_int godot_DisplayServer_accessibility_should_reduce_animation(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_should_reduce_animation, 3905245786, godot_int, self)
}
godot_int godot_DisplayServer_accessibility_should_reduce_transparency(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_should_reduce_transparency, 3905245786, godot_int, self)
}
godot_int godot_DisplayServer_accessibility_screen_reader_active(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_screen_reader_active, 3905245786, godot_int, self)
}
godot_RID godot_DisplayServer_accessibility_create_element(godot_DisplayServer *self, godot_int window_id, godot_DisplayServer_AccessibilityRole role) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_create_element, 2968347744, godot_RID, self, &window_id, &role)
}
godot_RID godot_DisplayServer_accessibility_create_sub_element(godot_DisplayServer *self, const godot_RID *parent_rid, godot_DisplayServer_AccessibilityRole role, godot_int insert_pos) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_create_sub_element, 1949948826, godot_RID, self, parent_rid, &role, &insert_pos)
}
godot_RID godot_DisplayServer_accessibility_create_sub_text_edit_elements(godot_DisplayServer *self, const godot_RID *parent_rid, const godot_RID *shaped_text, godot_float min_height, godot_int insert_pos) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_create_sub_text_edit_elements, 3328635351, godot_RID, self, parent_rid, shaped_text, &min_height, &insert_pos)
}
godot_bool godot_DisplayServer_accessibility_has_element(const godot_DisplayServer *self, const godot_RID *id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_has_element, 4155700596, godot_bool, self, id)
}
void godot_DisplayServer_accessibility_free_element(godot_DisplayServer *self, const godot_RID *id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_free_element, 2722037293, void, self, id)
}
void godot_DisplayServer_accessibility_element_set_meta(godot_DisplayServer *self, const godot_RID *id, const godot_Variant *meta) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_element_set_meta, 3175752987, void, self, id, meta)
}
godot_Variant godot_DisplayServer_accessibility_element_get_meta(const godot_DisplayServer *self, const godot_RID *id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_element_get_meta, 4171304767, godot_Variant, self, id)
}
void godot_DisplayServer_accessibility_set_window_rect(godot_DisplayServer *self, godot_int window_id, const godot_Rect2 *rect_out, const godot_Rect2 *rect_in) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_set_window_rect, 2386961724, void, self, &window_id, rect_out, rect_in)
}
void godot_DisplayServer_accessibility_set_window_focused(godot_DisplayServer *self, godot_int window_id, godot_bool focused) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_set_window_focused, 300928843, void, self, &window_id, &focused)
}
void godot_DisplayServer_accessibility_update_set_focus(godot_DisplayServer *self, const godot_RID *id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_focus, 2722037293, void, self, id)
}
godot_RID godot_DisplayServer_accessibility_get_window_root(const godot_DisplayServer *self, godot_int window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, accessibility_get_window_root, 495598643, godot_RID, self, &window_id)
}
void godot_DisplayServer_accessibility_update_set_role(godot_DisplayServer *self, const godot_RID *id, godot_DisplayServer_AccessibilityRole role) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_role, 3352768215, void, self, id, &role)
}
void godot_DisplayServer_accessibility_update_set_name(godot_DisplayServer *self, const godot_RID *id, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_name, 2726140452, void, self, id, name)
}
void godot_DisplayServer_accessibility_update_set_extra_info(godot_DisplayServer *self, const godot_RID *id, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_extra_info, 2726140452, void, self, id, name)
}
void godot_DisplayServer_accessibility_update_set_description(godot_DisplayServer *self, const godot_RID *id, const godot_String *description) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_description, 2726140452, void, self, id, description)
}
void godot_DisplayServer_accessibility_update_set_value(godot_DisplayServer *self, const godot_RID *id, const godot_String *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_value, 2726140452, void, self, id, value)
}
void godot_DisplayServer_accessibility_update_set_tooltip(godot_DisplayServer *self, const godot_RID *id, const godot_String *tooltip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_tooltip, 2726140452, void, self, id, tooltip)
}
void godot_DisplayServer_accessibility_update_set_bounds(godot_DisplayServer *self, const godot_RID *id, const godot_Rect2 *p_rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_bounds, 1378122625, void, self, id, p_rect)
}
void godot_DisplayServer_accessibility_update_set_transform(godot_DisplayServer *self, const godot_RID *id, const godot_Transform2D *transform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_transform, 1246044741, void, self, id, transform)
}
void godot_DisplayServer_accessibility_update_add_child(godot_DisplayServer *self, const godot_RID *id, const godot_RID *child_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_child, 395945892, void, self, id, child_id)
}
void godot_DisplayServer_accessibility_update_add_related_controls(godot_DisplayServer *self, const godot_RID *id, const godot_RID *related_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_related_controls, 395945892, void, self, id, related_id)
}
void godot_DisplayServer_accessibility_update_add_related_details(godot_DisplayServer *self, const godot_RID *id, const godot_RID *related_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_related_details, 395945892, void, self, id, related_id)
}
void godot_DisplayServer_accessibility_update_add_related_described_by(godot_DisplayServer *self, const godot_RID *id, const godot_RID *related_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_related_described_by, 395945892, void, self, id, related_id)
}
void godot_DisplayServer_accessibility_update_add_related_flow_to(godot_DisplayServer *self, const godot_RID *id, const godot_RID *related_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_related_flow_to, 395945892, void, self, id, related_id)
}
void godot_DisplayServer_accessibility_update_add_related_labeled_by(godot_DisplayServer *self, const godot_RID *id, const godot_RID *related_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_related_labeled_by, 395945892, void, self, id, related_id)
}
void godot_DisplayServer_accessibility_update_add_related_radio_group(godot_DisplayServer *self, const godot_RID *id, const godot_RID *related_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_related_radio_group, 395945892, void, self, id, related_id)
}
void godot_DisplayServer_accessibility_update_set_active_descendant(godot_DisplayServer *self, const godot_RID *id, const godot_RID *other_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_active_descendant, 395945892, void, self, id, other_id)
}
void godot_DisplayServer_accessibility_update_set_next_on_line(godot_DisplayServer *self, const godot_RID *id, const godot_RID *other_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_next_on_line, 395945892, void, self, id, other_id)
}
void godot_DisplayServer_accessibility_update_set_previous_on_line(godot_DisplayServer *self, const godot_RID *id, const godot_RID *other_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_previous_on_line, 395945892, void, self, id, other_id)
}
void godot_DisplayServer_accessibility_update_set_member_of(godot_DisplayServer *self, const godot_RID *id, const godot_RID *group_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_member_of, 395945892, void, self, id, group_id)
}
void godot_DisplayServer_accessibility_update_set_in_page_link_target(godot_DisplayServer *self, const godot_RID *id, const godot_RID *other_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_in_page_link_target, 395945892, void, self, id, other_id)
}
void godot_DisplayServer_accessibility_update_set_error_message(godot_DisplayServer *self, const godot_RID *id, const godot_RID *other_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_error_message, 395945892, void, self, id, other_id)
}
void godot_DisplayServer_accessibility_update_set_live(godot_DisplayServer *self, const godot_RID *id, godot_DisplayServer_AccessibilityLiveMode live) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_live, 2683302212, void, self, id, &live)
}
void godot_DisplayServer_accessibility_update_add_action(godot_DisplayServer *self, const godot_RID *id, godot_DisplayServer_AccessibilityAction action, const godot_Callable *callable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_action, 2898696987, void, self, id, &action, callable)
}
void godot_DisplayServer_accessibility_update_add_custom_action(godot_DisplayServer *self, const godot_RID *id, godot_int action_id, const godot_String *action_description) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_add_custom_action, 4153150897, void, self, id, &action_id, action_description)
}
void godot_DisplayServer_accessibility_update_set_table_row_count(godot_DisplayServer *self, const godot_RID *id, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_table_row_count, 3411492887, void, self, id, &count)
}
void godot_DisplayServer_accessibility_update_set_table_column_count(godot_DisplayServer *self, const godot_RID *id, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_table_column_count, 3411492887, void, self, id, &count)
}
void godot_DisplayServer_accessibility_update_set_table_row_index(godot_DisplayServer *self, const godot_RID *id, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_table_row_index, 3411492887, void, self, id, &index)
}
void godot_DisplayServer_accessibility_update_set_table_column_index(godot_DisplayServer *self, const godot_RID *id, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_table_column_index, 3411492887, void, self, id, &index)
}
void godot_DisplayServer_accessibility_update_set_table_cell_position(godot_DisplayServer *self, const godot_RID *id, godot_int row_index, godot_int column_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_table_cell_position, 4288446313, void, self, id, &row_index, &column_index)
}
void godot_DisplayServer_accessibility_update_set_table_cell_span(godot_DisplayServer *self, const godot_RID *id, godot_int row_span, godot_int column_span) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_table_cell_span, 4288446313, void, self, id, &row_span, &column_span)
}
void godot_DisplayServer_accessibility_update_set_list_item_count(godot_DisplayServer *self, const godot_RID *id, godot_int size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_list_item_count, 3411492887, void, self, id, &size)
}
void godot_DisplayServer_accessibility_update_set_list_item_index(godot_DisplayServer *self, const godot_RID *id, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_list_item_index, 3411492887, void, self, id, &index)
}
void godot_DisplayServer_accessibility_update_set_list_item_level(godot_DisplayServer *self, const godot_RID *id, godot_int level) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_list_item_level, 3411492887, void, self, id, &level)
}
void godot_DisplayServer_accessibility_update_set_list_item_selected(godot_DisplayServer *self, const godot_RID *id, godot_bool selected) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_list_item_selected, 1265174801, void, self, id, &selected)
}
void godot_DisplayServer_accessibility_update_set_list_item_expanded(godot_DisplayServer *self, const godot_RID *id, godot_bool expanded) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_list_item_expanded, 1265174801, void, self, id, &expanded)
}
void godot_DisplayServer_accessibility_update_set_popup_type(godot_DisplayServer *self, const godot_RID *id, godot_DisplayServer_AccessibilityPopupType popup) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_popup_type, 2040885448, void, self, id, &popup)
}
void godot_DisplayServer_accessibility_update_set_checked(godot_DisplayServer *self, const godot_RID *id, godot_bool checekd) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_checked, 1265174801, void, self, id, &checekd)
}
void godot_DisplayServer_accessibility_update_set_num_value(godot_DisplayServer *self, const godot_RID *id, godot_float position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_num_value, 1794382983, void, self, id, &position)
}
void godot_DisplayServer_accessibility_update_set_num_range(godot_DisplayServer *self, const godot_RID *id, godot_float min, godot_float max) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_num_range, 2513314492, void, self, id, &min, &max)
}
void godot_DisplayServer_accessibility_update_set_num_step(godot_DisplayServer *self, const godot_RID *id, godot_float step) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_num_step, 1794382983, void, self, id, &step)
}
void godot_DisplayServer_accessibility_update_set_num_jump(godot_DisplayServer *self, const godot_RID *id, godot_float jump) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_num_jump, 1794382983, void, self, id, &jump)
}
void godot_DisplayServer_accessibility_update_set_scroll_x(godot_DisplayServer *self, const godot_RID *id, godot_float position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_scroll_x, 1794382983, void, self, id, &position)
}
void godot_DisplayServer_accessibility_update_set_scroll_x_range(godot_DisplayServer *self, const godot_RID *id, godot_float min, godot_float max) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_scroll_x_range, 2513314492, void, self, id, &min, &max)
}
void godot_DisplayServer_accessibility_update_set_scroll_y(godot_DisplayServer *self, const godot_RID *id, godot_float position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_scroll_y, 1794382983, void, self, id, &position)
}
void godot_DisplayServer_accessibility_update_set_scroll_y_range(godot_DisplayServer *self, const godot_RID *id, godot_float min, godot_float max) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_scroll_y_range, 2513314492, void, self, id, &min, &max)
}
void godot_DisplayServer_accessibility_update_set_text_decorations(godot_DisplayServer *self, const godot_RID *id, godot_bool underline, godot_bool strikethrough, godot_bool overline) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_text_decorations, 1672422386, void, self, id, &underline, &strikethrough, &overline)
}
void godot_DisplayServer_accessibility_update_set_text_align(godot_DisplayServer *self, const godot_RID *id, godot_HorizontalAlignment align) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_text_align, 3725995085, void, self, id, &align)
}
void godot_DisplayServer_accessibility_update_set_text_selection(godot_DisplayServer *self, const godot_RID *id, const godot_RID *text_start_id, godot_int start_char, const godot_RID *text_end_id, godot_int end_char) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_text_selection, 3119144029, void, self, id, text_start_id, &start_char, text_end_id, &end_char)
}
void godot_DisplayServer_accessibility_update_set_flag(godot_DisplayServer *self, const godot_RID *id, godot_DisplayServer_AccessibilityFlags flag, godot_bool value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_flag, 3758675396, void, self, id, &flag, &value)
}
void godot_DisplayServer_accessibility_update_set_classname(godot_DisplayServer *self, const godot_RID *id, const godot_String *classname) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_classname, 2726140452, void, self, id, classname)
}
void godot_DisplayServer_accessibility_update_set_placeholder(godot_DisplayServer *self, const godot_RID *id, const godot_String *placeholder) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_placeholder, 2726140452, void, self, id, placeholder)
}
void godot_DisplayServer_accessibility_update_set_language(godot_DisplayServer *self, const godot_RID *id, const godot_String *language) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_language, 2726140452, void, self, id, language)
}
void godot_DisplayServer_accessibility_update_set_text_orientation(godot_DisplayServer *self, const godot_RID *id, godot_bool vertical) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_text_orientation, 1265174801, void, self, id, &vertical)
}
void godot_DisplayServer_accessibility_update_set_list_orientation(godot_DisplayServer *self, const godot_RID *id, godot_bool vertical) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_list_orientation, 1265174801, void, self, id, &vertical)
}
void godot_DisplayServer_accessibility_update_set_shortcut(godot_DisplayServer *self, const godot_RID *id, const godot_String *shortcut) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_shortcut, 2726140452, void, self, id, shortcut)
}
void godot_DisplayServer_accessibility_update_set_url(godot_DisplayServer *self, const godot_RID *id, const godot_String *url) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_url, 2726140452, void, self, id, url)
}
void godot_DisplayServer_accessibility_update_set_role_description(godot_DisplayServer *self, const godot_RID *id, const godot_String *description) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_role_description, 2726140452, void, self, id, description)
}
void godot_DisplayServer_accessibility_update_set_state_description(godot_DisplayServer *self, const godot_RID *id, const godot_String *description) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_state_description, 2726140452, void, self, id, description)
}
void godot_DisplayServer_accessibility_update_set_color_value(godot_DisplayServer *self, const godot_RID *id, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_color_value, 2948539648, void, self, id, color)
}
void godot_DisplayServer_accessibility_update_set_background_color(godot_DisplayServer *self, const godot_RID *id, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_background_color, 2948539648, void, self, id, color)
}
void godot_DisplayServer_accessibility_update_set_foreground_color(godot_DisplayServer *self, const godot_RID *id, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, accessibility_update_set_foreground_color, 2948539648, void, self, id, color)
}
godot_Vector2i godot_DisplayServer_ime_get_selection(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, ime_get_selection, 3690982128, godot_Vector2i, self)
}
godot_String godot_DisplayServer_ime_get_text(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, ime_get_text, 201670096, godot_String, self)
}
void godot_DisplayServer_virtual_keyboard_show(godot_DisplayServer *self, const godot_String *existing_text, const godot_Rect2 *position, godot_DisplayServer_VirtualKeyboardType type, godot_int max_length, godot_int cursor_start, godot_int cursor_end) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, virtual_keyboard_show, 3042891259, void, self, existing_text, position, &type, &max_length, &cursor_start, &cursor_end)
}
void godot_DisplayServer_virtual_keyboard_hide(godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, virtual_keyboard_hide, 3218959716, void, self)
}
godot_int godot_DisplayServer_virtual_keyboard_get_height(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, virtual_keyboard_get_height, 3905245786, godot_int, self)
}
godot_bool godot_DisplayServer_has_hardware_keyboard(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, has_hardware_keyboard, 36873697, godot_bool, self)
}
void godot_DisplayServer_set_hardware_keyboard_connection_change_callback(godot_DisplayServer *self, const godot_Callable *callable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, set_hardware_keyboard_connection_change_callback, 1611583062, void, self, callable)
}
void godot_DisplayServer_cursor_set_shape(godot_DisplayServer *self, godot_DisplayServer_CursorShape shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, cursor_set_shape, 2026291549, void, self, &shape)
}
godot_DisplayServer_CursorShape godot_DisplayServer_cursor_get_shape(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, cursor_get_shape, 1087724927, godot_DisplayServer_CursorShape, self)
}
void godot_DisplayServer_cursor_set_custom_image(godot_DisplayServer *self, const godot_Resource *cursor, godot_DisplayServer_CursorShape shape, const godot_Vector2 *hotspot) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, cursor_set_custom_image, 1816663697, void, self, cursor, &shape, hotspot)
}
godot_bool godot_DisplayServer_get_swap_cancel_ok(godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, get_swap_cancel_ok, 2240911060, godot_bool, self)
}
void godot_DisplayServer_enable_for_stealing_focus(godot_DisplayServer *self, godot_int process_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, enable_for_stealing_focus, 1286410249, void, self, &process_id)
}
godot_Error godot_DisplayServer_dialog_show(godot_DisplayServer *self, const godot_String *title, const godot_String *description, const godot_PackedStringArray *buttons, const godot_Callable *callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, dialog_show, 4115553226, godot_Error, self, title, description, buttons, callback)
}
godot_Error godot_DisplayServer_dialog_input_text(godot_DisplayServer *self, const godot_String *title, const godot_String *description, const godot_String *existing_text, const godot_Callable *callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, dialog_input_text, 3088703427, godot_Error, self, title, description, existing_text, callback)
}
godot_Error godot_DisplayServer_file_dialog_show(godot_DisplayServer *self, const godot_String *title, const godot_String *current_directory, const godot_String *filename, godot_bool show_hidden, godot_DisplayServer_FileDialogMode mode, const godot_PackedStringArray *filters, const godot_Callable *callback, godot_int parent_window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, file_dialog_show, 1386825884, godot_Error, self, title, current_directory, filename, &show_hidden, &mode, filters, callback, &parent_window_id)
}
godot_Error godot_DisplayServer_file_dialog_with_options_show(godot_DisplayServer *self, const godot_String *title, const godot_String *current_directory, const godot_String *root, const godot_String *filename, godot_bool show_hidden, godot_DisplayServer_FileDialogMode mode, const godot_PackedStringArray *filters, const godot_TypedArray(godot_Dictionary) *options, const godot_Callable *callback, godot_int parent_window_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, file_dialog_with_options_show, 1448789813, godot_Error, self, title, current_directory, root, filename, &show_hidden, &mode, filters, options, callback, &parent_window_id)
}
void godot_DisplayServer_beep(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, beep, 4051624405, void, self)
}
godot_int godot_DisplayServer_keyboard_get_layout_count(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, keyboard_get_layout_count, 3905245786, godot_int, self)
}
godot_int godot_DisplayServer_keyboard_get_current_layout(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, keyboard_get_current_layout, 3905245786, godot_int, self)
}
void godot_DisplayServer_keyboard_set_current_layout(godot_DisplayServer *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, keyboard_set_current_layout, 1286410249, void, self, &index)
}
godot_String godot_DisplayServer_keyboard_get_layout_language(const godot_DisplayServer *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, keyboard_get_layout_language, 844755477, godot_String, self, &index)
}
godot_String godot_DisplayServer_keyboard_get_layout_name(const godot_DisplayServer *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, keyboard_get_layout_name, 844755477, godot_String, self, &index)
}
godot_Key godot_DisplayServer_keyboard_get_keycode_from_physical(const godot_DisplayServer *self, godot_Key keycode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, keyboard_get_keycode_from_physical, 3447613187, godot_Key, self, &keycode)
}
godot_Key godot_DisplayServer_keyboard_get_label_from_physical(const godot_DisplayServer *self, godot_Key keycode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, keyboard_get_label_from_physical, 3447613187, godot_Key, self, &keycode)
}
void godot_DisplayServer_show_emoji_and_symbol_picker(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, show_emoji_and_symbol_picker, 4051624405, void, self)
}
godot_bool godot_DisplayServer_color_picker(godot_DisplayServer *self, const godot_Callable *callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, color_picker, 151643214, godot_bool, self, callback)
}
void godot_DisplayServer_process_events(godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, process_events, 3218959716, void, self)
}
void godot_DisplayServer_force_process_and_drop_events(godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, force_process_and_drop_events, 3218959716, void, self)
}
void godot_DisplayServer_set_native_icon(godot_DisplayServer *self, const godot_String *filename) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, set_native_icon, 83702148, void, self, filename)
}
void godot_DisplayServer_set_icon(godot_DisplayServer *self, const godot_Image *image) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, set_icon, 532598488, void, self, image)
}
godot_int godot_DisplayServer_create_status_indicator(godot_DisplayServer *self, const godot_Texture2D *icon, const godot_String *tooltip, const godot_Callable *callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, create_status_indicator, 1904285171, godot_int, self, icon, tooltip, callback)
}
void godot_DisplayServer_status_indicator_set_icon(godot_DisplayServer *self, godot_int id, const godot_Texture2D *icon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, status_indicator_set_icon, 666127730, void, self, &id, icon)
}
void godot_DisplayServer_status_indicator_set_tooltip(godot_DisplayServer *self, godot_int id, const godot_String *tooltip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, status_indicator_set_tooltip, 501894301, void, self, &id, tooltip)
}
void godot_DisplayServer_status_indicator_set_menu(godot_DisplayServer *self, godot_int id, const godot_RID *menu_rid) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, status_indicator_set_menu, 4040184819, void, self, &id, menu_rid)
}
void godot_DisplayServer_status_indicator_set_callback(godot_DisplayServer *self, godot_int id, const godot_Callable *callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, status_indicator_set_callback, 957362965, void, self, &id, callback)
}
godot_Rect2 godot_DisplayServer_status_indicator_get_rect(const godot_DisplayServer *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, status_indicator_get_rect, 3327874267, godot_Rect2, self, &id)
}
void godot_DisplayServer_delete_status_indicator(godot_DisplayServer *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, delete_status_indicator, 1286410249, void, self, &id)
}
godot_int godot_DisplayServer_tablet_get_driver_count(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, tablet_get_driver_count, 3905245786, godot_int, self)
}
godot_String godot_DisplayServer_tablet_get_driver_name(const godot_DisplayServer *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, tablet_get_driver_name, 844755477, godot_String, self, &idx)
}
godot_String godot_DisplayServer_tablet_get_current_driver(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, tablet_get_current_driver, 201670096, godot_String, self)
}
void godot_DisplayServer_tablet_set_current_driver(godot_DisplayServer *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, tablet_set_current_driver, 83702148, void, self, name)
}
godot_bool godot_DisplayServer_is_window_transparency_available(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, is_window_transparency_available, 36873697, godot_bool, self)
}
void godot_DisplayServer_register_additional_output(godot_DisplayServer *self, const godot_Object *object) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, register_additional_output, 3975164845, void, self, object)
}
void godot_DisplayServer_unregister_additional_output(godot_DisplayServer *self, const godot_Object *object) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DisplayServer, unregister_additional_output, 3975164845, void, self, object)
}
godot_bool godot_DisplayServer_has_additional_outputs(const godot_DisplayServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DisplayServer, has_additional_outputs, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
