// This file was automatically generated
// Do not modify this file
#include "camera2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Camera2D *godot_new_Camera2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Camera2D);
}

// Methods
void godot_Camera2D_set_offset(godot_Camera2D *self, const godot_Vector2 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_offset, 743155724, void, self, offset)
}
godot_Vector2 godot_Camera2D_get_offset(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_offset, 3341600327, godot_Vector2, self)
}
void godot_Camera2D_set_anchor_mode(godot_Camera2D *self, godot_Camera2D_AnchorMode anchor_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_anchor_mode, 2050398218, void, self, &anchor_mode)
}
godot_Camera2D_AnchorMode godot_Camera2D_get_anchor_mode(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_anchor_mode, 155978067, godot_Camera2D_AnchorMode, self)
}
void godot_Camera2D_set_ignore_rotation(godot_Camera2D *self, godot_bool ignore) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_ignore_rotation, 2586408642, void, self, &ignore)
}
godot_bool godot_Camera2D_is_ignoring_rotation(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_ignoring_rotation, 36873697, godot_bool, self)
}
void godot_Camera2D_set_process_callback(godot_Camera2D *self, godot_Camera2D_Camera2DProcessCallback mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_process_callback, 4201947462, void, self, &mode)
}
godot_Camera2D_Camera2DProcessCallback godot_Camera2D_get_process_callback(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_process_callback, 2325344499, godot_Camera2D_Camera2DProcessCallback, self)
}
void godot_Camera2D_set_enabled(godot_Camera2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_Camera2D_is_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_make_current(godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, make_current, 3218959716, void, self)
}
godot_bool godot_Camera2D_is_current(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_current, 36873697, godot_bool, self)
}
void godot_Camera2D_set_limit_enabled(godot_Camera2D *self, godot_bool limit_enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_limit_enabled, 2586408642, void, self, &limit_enabled)
}
godot_bool godot_Camera2D_is_limit_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_limit_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_set_limit(godot_Camera2D *self, godot_Side margin, godot_int limit) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_limit, 437707142, void, self, &margin, &limit)
}
godot_int godot_Camera2D_get_limit(const godot_Camera2D *self, godot_Side margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_limit, 1983885014, godot_int, self, &margin)
}
void godot_Camera2D_set_limit_smoothing_enabled(godot_Camera2D *self, godot_bool limit_smoothing_enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_limit_smoothing_enabled, 2586408642, void, self, &limit_smoothing_enabled)
}
godot_bool godot_Camera2D_is_limit_smoothing_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_limit_smoothing_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_set_drag_vertical_enabled(godot_Camera2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_drag_vertical_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_Camera2D_is_drag_vertical_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_drag_vertical_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_set_drag_horizontal_enabled(godot_Camera2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_drag_horizontal_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_Camera2D_is_drag_horizontal_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_drag_horizontal_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_set_drag_vertical_offset(godot_Camera2D *self, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_drag_vertical_offset, 373806689, void, self, &offset)
}
godot_float godot_Camera2D_get_drag_vertical_offset(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_drag_vertical_offset, 1740695150, godot_float, self)
}
void godot_Camera2D_set_drag_horizontal_offset(godot_Camera2D *self, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_drag_horizontal_offset, 373806689, void, self, &offset)
}
godot_float godot_Camera2D_get_drag_horizontal_offset(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_drag_horizontal_offset, 1740695150, godot_float, self)
}
void godot_Camera2D_set_drag_margin(godot_Camera2D *self, godot_Side margin, godot_float drag_margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_drag_margin, 4290182280, void, self, &margin, &drag_margin)
}
godot_float godot_Camera2D_get_drag_margin(const godot_Camera2D *self, godot_Side margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_drag_margin, 2869120046, godot_float, self, &margin)
}
godot_Vector2 godot_Camera2D_get_target_position(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_target_position, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_Camera2D_get_screen_center_position(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_screen_center_position, 3341600327, godot_Vector2, self)
}
godot_float godot_Camera2D_get_screen_rotation(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_screen_rotation, 1740695150, godot_float, self)
}
void godot_Camera2D_set_zoom(godot_Camera2D *self, const godot_Vector2 *zoom) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_zoom, 743155724, void, self, zoom)
}
godot_Vector2 godot_Camera2D_get_zoom(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_zoom, 3341600327, godot_Vector2, self)
}
void godot_Camera2D_set_custom_viewport(godot_Camera2D *self, const godot_Node *viewport) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_custom_viewport, 1078189570, void, self, viewport)
}
godot_Node * godot_Camera2D_get_custom_viewport(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_custom_viewport, 3160264692, godot_Node *, self)
}
void godot_Camera2D_set_position_smoothing_speed(godot_Camera2D *self, godot_float position_smoothing_speed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_position_smoothing_speed, 373806689, void, self, &position_smoothing_speed)
}
godot_float godot_Camera2D_get_position_smoothing_speed(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_position_smoothing_speed, 1740695150, godot_float, self)
}
void godot_Camera2D_set_position_smoothing_enabled(godot_Camera2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_position_smoothing_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_Camera2D_is_position_smoothing_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_position_smoothing_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_set_rotation_smoothing_enabled(godot_Camera2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_rotation_smoothing_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_Camera2D_is_rotation_smoothing_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_rotation_smoothing_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_set_rotation_smoothing_speed(godot_Camera2D *self, godot_float speed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_rotation_smoothing_speed, 373806689, void, self, &speed)
}
godot_float godot_Camera2D_get_rotation_smoothing_speed(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, get_rotation_smoothing_speed, 1740695150, godot_float, self)
}
void godot_Camera2D_force_update_scroll(godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, force_update_scroll, 3218959716, void, self)
}
void godot_Camera2D_reset_smoothing(godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, reset_smoothing, 3218959716, void, self)
}
void godot_Camera2D_align(godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, align, 3218959716, void, self)
}
void godot_Camera2D_set_screen_drawing_enabled(godot_Camera2D *self, godot_bool screen_drawing_enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_screen_drawing_enabled, 2586408642, void, self, &screen_drawing_enabled)
}
godot_bool godot_Camera2D_is_screen_drawing_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_screen_drawing_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_set_limit_drawing_enabled(godot_Camera2D *self, godot_bool limit_drawing_enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_limit_drawing_enabled, 2586408642, void, self, &limit_drawing_enabled)
}
godot_bool godot_Camera2D_is_limit_drawing_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_limit_drawing_enabled, 36873697, godot_bool, self)
}
void godot_Camera2D_set_margin_drawing_enabled(godot_Camera2D *self, godot_bool margin_drawing_enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera2D, set_margin_drawing_enabled, 2586408642, void, self, &margin_drawing_enabled)
}
godot_bool godot_Camera2D_is_margin_drawing_enabled(const godot_Camera2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera2D, is_margin_drawing_enabled, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
