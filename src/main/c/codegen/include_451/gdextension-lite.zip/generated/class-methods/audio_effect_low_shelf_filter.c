// This file was automatically generated
// Do not modify this file
#include "audio_effect_low_shelf_filter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectLowShelfFilter *godot_new_AudioEffectLowShelfFilter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectLowShelfFilter);
}


#ifdef __cplusplus
}
#endif
