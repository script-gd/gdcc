// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASTAR_GRID2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASTAR_GRID2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AStarGrid2D *godot_new_AStarGrid2D();

// Methods
GDEXTENSION_LITE_DECL godot_float godot_AStarGrid2D__estimate_cost(const godot_AStarGrid2D *self, const godot_Vector2i *from_id, const godot_Vector2i *end_id);
GDEXTENSION_LITE_DECL godot_float godot_AStarGrid2D__compute_cost(const godot_AStarGrid2D *self, const godot_Vector2i *from_id, const godot_Vector2i *to_id);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_region(godot_AStarGrid2D *self, const godot_Rect2i *region);
GDEXTENSION_LITE_DECL godot_Rect2i godot_AStarGrid2D_get_region(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_size(godot_AStarGrid2D *self, const godot_Vector2i *size);
GDEXTENSION_LITE_DECL godot_Vector2i godot_AStarGrid2D_get_size(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_offset(godot_AStarGrid2D *self, const godot_Vector2 *offset);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AStarGrid2D_get_offset(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_cell_size(godot_AStarGrid2D *self, const godot_Vector2 *cell_size);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AStarGrid2D_get_cell_size(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_cell_shape(godot_AStarGrid2D *self, godot_AStarGrid2D_CellShape cell_shape);
GDEXTENSION_LITE_DECL godot_AStarGrid2D_CellShape godot_AStarGrid2D_get_cell_shape(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL godot_bool godot_AStarGrid2D_is_in_bounds(const godot_AStarGrid2D *self, godot_int x, godot_int y);
GDEXTENSION_LITE_DECL godot_bool godot_AStarGrid2D_is_in_boundsv(const godot_AStarGrid2D *self, const godot_Vector2i *id);
GDEXTENSION_LITE_DECL godot_bool godot_AStarGrid2D_is_dirty(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_update(godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_jumping_enabled(godot_AStarGrid2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_AStarGrid2D_is_jumping_enabled(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_diagonal_mode(godot_AStarGrid2D *self, godot_AStarGrid2D_DiagonalMode mode);
GDEXTENSION_LITE_DECL godot_AStarGrid2D_DiagonalMode godot_AStarGrid2D_get_diagonal_mode(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_default_compute_heuristic(godot_AStarGrid2D *self, godot_AStarGrid2D_Heuristic heuristic);
GDEXTENSION_LITE_DECL godot_AStarGrid2D_Heuristic godot_AStarGrid2D_get_default_compute_heuristic(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_default_estimate_heuristic(godot_AStarGrid2D *self, godot_AStarGrid2D_Heuristic heuristic);
GDEXTENSION_LITE_DECL godot_AStarGrid2D_Heuristic godot_AStarGrid2D_get_default_estimate_heuristic(const godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_point_solid(godot_AStarGrid2D *self, const godot_Vector2i *id, godot_bool solid);
GDEXTENSION_LITE_DECL godot_bool godot_AStarGrid2D_is_point_solid(const godot_AStarGrid2D *self, const godot_Vector2i *id);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_set_point_weight_scale(godot_AStarGrid2D *self, const godot_Vector2i *id, godot_float weight_scale);
GDEXTENSION_LITE_DECL godot_float godot_AStarGrid2D_get_point_weight_scale(const godot_AStarGrid2D *self, const godot_Vector2i *id);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_fill_solid_region(godot_AStarGrid2D *self, const godot_Rect2i *region, godot_bool solid);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_fill_weight_scale_region(godot_AStarGrid2D *self, const godot_Rect2i *region, godot_float weight_scale);
GDEXTENSION_LITE_DECL void godot_AStarGrid2D_clear(godot_AStarGrid2D *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AStarGrid2D_get_point_position(const godot_AStarGrid2D *self, const godot_Vector2i *id);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_AStarGrid2D_get_point_data_in_region(const godot_AStarGrid2D *self, const godot_Rect2i *region);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_AStarGrid2D_get_point_path(godot_AStarGrid2D *self, const godot_Vector2i *from_id, const godot_Vector2i *to_id, godot_bool allow_partial_path);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Vector2i) godot_AStarGrid2D_get_id_path(godot_AStarGrid2D *self, const godot_Vector2i *from_id, const godot_Vector2i *to_id, godot_bool allow_partial_path);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASTAR_GRID2D_H__
