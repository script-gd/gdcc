// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_SYNCHRONIZED_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_SYNCHRONIZED_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamSynchronized *godot_new_AudioStreamSynchronized();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioStreamSynchronized_set_stream_count(godot_AudioStreamSynchronized *self, godot_int stream_count);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamSynchronized_get_stream_count(const godot_AudioStreamSynchronized *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamSynchronized_set_sync_stream(godot_AudioStreamSynchronized *self, godot_int stream_index, const godot_AudioStream *audio_stream);
GDEXTENSION_LITE_DECL godot_AudioStream * godot_AudioStreamSynchronized_get_sync_stream(const godot_AudioStreamSynchronized *self, godot_int stream_index);
GDEXTENSION_LITE_DECL void godot_AudioStreamSynchronized_set_sync_stream_volume(godot_AudioStreamSynchronized *self, godot_int stream_index, godot_float volume_db);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamSynchronized_get_sync_stream_volume(const godot_AudioStreamSynchronized *self, godot_int stream_index);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_SYNCHRONIZED_H__
