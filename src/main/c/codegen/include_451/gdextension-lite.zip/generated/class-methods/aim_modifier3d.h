// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AIM_MODIFIER3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AIM_MODIFIER3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AimModifier3D *godot_new_AimModifier3D();

// Methods
GDEXTENSION_LITE_DECL void godot_AimModifier3D_set_forward_axis(godot_AimModifier3D *self, godot_int index, godot_SkeletonModifier3D_BoneAxis axis);
GDEXTENSION_LITE_DECL godot_SkeletonModifier3D_BoneAxis godot_AimModifier3D_get_forward_axis(const godot_AimModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_AimModifier3D_set_use_euler(godot_AimModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_AimModifier3D_is_using_euler(const godot_AimModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_AimModifier3D_set_primary_rotation_axis(godot_AimModifier3D *self, godot_int index, godot_Vector3_Axis axis);
GDEXTENSION_LITE_DECL godot_Vector3_Axis godot_AimModifier3D_get_primary_rotation_axis(const godot_AimModifier3D *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_AimModifier3D_set_use_secondary_rotation(godot_AimModifier3D *self, godot_int index, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_AimModifier3D_is_using_secondary_rotation(const godot_AimModifier3D *self, godot_int index);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AIM_MODIFIER3D_H__
