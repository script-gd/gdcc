// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ARRAY_MESH_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ARRAY_MESH_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ArrayMesh *godot_new_ArrayMesh();

// Methods
GDEXTENSION_LITE_DECL void godot_ArrayMesh_add_blend_shape(godot_ArrayMesh *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_int godot_ArrayMesh_get_blend_shape_count(const godot_ArrayMesh *self);
GDEXTENSION_LITE_DECL godot_StringName godot_ArrayMesh_get_blend_shape_name(const godot_ArrayMesh *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_set_blend_shape_name(godot_ArrayMesh *self, godot_int index, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_clear_blend_shapes(godot_ArrayMesh *self);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_set_blend_shape_mode(godot_ArrayMesh *self, godot_Mesh_BlendShapeMode mode);
GDEXTENSION_LITE_DECL godot_Mesh_BlendShapeMode godot_ArrayMesh_get_blend_shape_mode(const godot_ArrayMesh *self);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_add_surface_from_arrays(godot_ArrayMesh *self, godot_Mesh_PrimitiveType primitive, const godot_Array *arrays, const godot_TypedArray(godot_Array) *blend_shapes, const godot_Dictionary *lods, const godot_Mesh_ArrayFormat *flags);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_clear_surfaces(godot_ArrayMesh *self);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_surface_remove(godot_ArrayMesh *self, godot_int surf_idx);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_surface_update_vertex_region(godot_ArrayMesh *self, godot_int surf_idx, godot_int offset, const godot_PackedByteArray *data);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_surface_update_attribute_region(godot_ArrayMesh *self, godot_int surf_idx, godot_int offset, const godot_PackedByteArray *data);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_surface_update_skin_region(godot_ArrayMesh *self, godot_int surf_idx, godot_int offset, const godot_PackedByteArray *data);
GDEXTENSION_LITE_DECL godot_int godot_ArrayMesh_surface_get_array_len(const godot_ArrayMesh *self, godot_int surf_idx);
GDEXTENSION_LITE_DECL godot_int godot_ArrayMesh_surface_get_array_index_len(const godot_ArrayMesh *self, godot_int surf_idx);
GDEXTENSION_LITE_DECL godot_Mesh_ArrayFormat godot_ArrayMesh_surface_get_format(const godot_ArrayMesh *self, godot_int surf_idx);
GDEXTENSION_LITE_DECL godot_Mesh_PrimitiveType godot_ArrayMesh_surface_get_primitive_type(const godot_ArrayMesh *self, godot_int surf_idx);
GDEXTENSION_LITE_DECL godot_int godot_ArrayMesh_surface_find_by_name(const godot_ArrayMesh *self, const godot_String *name);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_surface_set_name(godot_ArrayMesh *self, godot_int surf_idx, const godot_String *name);
GDEXTENSION_LITE_DECL godot_String godot_ArrayMesh_surface_get_name(const godot_ArrayMesh *self, godot_int surf_idx);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_regen_normal_maps(godot_ArrayMesh *self);
GDEXTENSION_LITE_DECL godot_Error godot_ArrayMesh_lightmap_unwrap(godot_ArrayMesh *self, const godot_Transform3D *transform, godot_float texel_size);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_set_custom_aabb(godot_ArrayMesh *self, const godot_AABB *aabb);
GDEXTENSION_LITE_DECL godot_AABB godot_ArrayMesh_get_custom_aabb(const godot_ArrayMesh *self);
GDEXTENSION_LITE_DECL void godot_ArrayMesh_set_shadow_mesh(godot_ArrayMesh *self, const godot_ArrayMesh *mesh);
GDEXTENSION_LITE_DECL godot_ArrayMesh * godot_ArrayMesh_get_shadow_mesh(const godot_ArrayMesh *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ARRAY_MESH_H__
