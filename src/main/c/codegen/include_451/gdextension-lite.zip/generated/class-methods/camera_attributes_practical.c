// This file was automatically generated
// Do not modify this file
#include "camera_attributes_practical.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CameraAttributesPractical *godot_new_CameraAttributesPractical() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CameraAttributesPractical);
}

// Methods
void godot_CameraAttributesPractical_set_dof_blur_far_enabled(godot_CameraAttributesPractical *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_dof_blur_far_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CameraAttributesPractical_is_dof_blur_far_enabled(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, is_dof_blur_far_enabled, 36873697, godot_bool, self)
}
void godot_CameraAttributesPractical_set_dof_blur_far_distance(godot_CameraAttributesPractical *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_dof_blur_far_distance, 373806689, void, self, &distance)
}
godot_float godot_CameraAttributesPractical_get_dof_blur_far_distance(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, get_dof_blur_far_distance, 1740695150, godot_float, self)
}
void godot_CameraAttributesPractical_set_dof_blur_far_transition(godot_CameraAttributesPractical *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_dof_blur_far_transition, 373806689, void, self, &distance)
}
godot_float godot_CameraAttributesPractical_get_dof_blur_far_transition(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, get_dof_blur_far_transition, 1740695150, godot_float, self)
}
void godot_CameraAttributesPractical_set_dof_blur_near_enabled(godot_CameraAttributesPractical *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_dof_blur_near_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CameraAttributesPractical_is_dof_blur_near_enabled(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, is_dof_blur_near_enabled, 36873697, godot_bool, self)
}
void godot_CameraAttributesPractical_set_dof_blur_near_distance(godot_CameraAttributesPractical *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_dof_blur_near_distance, 373806689, void, self, &distance)
}
godot_float godot_CameraAttributesPractical_get_dof_blur_near_distance(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, get_dof_blur_near_distance, 1740695150, godot_float, self)
}
void godot_CameraAttributesPractical_set_dof_blur_near_transition(godot_CameraAttributesPractical *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_dof_blur_near_transition, 373806689, void, self, &distance)
}
godot_float godot_CameraAttributesPractical_get_dof_blur_near_transition(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, get_dof_blur_near_transition, 1740695150, godot_float, self)
}
void godot_CameraAttributesPractical_set_dof_blur_amount(godot_CameraAttributesPractical *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_dof_blur_amount, 373806689, void, self, &amount)
}
godot_float godot_CameraAttributesPractical_get_dof_blur_amount(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, get_dof_blur_amount, 1740695150, godot_float, self)
}
void godot_CameraAttributesPractical_set_auto_exposure_max_sensitivity(godot_CameraAttributesPractical *self, godot_float max_sensitivity) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_auto_exposure_max_sensitivity, 373806689, void, self, &max_sensitivity)
}
godot_float godot_CameraAttributesPractical_get_auto_exposure_max_sensitivity(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, get_auto_exposure_max_sensitivity, 1740695150, godot_float, self)
}
void godot_CameraAttributesPractical_set_auto_exposure_min_sensitivity(godot_CameraAttributesPractical *self, godot_float min_sensitivity) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributesPractical, set_auto_exposure_min_sensitivity, 373806689, void, self, &min_sensitivity)
}
godot_float godot_CameraAttributesPractical_get_auto_exposure_min_sensitivity(const godot_CameraAttributesPractical *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributesPractical, get_auto_exposure_min_sensitivity, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
