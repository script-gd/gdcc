// This file was automatically generated
// Do not modify this file
#include "audio_effect_phaser.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectPhaser *godot_new_AudioEffectPhaser() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectPhaser);
}

// Methods
void godot_AudioEffectPhaser_set_range_min_hz(godot_AudioEffectPhaser *self, godot_float hz) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPhaser, set_range_min_hz, 373806689, void, self, &hz)
}
godot_float godot_AudioEffectPhaser_get_range_min_hz(const godot_AudioEffectPhaser *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPhaser, get_range_min_hz, 1740695150, godot_float, self)
}
void godot_AudioEffectPhaser_set_range_max_hz(godot_AudioEffectPhaser *self, godot_float hz) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPhaser, set_range_max_hz, 373806689, void, self, &hz)
}
godot_float godot_AudioEffectPhaser_get_range_max_hz(const godot_AudioEffectPhaser *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPhaser, get_range_max_hz, 1740695150, godot_float, self)
}
void godot_AudioEffectPhaser_set_rate_hz(godot_AudioEffectPhaser *self, godot_float hz) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPhaser, set_rate_hz, 373806689, void, self, &hz)
}
godot_float godot_AudioEffectPhaser_get_rate_hz(const godot_AudioEffectPhaser *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPhaser, get_rate_hz, 1740695150, godot_float, self)
}
void godot_AudioEffectPhaser_set_feedback(godot_AudioEffectPhaser *self, godot_float fbk) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPhaser, set_feedback, 373806689, void, self, &fbk)
}
godot_float godot_AudioEffectPhaser_get_feedback(const godot_AudioEffectPhaser *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPhaser, get_feedback, 1740695150, godot_float, self)
}
void godot_AudioEffectPhaser_set_depth(godot_AudioEffectPhaser *self, godot_float depth) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPhaser, set_depth, 373806689, void, self, &depth)
}
godot_float godot_AudioEffectPhaser_get_depth(const godot_AudioEffectPhaser *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPhaser, get_depth, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
