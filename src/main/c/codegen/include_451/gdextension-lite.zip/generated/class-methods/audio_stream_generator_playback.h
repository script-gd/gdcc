// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_GENERATOR_PLAYBACK_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_GENERATOR_PLAYBACK_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamGeneratorPlayback_push_frame(godot_AudioStreamGeneratorPlayback *self, const godot_Vector2 *frame);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamGeneratorPlayback_can_push_buffer(const godot_AudioStreamGeneratorPlayback *self, godot_int amount);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamGeneratorPlayback_push_buffer(godot_AudioStreamGeneratorPlayback *self, const godot_PackedVector2Array *frames);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamGeneratorPlayback_get_frames_available(const godot_AudioStreamGeneratorPlayback *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamGeneratorPlayback_get_skips(const godot_AudioStreamGeneratorPlayback *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamGeneratorPlayback_clear_buffer(godot_AudioStreamGeneratorPlayback *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_GENERATOR_PLAYBACK_H__
