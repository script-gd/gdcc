// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_CONTEXT_MENU_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_CONTEXT_MENU_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorContextMenuPlugin *godot_new_EditorContextMenuPlugin();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorContextMenuPlugin__popup_menu(godot_EditorContextMenuPlugin *self, const godot_PackedStringArray *paths);
GDEXTENSION_LITE_DECL void godot_EditorContextMenuPlugin_add_menu_shortcut(godot_EditorContextMenuPlugin *self, const godot_Shortcut *shortcut, const godot_Callable *callback);
GDEXTENSION_LITE_DECL void godot_EditorContextMenuPlugin_add_context_menu_item(godot_EditorContextMenuPlugin *self, const godot_String *name, const godot_Callable *callback, const godot_Texture2D *icon);
GDEXTENSION_LITE_DECL void godot_EditorContextMenuPlugin_add_context_menu_item_from_shortcut(godot_EditorContextMenuPlugin *self, const godot_String *name, const godot_Shortcut *shortcut, const godot_Texture2D *icon);
GDEXTENSION_LITE_DECL void godot_EditorContextMenuPlugin_add_context_submenu_item(godot_EditorContextMenuPlugin *self, const godot_String *name, const godot_PopupMenu *menu, const godot_Texture2D *icon);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_CONTEXT_MENU_PLUGIN_H__
