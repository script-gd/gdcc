// This file was automatically generated
// Do not modify this file
#include "animation_node_blend3.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeBlend3 *godot_new_AnimationNodeBlend3() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeBlend3);
}


#ifdef __cplusplus
}
#endif
