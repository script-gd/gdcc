// This file was automatically generated
// Do not modify this file
#include "collision_object2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
void godot_CollisionObject2D__input_event(godot_CollisionObject2D *self, const godot_Viewport *viewport, const godot_InputEvent *event, godot_int shape_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, _input_event, 1847696837, void, self, viewport, event, &shape_idx)
}
void godot_CollisionObject2D__mouse_enter(godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, _mouse_enter, 3218959716, void, self)
}
void godot_CollisionObject2D__mouse_exit(godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, _mouse_exit, 3218959716, void, self)
}
void godot_CollisionObject2D__mouse_shape_enter(godot_CollisionObject2D *self, godot_int shape_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, _mouse_shape_enter, 1286410249, void, self, &shape_idx)
}
void godot_CollisionObject2D__mouse_shape_exit(godot_CollisionObject2D *self, godot_int shape_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, _mouse_shape_exit, 1286410249, void, self, &shape_idx)
}
godot_RID godot_CollisionObject2D_get_rid(const godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_rid, 2944877500, godot_RID, self)
}
void godot_CollisionObject2D_set_collision_layer(godot_CollisionObject2D *self, godot_int layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, set_collision_layer, 1286410249, void, self, &layer)
}
godot_int godot_CollisionObject2D_get_collision_layer(const godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_collision_layer, 3905245786, godot_int, self)
}
void godot_CollisionObject2D_set_collision_mask(godot_CollisionObject2D *self, godot_int mask) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, set_collision_mask, 1286410249, void, self, &mask)
}
godot_int godot_CollisionObject2D_get_collision_mask(const godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_collision_mask, 3905245786, godot_int, self)
}
void godot_CollisionObject2D_set_collision_layer_value(godot_CollisionObject2D *self, godot_int layer_number, godot_bool value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, set_collision_layer_value, 300928843, void, self, &layer_number, &value)
}
godot_bool godot_CollisionObject2D_get_collision_layer_value(const godot_CollisionObject2D *self, godot_int layer_number) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_collision_layer_value, 1116898809, godot_bool, self, &layer_number)
}
void godot_CollisionObject2D_set_collision_mask_value(godot_CollisionObject2D *self, godot_int layer_number, godot_bool value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, set_collision_mask_value, 300928843, void, self, &layer_number, &value)
}
godot_bool godot_CollisionObject2D_get_collision_mask_value(const godot_CollisionObject2D *self, godot_int layer_number) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_collision_mask_value, 1116898809, godot_bool, self, &layer_number)
}
void godot_CollisionObject2D_set_collision_priority(godot_CollisionObject2D *self, godot_float priority) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, set_collision_priority, 373806689, void, self, &priority)
}
godot_float godot_CollisionObject2D_get_collision_priority(const godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_collision_priority, 1740695150, godot_float, self)
}
void godot_CollisionObject2D_set_disable_mode(godot_CollisionObject2D *self, godot_CollisionObject2D_DisableMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, set_disable_mode, 1919204045, void, self, &mode)
}
godot_CollisionObject2D_DisableMode godot_CollisionObject2D_get_disable_mode(const godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_disable_mode, 3172846349, godot_CollisionObject2D_DisableMode, self)
}
void godot_CollisionObject2D_set_pickable(godot_CollisionObject2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, set_pickable, 2586408642, void, self, &enabled)
}
godot_bool godot_CollisionObject2D_is_pickable(const godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, is_pickable, 36873697, godot_bool, self)
}
godot_int godot_CollisionObject2D_create_shape_owner(godot_CollisionObject2D *self, const godot_Object *owner) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, create_shape_owner, 3429307534, godot_int, self, owner)
}
void godot_CollisionObject2D_remove_shape_owner(godot_CollisionObject2D *self, godot_int owner_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, remove_shape_owner, 1286410249, void, self, &owner_id)
}
godot_PackedInt32Array godot_CollisionObject2D_get_shape_owners(godot_CollisionObject2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_shape_owners, 969006518, godot_PackedInt32Array, self)
}
void godot_CollisionObject2D_shape_owner_set_transform(godot_CollisionObject2D *self, godot_int owner_id, const godot_Transform2D *transform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, shape_owner_set_transform, 30160968, void, self, &owner_id, transform)
}
godot_Transform2D godot_CollisionObject2D_shape_owner_get_transform(const godot_CollisionObject2D *self, godot_int owner_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, shape_owner_get_transform, 3836996910, godot_Transform2D, self, &owner_id)
}
godot_Object * godot_CollisionObject2D_shape_owner_get_owner(const godot_CollisionObject2D *self, godot_int owner_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, shape_owner_get_owner, 3332903315, godot_Object *, self, &owner_id)
}
void godot_CollisionObject2D_shape_owner_set_disabled(godot_CollisionObject2D *self, godot_int owner_id, godot_bool disabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, shape_owner_set_disabled, 300928843, void, self, &owner_id, &disabled)
}
godot_bool godot_CollisionObject2D_is_shape_owner_disabled(const godot_CollisionObject2D *self, godot_int owner_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, is_shape_owner_disabled, 1116898809, godot_bool, self, &owner_id)
}
void godot_CollisionObject2D_shape_owner_set_one_way_collision(godot_CollisionObject2D *self, godot_int owner_id, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, shape_owner_set_one_way_collision, 300928843, void, self, &owner_id, &enable)
}
godot_bool godot_CollisionObject2D_is_shape_owner_one_way_collision_enabled(const godot_CollisionObject2D *self, godot_int owner_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, is_shape_owner_one_way_collision_enabled, 1116898809, godot_bool, self, &owner_id)
}
void godot_CollisionObject2D_shape_owner_set_one_way_collision_margin(godot_CollisionObject2D *self, godot_int owner_id, godot_float margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, shape_owner_set_one_way_collision_margin, 1602489585, void, self, &owner_id, &margin)
}
godot_float godot_CollisionObject2D_get_shape_owner_one_way_collision_margin(const godot_CollisionObject2D *self, godot_int owner_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, get_shape_owner_one_way_collision_margin, 2339986948, godot_float, self, &owner_id)
}
void godot_CollisionObject2D_shape_owner_add_shape(godot_CollisionObject2D *self, godot_int owner_id, const godot_Shape2D *shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, shape_owner_add_shape, 2077425081, void, self, &owner_id, shape)
}
godot_int godot_CollisionObject2D_shape_owner_get_shape_count(const godot_CollisionObject2D *self, godot_int owner_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, shape_owner_get_shape_count, 923996154, godot_int, self, &owner_id)
}
godot_Shape2D * godot_CollisionObject2D_shape_owner_get_shape(const godot_CollisionObject2D *self, godot_int owner_id, godot_int shape_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, shape_owner_get_shape, 3106725749, godot_Shape2D *, self, &owner_id, &shape_id)
}
godot_int godot_CollisionObject2D_shape_owner_get_shape_index(const godot_CollisionObject2D *self, godot_int owner_id, godot_int shape_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, shape_owner_get_shape_index, 3175239445, godot_int, self, &owner_id, &shape_id)
}
void godot_CollisionObject2D_shape_owner_remove_shape(godot_CollisionObject2D *self, godot_int owner_id, godot_int shape_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, shape_owner_remove_shape, 3937882851, void, self, &owner_id, &shape_id)
}
void godot_CollisionObject2D_shape_owner_clear_shapes(godot_CollisionObject2D *self, godot_int owner_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionObject2D, shape_owner_clear_shapes, 1286410249, void, self, &owner_id)
}
godot_int godot_CollisionObject2D_shape_find_owner(const godot_CollisionObject2D *self, godot_int shape_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionObject2D, shape_find_owner, 923996154, godot_int, self, &shape_index)
}


#ifdef __cplusplus
}
#endif
