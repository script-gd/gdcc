// This file was automatically generated
// Do not modify this file
#include "animatable_body2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimatableBody2D *godot_new_AnimatableBody2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimatableBody2D);
}

// Methods
void godot_AnimatableBody2D_set_sync_to_physics(godot_AnimatableBody2D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatableBody2D, set_sync_to_physics, 2586408642, void, self, &enable)
}
godot_bool godot_AnimatableBody2D_is_sync_to_physics_enabled(const godot_AnimatableBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatableBody2D, is_sync_to_physics_enabled, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
