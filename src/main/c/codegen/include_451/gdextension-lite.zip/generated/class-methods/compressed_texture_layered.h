// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE_LAYERED_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE_LAYERED_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL godot_Error godot_CompressedTextureLayered_load(godot_CompressedTextureLayered *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_String godot_CompressedTextureLayered_get_load_path(const godot_CompressedTextureLayered *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE_LAYERED_H__
