// This file was automatically generated
// Do not modify this file
#include "aspect_ratio_container.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AspectRatioContainer *godot_new_AspectRatioContainer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AspectRatioContainer);
}

// Methods
void godot_AspectRatioContainer_set_ratio(godot_AspectRatioContainer *self, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AspectRatioContainer, set_ratio, 373806689, void, self, &ratio)
}
godot_float godot_AspectRatioContainer_get_ratio(const godot_AspectRatioContainer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AspectRatioContainer, get_ratio, 1740695150, godot_float, self)
}
void godot_AspectRatioContainer_set_stretch_mode(godot_AspectRatioContainer *self, godot_AspectRatioContainer_StretchMode stretch_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AspectRatioContainer, set_stretch_mode, 1876743467, void, self, &stretch_mode)
}
godot_AspectRatioContainer_StretchMode godot_AspectRatioContainer_get_stretch_mode(const godot_AspectRatioContainer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AspectRatioContainer, get_stretch_mode, 3416449033, godot_AspectRatioContainer_StretchMode, self)
}
void godot_AspectRatioContainer_set_alignment_horizontal(godot_AspectRatioContainer *self, godot_AspectRatioContainer_AlignmentMode alignment_horizontal) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AspectRatioContainer, set_alignment_horizontal, 2147829016, void, self, &alignment_horizontal)
}
godot_AspectRatioContainer_AlignmentMode godot_AspectRatioContainer_get_alignment_horizontal(const godot_AspectRatioContainer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AspectRatioContainer, get_alignment_horizontal, 3838875429, godot_AspectRatioContainer_AlignmentMode, self)
}
void godot_AspectRatioContainer_set_alignment_vertical(godot_AspectRatioContainer *self, godot_AspectRatioContainer_AlignmentMode alignment_vertical) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AspectRatioContainer, set_alignment_vertical, 2147829016, void, self, &alignment_vertical)
}
godot_AspectRatioContainer_AlignmentMode godot_AspectRatioContainer_get_alignment_vertical(const godot_AspectRatioContainer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AspectRatioContainer, get_alignment_vertical, 3838875429, godot_AspectRatioContainer_AlignmentMode, self)
}


#ifdef __cplusplus
}
#endif
