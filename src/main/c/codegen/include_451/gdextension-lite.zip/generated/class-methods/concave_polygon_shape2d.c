// This file was automatically generated
// Do not modify this file
#include "concave_polygon_shape2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ConcavePolygonShape2D *godot_new_ConcavePolygonShape2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ConcavePolygonShape2D);
}

// Methods
void godot_ConcavePolygonShape2D_set_segments(godot_ConcavePolygonShape2D *self, const godot_PackedVector2Array *segments) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConcavePolygonShape2D, set_segments, 1509147220, void, self, segments)
}
godot_PackedVector2Array godot_ConcavePolygonShape2D_get_segments(const godot_ConcavePolygonShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConcavePolygonShape2D, get_segments, 2961356807, godot_PackedVector2Array, self)
}


#ifdef __cplusplus
}
#endif
