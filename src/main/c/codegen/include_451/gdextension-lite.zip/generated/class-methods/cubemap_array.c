// This file was automatically generated
// Do not modify this file
#include "cubemap_array.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CubemapArray *godot_new_CubemapArray() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CubemapArray);
}

// Methods
godot_Resource * godot_CubemapArray_create_placeholder(const godot_CubemapArray *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CubemapArray, create_placeholder, 121922552, godot_Resource *, self)
}


#ifdef __cplusplus
}
#endif
