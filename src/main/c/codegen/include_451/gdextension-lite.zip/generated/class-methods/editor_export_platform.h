// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLATFORM_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLATFORM_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL godot_String godot_EditorExportPlatform_get_os_name(const godot_EditorExportPlatform *self);
GDEXTENSION_LITE_DECL godot_EditorExportPreset * godot_EditorExportPlatform_create_preset(godot_EditorExportPlatform *self);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorExportPlatform_find_export_template(const godot_EditorExportPlatform *self, const godot_String *template_file_name);
GDEXTENSION_LITE_DECL godot_Array godot_EditorExportPlatform_get_current_presets(const godot_EditorExportPlatform *self);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorExportPlatform_save_pack(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, godot_bool embed);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorExportPlatform_save_zip(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorExportPlatform_save_pack_patch(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorExportPlatform_save_zip_patch(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorExportPlatform_gen_export_flags(godot_EditorExportPlatform *self, const godot_EditorExportPlatform_DebugFlags *flags);
GDEXTENSION_LITE_DECL godot_Error godot_EditorExportPlatform_export_project_files(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_Callable *save_cb, const godot_Callable *shared_cb);
GDEXTENSION_LITE_DECL godot_Error godot_EditorExportPlatform_export_project(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags);
GDEXTENSION_LITE_DECL godot_Error godot_EditorExportPlatform_export_pack(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags);
GDEXTENSION_LITE_DECL godot_Error godot_EditorExportPlatform_export_zip(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags);
GDEXTENSION_LITE_DECL godot_Error godot_EditorExportPlatform_export_pack_patch(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_PackedStringArray *patches, const godot_EditorExportPlatform_DebugFlags *flags);
GDEXTENSION_LITE_DECL godot_Error godot_EditorExportPlatform_export_zip_patch(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_PackedStringArray *patches, const godot_EditorExportPlatform_DebugFlags *flags);
GDEXTENSION_LITE_DECL void godot_EditorExportPlatform_clear_messages(godot_EditorExportPlatform *self);
GDEXTENSION_LITE_DECL void godot_EditorExportPlatform_add_message(godot_EditorExportPlatform *self, godot_EditorExportPlatform_ExportMessageType type, const godot_String *category, const godot_String *message);
GDEXTENSION_LITE_DECL godot_int godot_EditorExportPlatform_get_message_count(const godot_EditorExportPlatform *self);
GDEXTENSION_LITE_DECL godot_EditorExportPlatform_ExportMessageType godot_EditorExportPlatform_get_message_type(const godot_EditorExportPlatform *self, godot_int index);
GDEXTENSION_LITE_DECL godot_String godot_EditorExportPlatform_get_message_category(const godot_EditorExportPlatform *self, godot_int index);
GDEXTENSION_LITE_DECL godot_String godot_EditorExportPlatform_get_message_text(const godot_EditorExportPlatform *self, godot_int index);
GDEXTENSION_LITE_DECL godot_EditorExportPlatform_ExportMessageType godot_EditorExportPlatform_get_worst_message_type(const godot_EditorExportPlatform *self);
GDEXTENSION_LITE_DECL godot_Error godot_EditorExportPlatform_ssh_run_on_remote(const godot_EditorExportPlatform *self, const godot_String *host, const godot_String *port, const godot_PackedStringArray *ssh_arg, const godot_String *cmd_args, const godot_Array *output, godot_int port_fwd);
GDEXTENSION_LITE_DECL godot_int godot_EditorExportPlatform_ssh_run_on_remote_no_wait(const godot_EditorExportPlatform *self, const godot_String *host, const godot_String *port, const godot_PackedStringArray *ssh_args, const godot_String *cmd_args, godot_int port_fwd);
GDEXTENSION_LITE_DECL godot_Error godot_EditorExportPlatform_ssh_push_to_remote(const godot_EditorExportPlatform *self, const godot_String *host, const godot_String *port, const godot_PackedStringArray *scp_args, const godot_String *src_file, const godot_String *dst_file);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorExportPlatform_get_internal_export_files(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorExportPlatform_get_forced_export_files(const godot_EditorExportPreset *preset);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLATFORM_H__
