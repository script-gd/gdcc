// This file was automatically generated
// Do not modify this file
#include "animation_node_sub2.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeSub2 *godot_new_AnimationNodeSub2() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeSub2);
}


#ifdef __cplusplus
}
#endif
