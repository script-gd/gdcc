// This file was automatically generated
// Do not modify this file
#include "editor_export_platform_vision_os.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlatformVisionOS *godot_new_EditorExportPlatformVisionOS() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlatformVisionOS);
}


#ifdef __cplusplus
}
#endif
