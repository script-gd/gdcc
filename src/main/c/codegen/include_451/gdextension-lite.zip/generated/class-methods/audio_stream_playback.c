// This file was automatically generated
// Do not modify this file
#include "audio_stream_playback.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamPlayback *godot_new_AudioStreamPlayback() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamPlayback);
}

// Methods
void godot_AudioStreamPlayback__start(godot_AudioStreamPlayback *self, godot_float from_pos) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, _start, 373806689, void, self, &from_pos)
}
void godot_AudioStreamPlayback__stop(godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, _stop, 3218959716, void, self)
}
godot_bool godot_AudioStreamPlayback__is_playing(const godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, _is_playing, 36873697, godot_bool, self)
}
godot_int godot_AudioStreamPlayback__get_loop_count(const godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, _get_loop_count, 3905245786, godot_int, self)
}
godot_float godot_AudioStreamPlayback__get_playback_position(const godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, _get_playback_position, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayback__seek(godot_AudioStreamPlayback *self, godot_float position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, _seek, 373806689, void, self, &position)
}
godot_int godot_AudioStreamPlayback__mix(godot_AudioStreamPlayback *self, godot_AudioFrame* buffer, godot_float rate_scale, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, _mix, 925936155, godot_int, self, buffer, &rate_scale, &frames)
}
void godot_AudioStreamPlayback__tag_used_streams(godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, _tag_used_streams, 3218959716, void, self)
}
void godot_AudioStreamPlayback__set_parameter(godot_AudioStreamPlayback *self, const godot_StringName *name, const godot_Variant *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, _set_parameter, 3776071444, void, self, name, value)
}
godot_Variant godot_AudioStreamPlayback__get_parameter(const godot_AudioStreamPlayback *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, _get_parameter, 2760726917, godot_Variant, self, name)
}
void godot_AudioStreamPlayback_set_sample_playback(godot_AudioStreamPlayback *self, const godot_AudioSamplePlayback *playback_sample) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, set_sample_playback, 3195455091, void, self, playback_sample)
}
godot_AudioSamplePlayback * godot_AudioStreamPlayback_get_sample_playback(const godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, get_sample_playback, 3482738536, godot_AudioSamplePlayback *, self)
}
godot_PackedVector2Array godot_AudioStreamPlayback_mix_audio(godot_AudioStreamPlayback *self, godot_float rate_scale, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, mix_audio, 3341291446, godot_PackedVector2Array, self, &rate_scale, &frames)
}
void godot_AudioStreamPlayback_start(godot_AudioStreamPlayback *self, godot_float from_pos) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, start, 1958160172, void, self, &from_pos)
}
void godot_AudioStreamPlayback_seek(godot_AudioStreamPlayback *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, seek, 1958160172, void, self, &time)
}
void godot_AudioStreamPlayback_stop(godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayback, stop, 3218959716, void, self)
}
godot_int godot_AudioStreamPlayback_get_loop_count(const godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, get_loop_count, 3905245786, godot_int, self)
}
godot_float godot_AudioStreamPlayback_get_playback_position(const godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, get_playback_position, 1740695150, godot_float, self)
}
godot_bool godot_AudioStreamPlayback_is_playing(const godot_AudioStreamPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayback, is_playing, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
