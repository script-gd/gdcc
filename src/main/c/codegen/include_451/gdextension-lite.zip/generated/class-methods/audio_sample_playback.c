// This file was automatically generated
// Do not modify this file
#include "audio_sample_playback.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioSamplePlayback *godot_new_AudioSamplePlayback() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioSamplePlayback);
}


#ifdef __cplusplus
}
#endif
