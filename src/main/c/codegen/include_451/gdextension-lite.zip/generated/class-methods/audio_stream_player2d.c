// This file was automatically generated
// Do not modify this file
#include "audio_stream_player2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamPlayer2D *godot_new_AudioStreamPlayer2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamPlayer2D);
}

// Methods
void godot_AudioStreamPlayer2D_set_stream(godot_AudioStreamPlayer2D *self, const godot_AudioStream *stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_stream, 2210767741, void, self, stream)
}
godot_AudioStream * godot_AudioStreamPlayer2D_get_stream(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_stream, 160907539, godot_AudioStream *, self)
}
void godot_AudioStreamPlayer2D_set_volume_db(godot_AudioStreamPlayer2D *self, godot_float volume_db) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_volume_db, 373806689, void, self, &volume_db)
}
godot_float godot_AudioStreamPlayer2D_get_volume_db(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_volume_db, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayer2D_set_volume_linear(godot_AudioStreamPlayer2D *self, godot_float volume_linear) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_volume_linear, 373806689, void, self, &volume_linear)
}
godot_float godot_AudioStreamPlayer2D_get_volume_linear(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_volume_linear, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayer2D_set_pitch_scale(godot_AudioStreamPlayer2D *self, godot_float pitch_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_pitch_scale, 373806689, void, self, &pitch_scale)
}
godot_float godot_AudioStreamPlayer2D_get_pitch_scale(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_pitch_scale, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayer2D_play(godot_AudioStreamPlayer2D *self, godot_float from_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, play, 1958160172, void, self, &from_position)
}
void godot_AudioStreamPlayer2D_seek(godot_AudioStreamPlayer2D *self, godot_float to_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, seek, 373806689, void, self, &to_position)
}
void godot_AudioStreamPlayer2D_stop(godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, stop, 3218959716, void, self)
}
godot_bool godot_AudioStreamPlayer2D_is_playing(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, is_playing, 36873697, godot_bool, self)
}
godot_float godot_AudioStreamPlayer2D_get_playback_position(godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_playback_position, 191475506, godot_float, self)
}
void godot_AudioStreamPlayer2D_set_bus(godot_AudioStreamPlayer2D *self, const godot_StringName *bus) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_bus, 3304788590, void, self, bus)
}
godot_StringName godot_AudioStreamPlayer2D_get_bus(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_bus, 2002593661, godot_StringName, self)
}
void godot_AudioStreamPlayer2D_set_autoplay(godot_AudioStreamPlayer2D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_autoplay, 2586408642, void, self, &enable)
}
godot_bool godot_AudioStreamPlayer2D_is_autoplay_enabled(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, is_autoplay_enabled, 36873697, godot_bool, self)
}
void godot_AudioStreamPlayer2D_set_playing(godot_AudioStreamPlayer2D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_playing, 2586408642, void, self, &enable)
}
void godot_AudioStreamPlayer2D_set_max_distance(godot_AudioStreamPlayer2D *self, godot_float pixels) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_max_distance, 373806689, void, self, &pixels)
}
godot_float godot_AudioStreamPlayer2D_get_max_distance(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_max_distance, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayer2D_set_attenuation(godot_AudioStreamPlayer2D *self, godot_float curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_attenuation, 373806689, void, self, &curve)
}
godot_float godot_AudioStreamPlayer2D_get_attenuation(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_attenuation, 1740695150, godot_float, self)
}
void godot_AudioStreamPlayer2D_set_area_mask(godot_AudioStreamPlayer2D *self, godot_int mask) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_area_mask, 1286410249, void, self, &mask)
}
godot_int godot_AudioStreamPlayer2D_get_area_mask(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_area_mask, 3905245786, godot_int, self)
}
void godot_AudioStreamPlayer2D_set_stream_paused(godot_AudioStreamPlayer2D *self, godot_bool pause) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_stream_paused, 2586408642, void, self, &pause)
}
godot_bool godot_AudioStreamPlayer2D_get_stream_paused(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_stream_paused, 36873697, godot_bool, self)
}
void godot_AudioStreamPlayer2D_set_max_polyphony(godot_AudioStreamPlayer2D *self, godot_int max_polyphony) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_max_polyphony, 1286410249, void, self, &max_polyphony)
}
godot_int godot_AudioStreamPlayer2D_get_max_polyphony(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_max_polyphony, 3905245786, godot_int, self)
}
void godot_AudioStreamPlayer2D_set_panning_strength(godot_AudioStreamPlayer2D *self, godot_float panning_strength) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_panning_strength, 373806689, void, self, &panning_strength)
}
godot_float godot_AudioStreamPlayer2D_get_panning_strength(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_panning_strength, 1740695150, godot_float, self)
}
godot_bool godot_AudioStreamPlayer2D_has_stream_playback(godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, has_stream_playback, 2240911060, godot_bool, self)
}
godot_AudioStreamPlayback * godot_AudioStreamPlayer2D_get_stream_playback(godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_stream_playback, 210135309, godot_AudioStreamPlayback *, self)
}
void godot_AudioStreamPlayer2D_set_playback_type(godot_AudioStreamPlayer2D *self, godot_AudioServer_PlaybackType playback_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlayer2D, set_playback_type, 725473817, void, self, &playback_type)
}
godot_AudioServer_PlaybackType godot_AudioStreamPlayer2D_get_playback_type(const godot_AudioStreamPlayer2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlayer2D, get_playback_type, 4011264623, godot_AudioServer_PlaybackType, self)
}


#ifdef __cplusplus
}
#endif
