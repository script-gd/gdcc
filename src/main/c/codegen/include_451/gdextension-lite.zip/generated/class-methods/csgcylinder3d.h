// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGCYLINDER3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGCYLINDER3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CSGCylinder3D *godot_new_CSGCylinder3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CSGCylinder3D_set_radius(godot_CSGCylinder3D *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CSGCylinder3D_get_radius(const godot_CSGCylinder3D *self);
GDEXTENSION_LITE_DECL void godot_CSGCylinder3D_set_height(godot_CSGCylinder3D *self, godot_float height);
GDEXTENSION_LITE_DECL godot_float godot_CSGCylinder3D_get_height(const godot_CSGCylinder3D *self);
GDEXTENSION_LITE_DECL void godot_CSGCylinder3D_set_sides(godot_CSGCylinder3D *self, godot_int sides);
GDEXTENSION_LITE_DECL godot_int godot_CSGCylinder3D_get_sides(const godot_CSGCylinder3D *self);
GDEXTENSION_LITE_DECL void godot_CSGCylinder3D_set_cone(godot_CSGCylinder3D *self, godot_bool cone);
GDEXTENSION_LITE_DECL godot_bool godot_CSGCylinder3D_is_cone(const godot_CSGCylinder3D *self);
GDEXTENSION_LITE_DECL void godot_CSGCylinder3D_set_material(godot_CSGCylinder3D *self, const godot_Material *material);
GDEXTENSION_LITE_DECL godot_Material * godot_CSGCylinder3D_get_material(const godot_CSGCylinder3D *self);
GDEXTENSION_LITE_DECL void godot_CSGCylinder3D_set_smooth_faces(godot_CSGCylinder3D *self, godot_bool smooth_faces);
GDEXTENSION_LITE_DECL godot_bool godot_CSGCylinder3D_get_smooth_faces(const godot_CSGCylinder3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGCYLINDER3D_H__
