// This file was automatically generated
// Do not modify this file
#include "csgmesh3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CSGMesh3D *godot_new_CSGMesh3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CSGMesh3D);
}

// Methods
void godot_CSGMesh3D_set_mesh(godot_CSGMesh3D *self, const godot_Mesh *mesh) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGMesh3D, set_mesh, 194775623, void, self, mesh)
}
godot_Mesh * godot_CSGMesh3D_get_mesh(godot_CSGMesh3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGMesh3D, get_mesh, 4081188045, godot_Mesh *, self)
}
void godot_CSGMesh3D_set_material(godot_CSGMesh3D *self, const godot_Material *material) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGMesh3D, set_material, 2757459619, void, self, material)
}
godot_Material * godot_CSGMesh3D_get_material(const godot_CSGMesh3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGMesh3D, get_material, 5934680, godot_Material *, self)
}


#ifdef __cplusplus
}
#endif
