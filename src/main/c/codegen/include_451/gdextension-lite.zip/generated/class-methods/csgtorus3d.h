// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGTORUS3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGTORUS3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CSGTorus3D *godot_new_CSGTorus3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CSGTorus3D_set_inner_radius(godot_CSGTorus3D *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CSGTorus3D_get_inner_radius(const godot_CSGTorus3D *self);
GDEXTENSION_LITE_DECL void godot_CSGTorus3D_set_outer_radius(godot_CSGTorus3D *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CSGTorus3D_get_outer_radius(const godot_CSGTorus3D *self);
GDEXTENSION_LITE_DECL void godot_CSGTorus3D_set_sides(godot_CSGTorus3D *self, godot_int sides);
GDEXTENSION_LITE_DECL godot_int godot_CSGTorus3D_get_sides(const godot_CSGTorus3D *self);
GDEXTENSION_LITE_DECL void godot_CSGTorus3D_set_ring_sides(godot_CSGTorus3D *self, godot_int sides);
GDEXTENSION_LITE_DECL godot_int godot_CSGTorus3D_get_ring_sides(const godot_CSGTorus3D *self);
GDEXTENSION_LITE_DECL void godot_CSGTorus3D_set_material(godot_CSGTorus3D *self, const godot_Material *material);
GDEXTENSION_LITE_DECL godot_Material * godot_CSGTorus3D_get_material(const godot_CSGTorus3D *self);
GDEXTENSION_LITE_DECL void godot_CSGTorus3D_set_smooth_faces(godot_CSGTorus3D *self, godot_bool smooth_faces);
GDEXTENSION_LITE_DECL godot_bool godot_CSGTorus3D_get_smooth_faces(const godot_CSGTorus3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGTORUS3D_H__
