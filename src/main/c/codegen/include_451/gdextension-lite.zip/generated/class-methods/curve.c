// This file was automatically generated
// Do not modify this file
#include "curve.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Curve *godot_new_Curve() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Curve);
}

// Methods
godot_int godot_Curve_get_point_count(const godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_point_count, 3905245786, godot_int, self)
}
void godot_Curve_set_point_count(godot_Curve *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_point_count, 1286410249, void, self, &count)
}
godot_int godot_Curve_add_point(godot_Curve *self, const godot_Vector2 *position, godot_float left_tangent, godot_float right_tangent, godot_Curve_TangentMode left_mode, godot_Curve_TangentMode right_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, add_point, 434072736, godot_int, self, position, &left_tangent, &right_tangent, &left_mode, &right_mode)
}
void godot_Curve_remove_point(godot_Curve *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, remove_point, 1286410249, void, self, &index)
}
void godot_Curve_clear_points(godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, clear_points, 3218959716, void, self)
}
godot_Vector2 godot_Curve_get_point_position(const godot_Curve *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_point_position, 2299179447, godot_Vector2, self, &index)
}
void godot_Curve_set_point_value(godot_Curve *self, godot_int index, godot_float y) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_point_value, 1602489585, void, self, &index, &y)
}
godot_int godot_Curve_set_point_offset(godot_Curve *self, godot_int index, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, set_point_offset, 3780573764, godot_int, self, &index, &offset)
}
godot_float godot_Curve_sample(const godot_Curve *self, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, sample, 3919130443, godot_float, self, &offset)
}
godot_float godot_Curve_sample_baked(const godot_Curve *self, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, sample_baked, 3919130443, godot_float, self, &offset)
}
godot_float godot_Curve_get_point_left_tangent(const godot_Curve *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_point_left_tangent, 2339986948, godot_float, self, &index)
}
godot_float godot_Curve_get_point_right_tangent(const godot_Curve *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_point_right_tangent, 2339986948, godot_float, self, &index)
}
godot_Curve_TangentMode godot_Curve_get_point_left_mode(const godot_Curve *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_point_left_mode, 426950354, godot_Curve_TangentMode, self, &index)
}
godot_Curve_TangentMode godot_Curve_get_point_right_mode(const godot_Curve *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_point_right_mode, 426950354, godot_Curve_TangentMode, self, &index)
}
void godot_Curve_set_point_left_tangent(godot_Curve *self, godot_int index, godot_float tangent) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_point_left_tangent, 1602489585, void, self, &index, &tangent)
}
void godot_Curve_set_point_right_tangent(godot_Curve *self, godot_int index, godot_float tangent) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_point_right_tangent, 1602489585, void, self, &index, &tangent)
}
void godot_Curve_set_point_left_mode(godot_Curve *self, godot_int index, godot_Curve_TangentMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_point_left_mode, 1217242874, void, self, &index, &mode)
}
void godot_Curve_set_point_right_mode(godot_Curve *self, godot_int index, godot_Curve_TangentMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_point_right_mode, 1217242874, void, self, &index, &mode)
}
godot_float godot_Curve_get_min_value(const godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_min_value, 1740695150, godot_float, self)
}
void godot_Curve_set_min_value(godot_Curve *self, godot_float min) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_min_value, 373806689, void, self, &min)
}
godot_float godot_Curve_get_max_value(const godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_max_value, 1740695150, godot_float, self)
}
void godot_Curve_set_max_value(godot_Curve *self, godot_float max) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_max_value, 373806689, void, self, &max)
}
godot_float godot_Curve_get_value_range(const godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_value_range, 1740695150, godot_float, self)
}
godot_float godot_Curve_get_min_domain(const godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_min_domain, 1740695150, godot_float, self)
}
void godot_Curve_set_min_domain(godot_Curve *self, godot_float min) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_min_domain, 373806689, void, self, &min)
}
godot_float godot_Curve_get_max_domain(const godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_max_domain, 1740695150, godot_float, self)
}
void godot_Curve_set_max_domain(godot_Curve *self, godot_float max) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_max_domain, 373806689, void, self, &max)
}
godot_float godot_Curve_get_domain_range(const godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_domain_range, 1740695150, godot_float, self)
}
void godot_Curve_clean_dupes(godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, clean_dupes, 3218959716, void, self)
}
void godot_Curve_bake(godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, bake, 3218959716, void, self)
}
godot_int godot_Curve_get_bake_resolution(const godot_Curve *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve, get_bake_resolution, 3905245786, godot_int, self)
}
void godot_Curve_set_bake_resolution(godot_Curve *self, godot_int resolution) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve, set_bake_resolution, 1286410249, void, self, &resolution)
}


#ifdef __cplusplus
}
#endif
