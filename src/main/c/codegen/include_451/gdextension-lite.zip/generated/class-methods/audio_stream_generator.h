// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_GENERATOR_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_GENERATOR_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamGenerator *godot_new_AudioStreamGenerator();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioStreamGenerator_set_mix_rate(godot_AudioStreamGenerator *self, godot_float hz);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamGenerator_get_mix_rate(const godot_AudioStreamGenerator *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamGenerator_set_mix_rate_mode(godot_AudioStreamGenerator *self, godot_AudioStreamGenerator_AudioStreamGeneratorMixRate mode);
GDEXTENSION_LITE_DECL godot_AudioStreamGenerator_AudioStreamGeneratorMixRate godot_AudioStreamGenerator_get_mix_rate_mode(const godot_AudioStreamGenerator *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamGenerator_set_buffer_length(godot_AudioStreamGenerator *self, godot_float seconds);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamGenerator_get_buffer_length(const godot_AudioStreamGenerator *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_GENERATOR_H__
