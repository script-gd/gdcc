// This file was automatically generated
// Do not modify this file
#include "animation_node_blend_tree.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeBlendTree *godot_new_AnimationNodeBlendTree() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeBlendTree);
}

// Methods
void godot_AnimationNodeBlendTree_add_node(godot_AnimationNodeBlendTree *self, const godot_StringName *name, const godot_AnimationNode *node, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendTree, add_node, 1980270704, void, self, name, node, position)
}
godot_AnimationNode * godot_AnimationNodeBlendTree_get_node(const godot_AnimationNodeBlendTree *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendTree, get_node, 625644256, godot_AnimationNode *, self, name)
}
void godot_AnimationNodeBlendTree_remove_node(godot_AnimationNodeBlendTree *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendTree, remove_node, 3304788590, void, self, name)
}
void godot_AnimationNodeBlendTree_rename_node(godot_AnimationNodeBlendTree *self, const godot_StringName *name, const godot_StringName *new_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendTree, rename_node, 3740211285, void, self, name, new_name)
}
godot_bool godot_AnimationNodeBlendTree_has_node(const godot_AnimationNodeBlendTree *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendTree, has_node, 2619796661, godot_bool, self, name)
}
void godot_AnimationNodeBlendTree_connect_node(godot_AnimationNodeBlendTree *self, const godot_StringName *input_node, godot_int input_index, const godot_StringName *output_node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendTree, connect_node, 2168001410, void, self, input_node, &input_index, output_node)
}
void godot_AnimationNodeBlendTree_disconnect_node(godot_AnimationNodeBlendTree *self, const godot_StringName *input_node, godot_int input_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendTree, disconnect_node, 2415702435, void, self, input_node, &input_index)
}
godot_TypedArray(godot_StringName) godot_AnimationNodeBlendTree_get_node_list(const godot_AnimationNodeBlendTree *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendTree, get_node_list, 3995934104, godot_TypedArray(godot_StringName), self)
}
void godot_AnimationNodeBlendTree_set_node_position(godot_AnimationNodeBlendTree *self, const godot_StringName *name, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendTree, set_node_position, 1999414630, void, self, name, position)
}
godot_Vector2 godot_AnimationNodeBlendTree_get_node_position(const godot_AnimationNodeBlendTree *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendTree, get_node_position, 3100822709, godot_Vector2, self, name)
}
void godot_AnimationNodeBlendTree_set_graph_offset(godot_AnimationNodeBlendTree *self, const godot_Vector2 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendTree, set_graph_offset, 743155724, void, self, offset)
}
godot_Vector2 godot_AnimationNodeBlendTree_get_graph_offset(const godot_AnimationNodeBlendTree *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendTree, get_graph_offset, 3341600327, godot_Vector2, self)
}


#ifdef __cplusplus
}
#endif
