// This file was automatically generated
// Do not modify this file
#include "directional_light3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_DirectionalLight3D *godot_new_DirectionalLight3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(DirectionalLight3D);
}

// Methods
void godot_DirectionalLight3D_set_shadow_mode(godot_DirectionalLight3D *self, godot_DirectionalLight3D_ShadowMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DirectionalLight3D, set_shadow_mode, 1261211726, void, self, &mode)
}
godot_DirectionalLight3D_ShadowMode godot_DirectionalLight3D_get_shadow_mode(const godot_DirectionalLight3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirectionalLight3D, get_shadow_mode, 2765228544, godot_DirectionalLight3D_ShadowMode, self)
}
void godot_DirectionalLight3D_set_blend_splits(godot_DirectionalLight3D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DirectionalLight3D, set_blend_splits, 2586408642, void, self, &enabled)
}
godot_bool godot_DirectionalLight3D_is_blend_splits_enabled(const godot_DirectionalLight3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirectionalLight3D, is_blend_splits_enabled, 36873697, godot_bool, self)
}
void godot_DirectionalLight3D_set_sky_mode(godot_DirectionalLight3D *self, godot_DirectionalLight3D_SkyMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DirectionalLight3D, set_sky_mode, 2691194817, void, self, &mode)
}
godot_DirectionalLight3D_SkyMode godot_DirectionalLight3D_get_sky_mode(const godot_DirectionalLight3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirectionalLight3D, get_sky_mode, 3819982774, godot_DirectionalLight3D_SkyMode, self)
}


#ifdef __cplusplus
}
#endif
