// This file was automatically generated
// Do not modify this file
#include "animation_node_blend_space2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeBlendSpace2D *godot_new_AnimationNodeBlendSpace2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeBlendSpace2D);
}

// Methods
void godot_AnimationNodeBlendSpace2D_add_blend_point(godot_AnimationNodeBlendSpace2D *self, const godot_AnimationRootNode *node, const godot_Vector2 *pos, godot_int at_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, add_blend_point, 402261981, void, self, node, pos, &at_index)
}
void godot_AnimationNodeBlendSpace2D_set_blend_point_position(godot_AnimationNodeBlendSpace2D *self, godot_int point, const godot_Vector2 *pos) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_blend_point_position, 163021252, void, self, &point, pos)
}
godot_Vector2 godot_AnimationNodeBlendSpace2D_get_blend_point_position(const godot_AnimationNodeBlendSpace2D *self, godot_int point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_blend_point_position, 2299179447, godot_Vector2, self, &point)
}
void godot_AnimationNodeBlendSpace2D_set_blend_point_node(godot_AnimationNodeBlendSpace2D *self, godot_int point, const godot_AnimationRootNode *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_blend_point_node, 4240341528, void, self, &point, node)
}
godot_AnimationRootNode * godot_AnimationNodeBlendSpace2D_get_blend_point_node(const godot_AnimationNodeBlendSpace2D *self, godot_int point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_blend_point_node, 665599029, godot_AnimationRootNode *, self, &point)
}
void godot_AnimationNodeBlendSpace2D_remove_blend_point(godot_AnimationNodeBlendSpace2D *self, godot_int point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, remove_blend_point, 1286410249, void, self, &point)
}
godot_int godot_AnimationNodeBlendSpace2D_get_blend_point_count(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_blend_point_count, 3905245786, godot_int, self)
}
void godot_AnimationNodeBlendSpace2D_add_triangle(godot_AnimationNodeBlendSpace2D *self, godot_int x, godot_int y, godot_int z, godot_int at_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, add_triangle, 753017335, void, self, &x, &y, &z, &at_index)
}
godot_int godot_AnimationNodeBlendSpace2D_get_triangle_point(godot_AnimationNodeBlendSpace2D *self, godot_int triangle, godot_int point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_triangle_point, 50157827, godot_int, self, &triangle, &point)
}
void godot_AnimationNodeBlendSpace2D_remove_triangle(godot_AnimationNodeBlendSpace2D *self, godot_int triangle) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, remove_triangle, 1286410249, void, self, &triangle)
}
godot_int godot_AnimationNodeBlendSpace2D_get_triangle_count(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_triangle_count, 3905245786, godot_int, self)
}
void godot_AnimationNodeBlendSpace2D_set_min_space(godot_AnimationNodeBlendSpace2D *self, const godot_Vector2 *min_space) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_min_space, 743155724, void, self, min_space)
}
godot_Vector2 godot_AnimationNodeBlendSpace2D_get_min_space(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_min_space, 3341600327, godot_Vector2, self)
}
void godot_AnimationNodeBlendSpace2D_set_max_space(godot_AnimationNodeBlendSpace2D *self, const godot_Vector2 *max_space) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_max_space, 743155724, void, self, max_space)
}
godot_Vector2 godot_AnimationNodeBlendSpace2D_get_max_space(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_max_space, 3341600327, godot_Vector2, self)
}
void godot_AnimationNodeBlendSpace2D_set_snap(godot_AnimationNodeBlendSpace2D *self, const godot_Vector2 *snap) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_snap, 743155724, void, self, snap)
}
godot_Vector2 godot_AnimationNodeBlendSpace2D_get_snap(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_snap, 3341600327, godot_Vector2, self)
}
void godot_AnimationNodeBlendSpace2D_set_x_label(godot_AnimationNodeBlendSpace2D *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_x_label, 83702148, void, self, text)
}
godot_String godot_AnimationNodeBlendSpace2D_get_x_label(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_x_label, 201670096, godot_String, self)
}
void godot_AnimationNodeBlendSpace2D_set_y_label(godot_AnimationNodeBlendSpace2D *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_y_label, 83702148, void, self, text)
}
godot_String godot_AnimationNodeBlendSpace2D_get_y_label(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_y_label, 201670096, godot_String, self)
}
void godot_AnimationNodeBlendSpace2D_set_auto_triangles(godot_AnimationNodeBlendSpace2D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_auto_triangles, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeBlendSpace2D_get_auto_triangles(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_auto_triangles, 36873697, godot_bool, self)
}
void godot_AnimationNodeBlendSpace2D_set_blend_mode(godot_AnimationNodeBlendSpace2D *self, godot_AnimationNodeBlendSpace2D_BlendMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_blend_mode, 81193520, void, self, &mode)
}
godot_AnimationNodeBlendSpace2D_BlendMode godot_AnimationNodeBlendSpace2D_get_blend_mode(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, get_blend_mode, 1398433632, godot_AnimationNodeBlendSpace2D_BlendMode, self)
}
void godot_AnimationNodeBlendSpace2D_set_use_sync(godot_AnimationNodeBlendSpace2D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace2D, set_use_sync, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeBlendSpace2D_is_using_sync(const godot_AnimationNodeBlendSpace2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace2D, is_using_sync, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
