// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_RESAMPLED_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_RESAMPLED_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamPlaybackResampled *godot_new_AudioStreamPlaybackResampled();

// Methods
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPlaybackResampled__mix_resampled(godot_AudioStreamPlaybackResampled *self, godot_AudioFrame* dst_buffer, godot_int frame_count);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlaybackResampled__get_stream_sampling_rate(const godot_AudioStreamPlaybackResampled *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaybackResampled_begin_resample(godot_AudioStreamPlaybackResampled *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_RESAMPLED_H__
