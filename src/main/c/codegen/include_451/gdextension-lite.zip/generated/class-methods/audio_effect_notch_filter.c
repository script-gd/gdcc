// This file was automatically generated
// Do not modify this file
#include "audio_effect_notch_filter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectNotchFilter *godot_new_AudioEffectNotchFilter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectNotchFilter);
}


#ifdef __cplusplus
}
#endif
