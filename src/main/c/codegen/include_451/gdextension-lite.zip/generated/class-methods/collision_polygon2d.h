// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_POLYGON2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_POLYGON2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CollisionPolygon2D *godot_new_CollisionPolygon2D();

// Methods
GDEXTENSION_LITE_DECL void godot_CollisionPolygon2D_set_polygon(godot_CollisionPolygon2D *self, const godot_PackedVector2Array *polygon);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_CollisionPolygon2D_get_polygon(const godot_CollisionPolygon2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon2D_set_build_mode(godot_CollisionPolygon2D *self, godot_CollisionPolygon2D_BuildMode build_mode);
GDEXTENSION_LITE_DECL godot_CollisionPolygon2D_BuildMode godot_CollisionPolygon2D_get_build_mode(const godot_CollisionPolygon2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon2D_set_disabled(godot_CollisionPolygon2D *self, godot_bool disabled);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionPolygon2D_is_disabled(const godot_CollisionPolygon2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon2D_set_one_way_collision(godot_CollisionPolygon2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionPolygon2D_is_one_way_collision_enabled(const godot_CollisionPolygon2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon2D_set_one_way_collision_margin(godot_CollisionPolygon2D *self, godot_float margin);
GDEXTENSION_LITE_DECL godot_float godot_CollisionPolygon2D_get_one_way_collision_margin(const godot_CollisionPolygon2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_POLYGON2D_H__
