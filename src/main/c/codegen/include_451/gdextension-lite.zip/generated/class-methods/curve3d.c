// This file was automatically generated
// Do not modify this file
#include "curve3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Curve3D *godot_new_Curve3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Curve3D);
}

// Methods
godot_int godot_Curve3D_get_point_count(const godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_point_count, 3905245786, godot_int, self)
}
void godot_Curve3D_set_point_count(godot_Curve3D *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, set_point_count, 1286410249, void, self, &count)
}
void godot_Curve3D_add_point(godot_Curve3D *self, const godot_Vector3 *position, const godot_Vector3 *in, const godot_Vector3 *out, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, add_point, 2931053748, void, self, position, in, out, &index)
}
void godot_Curve3D_set_point_position(godot_Curve3D *self, godot_int idx, const godot_Vector3 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, set_point_position, 1530502735, void, self, &idx, position)
}
godot_Vector3 godot_Curve3D_get_point_position(const godot_Curve3D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_point_position, 711720468, godot_Vector3, self, &idx)
}
void godot_Curve3D_set_point_tilt(godot_Curve3D *self, godot_int idx, godot_float tilt) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, set_point_tilt, 1602489585, void, self, &idx, &tilt)
}
godot_float godot_Curve3D_get_point_tilt(const godot_Curve3D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_point_tilt, 2339986948, godot_float, self, &idx)
}
void godot_Curve3D_set_point_in(godot_Curve3D *self, godot_int idx, const godot_Vector3 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, set_point_in, 1530502735, void, self, &idx, position)
}
godot_Vector3 godot_Curve3D_get_point_in(const godot_Curve3D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_point_in, 711720468, godot_Vector3, self, &idx)
}
void godot_Curve3D_set_point_out(godot_Curve3D *self, godot_int idx, const godot_Vector3 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, set_point_out, 1530502735, void, self, &idx, position)
}
godot_Vector3 godot_Curve3D_get_point_out(const godot_Curve3D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_point_out, 711720468, godot_Vector3, self, &idx)
}
void godot_Curve3D_remove_point(godot_Curve3D *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, remove_point, 1286410249, void, self, &idx)
}
void godot_Curve3D_clear_points(godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, clear_points, 3218959716, void, self)
}
godot_Vector3 godot_Curve3D_sample(const godot_Curve3D *self, godot_int idx, godot_float t) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, sample, 3285246857, godot_Vector3, self, &idx, &t)
}
godot_Vector3 godot_Curve3D_samplef(const godot_Curve3D *self, godot_float fofs) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, samplef, 2553580215, godot_Vector3, self, &fofs)
}
void godot_Curve3D_set_closed(godot_Curve3D *self, godot_bool closed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, set_closed, 2586408642, void, self, &closed)
}
godot_bool godot_Curve3D_is_closed(const godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, is_closed, 36873697, godot_bool, self)
}
void godot_Curve3D_set_bake_interval(godot_Curve3D *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, set_bake_interval, 373806689, void, self, &distance)
}
godot_float godot_Curve3D_get_bake_interval(const godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_bake_interval, 1740695150, godot_float, self)
}
void godot_Curve3D_set_up_vector_enabled(godot_Curve3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Curve3D, set_up_vector_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_Curve3D_is_up_vector_enabled(const godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, is_up_vector_enabled, 36873697, godot_bool, self)
}
godot_float godot_Curve3D_get_baked_length(const godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_baked_length, 1740695150, godot_float, self)
}
godot_Vector3 godot_Curve3D_sample_baked(const godot_Curve3D *self, godot_float offset, godot_bool cubic) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, sample_baked, 1350085894, godot_Vector3, self, &offset, &cubic)
}
godot_Transform3D godot_Curve3D_sample_baked_with_rotation(const godot_Curve3D *self, godot_float offset, godot_bool cubic, godot_bool apply_tilt) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, sample_baked_with_rotation, 1939359131, godot_Transform3D, self, &offset, &cubic, &apply_tilt)
}
godot_Vector3 godot_Curve3D_sample_baked_up_vector(const godot_Curve3D *self, godot_float offset, godot_bool apply_tilt) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, sample_baked_up_vector, 1362627031, godot_Vector3, self, &offset, &apply_tilt)
}
godot_PackedVector3Array godot_Curve3D_get_baked_points(const godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_baked_points, 497664490, godot_PackedVector3Array, self)
}
godot_PackedFloat32Array godot_Curve3D_get_baked_tilts(const godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_baked_tilts, 675695659, godot_PackedFloat32Array, self)
}
godot_PackedVector3Array godot_Curve3D_get_baked_up_vectors(const godot_Curve3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_baked_up_vectors, 497664490, godot_PackedVector3Array, self)
}
godot_Vector3 godot_Curve3D_get_closest_point(const godot_Curve3D *self, const godot_Vector3 *to_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_closest_point, 192990374, godot_Vector3, self, to_point)
}
godot_float godot_Curve3D_get_closest_offset(const godot_Curve3D *self, const godot_Vector3 *to_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, get_closest_offset, 1109078154, godot_float, self, to_point)
}
godot_PackedVector3Array godot_Curve3D_tessellate(const godot_Curve3D *self, godot_int max_stages, godot_float tolerance_degrees) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, tessellate, 1519759391, godot_PackedVector3Array, self, &max_stages, &tolerance_degrees)
}
godot_PackedVector3Array godot_Curve3D_tessellate_even_length(const godot_Curve3D *self, godot_int max_stages, godot_float tolerance_length) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Curve3D, tessellate_even_length, 133237049, godot_PackedVector3Array, self, &max_stages, &tolerance_length)
}


#ifdef __cplusplus
}
#endif
