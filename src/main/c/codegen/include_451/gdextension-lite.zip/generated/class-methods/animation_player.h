// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_PLAYER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_PLAYER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationPlayer *godot_new_AnimationPlayer();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_animation_set_next(godot_AnimationPlayer *self, const godot_StringName *animation_from, const godot_StringName *animation_to);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimationPlayer_animation_get_next(const godot_AnimationPlayer *self, const godot_StringName *animation_from);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_blend_time(godot_AnimationPlayer *self, const godot_StringName *animation_from, const godot_StringName *animation_to, godot_float sec);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_blend_time(const godot_AnimationPlayer *self, const godot_StringName *animation_from, const godot_StringName *animation_to);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_default_blend_time(godot_AnimationPlayer *self, godot_float sec);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_default_blend_time(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_auto_capture(godot_AnimationPlayer *self, godot_bool auto_capture);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationPlayer_is_auto_capture(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_auto_capture_duration(godot_AnimationPlayer *self, godot_float auto_capture_duration);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_auto_capture_duration(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_auto_capture_transition_type(godot_AnimationPlayer *self, godot_Tween_TransitionType auto_capture_transition_type);
GDEXTENSION_LITE_DECL godot_Tween_TransitionType godot_AnimationPlayer_get_auto_capture_transition_type(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_auto_capture_ease_type(godot_AnimationPlayer *self, godot_Tween_EaseType auto_capture_ease_type);
GDEXTENSION_LITE_DECL godot_Tween_EaseType godot_AnimationPlayer_get_auto_capture_ease_type(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_play(godot_AnimationPlayer *self, const godot_StringName *name, godot_float custom_blend, godot_float custom_speed, godot_bool from_end);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_play_section_with_markers(godot_AnimationPlayer *self, const godot_StringName *name, const godot_StringName *start_marker, const godot_StringName *end_marker, godot_float custom_blend, godot_float custom_speed, godot_bool from_end);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_play_section(godot_AnimationPlayer *self, const godot_StringName *name, godot_float start_time, godot_float end_time, godot_float custom_blend, godot_float custom_speed, godot_bool from_end);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_play_backwards(godot_AnimationPlayer *self, const godot_StringName *name, godot_float custom_blend);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_play_section_with_markers_backwards(godot_AnimationPlayer *self, const godot_StringName *name, const godot_StringName *start_marker, const godot_StringName *end_marker, godot_float custom_blend);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_play_section_backwards(godot_AnimationPlayer *self, const godot_StringName *name, godot_float start_time, godot_float end_time, godot_float custom_blend);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_play_with_capture(godot_AnimationPlayer *self, const godot_StringName *name, godot_float duration, godot_float custom_blend, godot_float custom_speed, godot_bool from_end, godot_Tween_TransitionType trans_type, godot_Tween_EaseType ease_type);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_pause(godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_stop(godot_AnimationPlayer *self, godot_bool keep_state);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationPlayer_is_playing(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_current_animation(godot_AnimationPlayer *self, const godot_String *animation);
GDEXTENSION_LITE_DECL godot_String godot_AnimationPlayer_get_current_animation(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_assigned_animation(godot_AnimationPlayer *self, const godot_String *animation);
GDEXTENSION_LITE_DECL godot_String godot_AnimationPlayer_get_assigned_animation(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_queue(godot_AnimationPlayer *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_AnimationPlayer_get_queue(godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_clear_queue(godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_speed_scale(godot_AnimationPlayer *self, godot_float speed);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_speed_scale(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_playing_speed(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_autoplay(godot_AnimationPlayer *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_String godot_AnimationPlayer_get_autoplay(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_movie_quit_on_finish_enabled(godot_AnimationPlayer *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationPlayer_is_movie_quit_on_finish_enabled(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_current_animation_position(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_current_animation_length(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_section_with_markers(godot_AnimationPlayer *self, const godot_StringName *start_marker, const godot_StringName *end_marker);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_section(godot_AnimationPlayer *self, godot_float start_time, godot_float end_time);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_reset_section(godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_section_start_time(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimationPlayer_get_section_end_time(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationPlayer_has_section(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_seek(godot_AnimationPlayer *self, godot_float seconds, godot_bool update, godot_bool update_only);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_process_callback(godot_AnimationPlayer *self, godot_AnimationPlayer_AnimationProcessCallback mode);
GDEXTENSION_LITE_DECL godot_AnimationPlayer_AnimationProcessCallback godot_AnimationPlayer_get_process_callback(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_method_call_mode(godot_AnimationPlayer *self, godot_AnimationPlayer_AnimationMethodCallMode mode);
GDEXTENSION_LITE_DECL godot_AnimationPlayer_AnimationMethodCallMode godot_AnimationPlayer_get_method_call_mode(const godot_AnimationPlayer *self);
GDEXTENSION_LITE_DECL void godot_AnimationPlayer_set_root(godot_AnimationPlayer *self, const godot_NodePath *path);
GDEXTENSION_LITE_DECL godot_NodePath godot_AnimationPlayer_get_root(const godot_AnimationPlayer *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_PLAYER_H__
