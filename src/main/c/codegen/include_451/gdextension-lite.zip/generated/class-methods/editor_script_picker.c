// This file was automatically generated
// Do not modify this file
#include "editor_script_picker.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorScriptPicker *godot_new_EditorScriptPicker() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorScriptPicker);
}

// Methods
void godot_EditorScriptPicker_set_script_owner(godot_EditorScriptPicker *self, const godot_Node *owner_node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScriptPicker, set_script_owner, 1078189570, void, self, owner_node)
}
godot_Node * godot_EditorScriptPicker_get_script_owner(const godot_EditorScriptPicker *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScriptPicker, get_script_owner, 3160264692, godot_Node *, self)
}


#ifdef __cplusplus
}
#endif
