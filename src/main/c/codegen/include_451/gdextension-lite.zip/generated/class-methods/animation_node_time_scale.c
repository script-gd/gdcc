// This file was automatically generated
// Do not modify this file
#include "animation_node_time_scale.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeTimeScale *godot_new_AnimationNodeTimeScale() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeTimeScale);
}


#ifdef __cplusplus
}
#endif
