// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DECAL_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DECAL_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Decal *godot_new_Decal();

// Methods
GDEXTENSION_LITE_DECL void godot_Decal_set_size(godot_Decal *self, const godot_Vector3 *size);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Decal_get_size(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_texture(godot_Decal *self, godot_Decal_DecalTexture type, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_Decal_get_texture(const godot_Decal *self, godot_Decal_DecalTexture type);
GDEXTENSION_LITE_DECL void godot_Decal_set_emission_energy(godot_Decal *self, godot_float energy);
GDEXTENSION_LITE_DECL godot_float godot_Decal_get_emission_energy(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_albedo_mix(godot_Decal *self, godot_float energy);
GDEXTENSION_LITE_DECL godot_float godot_Decal_get_albedo_mix(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_modulate(godot_Decal *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_Decal_get_modulate(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_upper_fade(godot_Decal *self, godot_float fade);
GDEXTENSION_LITE_DECL godot_float godot_Decal_get_upper_fade(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_lower_fade(godot_Decal *self, godot_float fade);
GDEXTENSION_LITE_DECL godot_float godot_Decal_get_lower_fade(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_normal_fade(godot_Decal *self, godot_float fade);
GDEXTENSION_LITE_DECL godot_float godot_Decal_get_normal_fade(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_enable_distance_fade(godot_Decal *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Decal_is_distance_fade_enabled(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_distance_fade_begin(godot_Decal *self, godot_float distance);
GDEXTENSION_LITE_DECL godot_float godot_Decal_get_distance_fade_begin(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_distance_fade_length(godot_Decal *self, godot_float distance);
GDEXTENSION_LITE_DECL godot_float godot_Decal_get_distance_fade_length(const godot_Decal *self);
GDEXTENSION_LITE_DECL void godot_Decal_set_cull_mask(godot_Decal *self, godot_int mask);
GDEXTENSION_LITE_DECL godot_int godot_Decal_get_cull_mask(const godot_Decal *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DECAL_H__
