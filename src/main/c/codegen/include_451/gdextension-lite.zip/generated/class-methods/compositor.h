// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPOSITOR_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPOSITOR_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Compositor *godot_new_Compositor();

// Methods
GDEXTENSION_LITE_DECL void godot_Compositor_set_compositor_effects(godot_Compositor *self, const godot_TypedArray(godot_CompositorEffect) *compositor_effects);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_CompositorEffect) godot_Compositor_get_compositor_effects(const godot_Compositor *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPOSITOR_H__
