// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_ATTACHMENT3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_ATTACHMENT3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BoneAttachment3D *godot_new_BoneAttachment3D();

// Methods
GDEXTENSION_LITE_DECL godot_Skeleton3D * godot_BoneAttachment3D_get_skeleton(godot_BoneAttachment3D *self);
GDEXTENSION_LITE_DECL void godot_BoneAttachment3D_set_bone_name(godot_BoneAttachment3D *self, const godot_String *bone_name);
GDEXTENSION_LITE_DECL godot_String godot_BoneAttachment3D_get_bone_name(const godot_BoneAttachment3D *self);
GDEXTENSION_LITE_DECL void godot_BoneAttachment3D_set_bone_idx(godot_BoneAttachment3D *self, godot_int bone_idx);
GDEXTENSION_LITE_DECL godot_int godot_BoneAttachment3D_get_bone_idx(const godot_BoneAttachment3D *self);
GDEXTENSION_LITE_DECL void godot_BoneAttachment3D_on_skeleton_update(godot_BoneAttachment3D *self);
GDEXTENSION_LITE_DECL void godot_BoneAttachment3D_set_override_pose(godot_BoneAttachment3D *self, godot_bool override_pose);
GDEXTENSION_LITE_DECL godot_bool godot_BoneAttachment3D_get_override_pose(const godot_BoneAttachment3D *self);
GDEXTENSION_LITE_DECL void godot_BoneAttachment3D_set_use_external_skeleton(godot_BoneAttachment3D *self, godot_bool use_external_skeleton);
GDEXTENSION_LITE_DECL godot_bool godot_BoneAttachment3D_get_use_external_skeleton(const godot_BoneAttachment3D *self);
GDEXTENSION_LITE_DECL void godot_BoneAttachment3D_set_external_skeleton(godot_BoneAttachment3D *self, const godot_NodePath *external_skeleton);
GDEXTENSION_LITE_DECL godot_NodePath godot_BoneAttachment3D_get_external_skeleton(const godot_BoneAttachment3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_ATTACHMENT3D_H__
