// This file was automatically generated
// Do not modify this file
#include "check_button.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CheckButton *godot_new_CheckButton() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CheckButton);
}


#ifdef __cplusplus
}
#endif
