// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PROPERTY_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PROPERTY_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorProperty *godot_new_EditorProperty();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorProperty__update_property(godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty__set_read_only(godot_EditorProperty *self, godot_bool read_only);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_label(godot_EditorProperty *self, const godot_String *text);
GDEXTENSION_LITE_DECL godot_String godot_EditorProperty_get_label(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_read_only(godot_EditorProperty *self, godot_bool read_only);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_read_only(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_draw_label(godot_EditorProperty *self, godot_bool draw_label);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_draw_label(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_draw_background(godot_EditorProperty *self, godot_bool draw_background);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_draw_background(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_checkable(godot_EditorProperty *self, godot_bool checkable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_checkable(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_checked(godot_EditorProperty *self, godot_bool checked);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_checked(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_draw_warning(godot_EditorProperty *self, godot_bool draw_warning);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_draw_warning(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_keying(godot_EditorProperty *self, godot_bool keying);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_keying(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_deletable(godot_EditorProperty *self, godot_bool deletable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_deletable(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL godot_StringName godot_EditorProperty_get_edited_property(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL godot_Object * godot_EditorProperty_get_edited_object(godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_update_property(godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_add_focusable(godot_EditorProperty *self, const godot_Control *control);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_bottom_editor(godot_EditorProperty *self, const godot_Control *editor);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_selectable(godot_EditorProperty *self, godot_bool selectable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_selectable(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_use_folding(godot_EditorProperty *self, godot_bool use_folding);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_using_folding(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_name_split_ratio(godot_EditorProperty *self, godot_float ratio);
GDEXTENSION_LITE_DECL godot_float godot_EditorProperty_get_name_split_ratio(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_deselect(godot_EditorProperty *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorProperty_is_selected(const godot_EditorProperty *self);
GDEXTENSION_LITE_DECL void godot_EditorProperty_select(godot_EditorProperty *self, godot_int focusable);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_object_and_property(godot_EditorProperty *self, const godot_Object *object, const godot_StringName *property);
GDEXTENSION_LITE_DECL void godot_EditorProperty_set_label_reference(godot_EditorProperty *self, const godot_Control *control);
GDEXTENSION_LITE_DECL void godot_EditorProperty_emit_changed(godot_EditorProperty *self, const godot_StringName *property, const godot_Variant *value, const godot_StringName *field, godot_bool changing);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_PROPERTY_H__
