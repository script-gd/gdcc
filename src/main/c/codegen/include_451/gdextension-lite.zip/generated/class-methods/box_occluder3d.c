// This file was automatically generated
// Do not modify this file
#include "box_occluder3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BoxOccluder3D *godot_new_BoxOccluder3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BoxOccluder3D);
}

// Methods
void godot_BoxOccluder3D_set_size(godot_BoxOccluder3D *self, const godot_Vector3 *size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoxOccluder3D, set_size, 3460891852, void, self, size)
}
godot_Vector3 godot_BoxOccluder3D_get_size(const godot_BoxOccluder3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoxOccluder3D, get_size, 3360562783, godot_Vector3, self)
}


#ifdef __cplusplus
}
#endif
