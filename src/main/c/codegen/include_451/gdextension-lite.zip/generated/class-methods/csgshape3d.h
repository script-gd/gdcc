// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGSHAPE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGSHAPE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_CSGShape3D_is_root_shape(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_operation(godot_CSGShape3D *self, godot_CSGShape3D_Operation operation);
GDEXTENSION_LITE_DECL godot_CSGShape3D_Operation godot_CSGShape3D_get_operation(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_snap(godot_CSGShape3D *self, godot_float snap);
GDEXTENSION_LITE_DECL godot_float godot_CSGShape3D_get_snap(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_use_collision(godot_CSGShape3D *self, godot_bool operation);
GDEXTENSION_LITE_DECL godot_bool godot_CSGShape3D_is_using_collision(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_collision_layer(godot_CSGShape3D *self, godot_int layer);
GDEXTENSION_LITE_DECL godot_int godot_CSGShape3D_get_collision_layer(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_collision_mask(godot_CSGShape3D *self, godot_int mask);
GDEXTENSION_LITE_DECL godot_int godot_CSGShape3D_get_collision_mask(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_collision_mask_value(godot_CSGShape3D *self, godot_int layer_number, godot_bool value);
GDEXTENSION_LITE_DECL godot_bool godot_CSGShape3D_get_collision_mask_value(const godot_CSGShape3D *self, godot_int layer_number);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_collision_layer_value(godot_CSGShape3D *self, godot_int layer_number, godot_bool value);
GDEXTENSION_LITE_DECL godot_bool godot_CSGShape3D_get_collision_layer_value(const godot_CSGShape3D *self, godot_int layer_number);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_collision_priority(godot_CSGShape3D *self, godot_float priority);
GDEXTENSION_LITE_DECL godot_float godot_CSGShape3D_get_collision_priority(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL godot_ConcavePolygonShape3D * godot_CSGShape3D_bake_collision_shape(godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL void godot_CSGShape3D_set_calculate_tangents(godot_CSGShape3D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CSGShape3D_is_calculating_tangents(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL godot_Array godot_CSGShape3D_get_meshes(const godot_CSGShape3D *self);
GDEXTENSION_LITE_DECL godot_ArrayMesh * godot_CSGShape3D_bake_static_mesh(godot_CSGShape3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGSHAPE3D_H__
