// This file was automatically generated
// Do not modify this file
#include "confirmation_dialog.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ConfirmationDialog *godot_new_ConfirmationDialog() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ConfirmationDialog);
}

// Methods
godot_Button * godot_ConfirmationDialog_get_cancel_button(godot_ConfirmationDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfirmationDialog, get_cancel_button, 1856205918, godot_Button *, self)
}
void godot_ConfirmationDialog_set_cancel_button_text(godot_ConfirmationDialog *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConfirmationDialog, set_cancel_button_text, 83702148, void, self, text)
}
godot_String godot_ConfirmationDialog_get_cancel_button_text(const godot_ConfirmationDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfirmationDialog, get_cancel_button_text, 201670096, godot_String, self)
}


#ifdef __cplusplus
}
#endif
