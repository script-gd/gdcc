// This file was automatically generated
// Do not modify this file
#include "copy_transform_modifier3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CopyTransformModifier3D *godot_new_CopyTransformModifier3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CopyTransformModifier3D);
}

// Methods
void godot_CopyTransformModifier3D_set_copy_flags(godot_CopyTransformModifier3D *self, godot_int index, const godot_CopyTransformModifier3D_TransformFlag *copy_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_copy_flags, 2252507859, void, self, &index, copy_flags)
}
godot_CopyTransformModifier3D_TransformFlag godot_CopyTransformModifier3D_get_copy_flags(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, get_copy_flags, 1685185931, godot_CopyTransformModifier3D_TransformFlag, self, &index)
}
void godot_CopyTransformModifier3D_set_axis_flags(godot_CopyTransformModifier3D *self, godot_int index, const godot_CopyTransformModifier3D_AxisFlag *axis_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_axis_flags, 2044211897, void, self, &index, axis_flags)
}
godot_CopyTransformModifier3D_AxisFlag godot_CopyTransformModifier3D_get_axis_flags(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, get_axis_flags, 992162046, godot_CopyTransformModifier3D_AxisFlag, self, &index)
}
void godot_CopyTransformModifier3D_set_invert_flags(godot_CopyTransformModifier3D *self, godot_int index, const godot_CopyTransformModifier3D_AxisFlag *axis_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_invert_flags, 2044211897, void, self, &index, axis_flags)
}
godot_CopyTransformModifier3D_AxisFlag godot_CopyTransformModifier3D_get_invert_flags(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, get_invert_flags, 992162046, godot_CopyTransformModifier3D_AxisFlag, self, &index)
}
void godot_CopyTransformModifier3D_set_copy_position(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_copy_position, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_position_copying(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_position_copying, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_copy_rotation(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_copy_rotation, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_rotation_copying(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_rotation_copying, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_copy_scale(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_copy_scale, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_scale_copying(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_scale_copying, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_axis_x_enabled(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_axis_x_enabled, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_axis_x_enabled(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_axis_x_enabled, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_axis_y_enabled(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_axis_y_enabled, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_axis_y_enabled(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_axis_y_enabled, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_axis_z_enabled(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_axis_z_enabled, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_axis_z_enabled(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_axis_z_enabled, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_axis_x_inverted(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_axis_x_inverted, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_axis_x_inverted(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_axis_x_inverted, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_axis_y_inverted(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_axis_y_inverted, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_axis_y_inverted(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_axis_y_inverted, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_axis_z_inverted(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_axis_z_inverted, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_axis_z_inverted(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_axis_z_inverted, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_relative(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_relative, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_relative(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_relative, 1116898809, godot_bool, self, &index)
}
void godot_CopyTransformModifier3D_set_additive(godot_CopyTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CopyTransformModifier3D, set_additive, 300928843, void, self, &index, &enabled)
}
godot_bool godot_CopyTransformModifier3D_is_additive(const godot_CopyTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CopyTransformModifier3D, is_additive, 1116898809, godot_bool, self, &index)
}


#ifdef __cplusplus
}
#endif
