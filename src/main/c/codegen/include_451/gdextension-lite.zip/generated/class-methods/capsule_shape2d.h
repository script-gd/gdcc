// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAPSULE_SHAPE2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAPSULE_SHAPE2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CapsuleShape2D *godot_new_CapsuleShape2D();

// Methods
GDEXTENSION_LITE_DECL void godot_CapsuleShape2D_set_radius(godot_CapsuleShape2D *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CapsuleShape2D_get_radius(const godot_CapsuleShape2D *self);
GDEXTENSION_LITE_DECL void godot_CapsuleShape2D_set_height(godot_CapsuleShape2D *self, godot_float height);
GDEXTENSION_LITE_DECL godot_float godot_CapsuleShape2D_get_height(const godot_CapsuleShape2D *self);
GDEXTENSION_LITE_DECL void godot_CapsuleShape2D_set_mid_height(godot_CapsuleShape2D *self, godot_float mid_height);
GDEXTENSION_LITE_DECL godot_float godot_CapsuleShape2D_get_mid_height(const godot_CapsuleShape2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAPSULE_SHAPE2D_H__
