// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_WAV_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_WAV_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamWAV *godot_new_AudioStreamWAV();

// Methods
GDEXTENSION_LITE_DECL godot_AudioStreamWAV * godot_AudioStreamWAV_load_from_buffer(const godot_PackedByteArray *stream_data, const godot_Dictionary *options);
GDEXTENSION_LITE_DECL godot_AudioStreamWAV * godot_AudioStreamWAV_load_from_file(const godot_String *path, const godot_Dictionary *options);
GDEXTENSION_LITE_DECL void godot_AudioStreamWAV_set_data(godot_AudioStreamWAV *self, const godot_PackedByteArray *data);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_AudioStreamWAV_get_data(const godot_AudioStreamWAV *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamWAV_set_format(godot_AudioStreamWAV *self, godot_AudioStreamWAV_Format format);
GDEXTENSION_LITE_DECL godot_AudioStreamWAV_Format godot_AudioStreamWAV_get_format(const godot_AudioStreamWAV *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamWAV_set_loop_mode(godot_AudioStreamWAV *self, godot_AudioStreamWAV_LoopMode loop_mode);
GDEXTENSION_LITE_DECL godot_AudioStreamWAV_LoopMode godot_AudioStreamWAV_get_loop_mode(const godot_AudioStreamWAV *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamWAV_set_loop_begin(godot_AudioStreamWAV *self, godot_int loop_begin);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamWAV_get_loop_begin(const godot_AudioStreamWAV *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamWAV_set_loop_end(godot_AudioStreamWAV *self, godot_int loop_end);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamWAV_get_loop_end(const godot_AudioStreamWAV *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamWAV_set_mix_rate(godot_AudioStreamWAV *self, godot_int mix_rate);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamWAV_get_mix_rate(const godot_AudioStreamWAV *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamWAV_set_stereo(godot_AudioStreamWAV *self, godot_bool stereo);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamWAV_is_stereo(const godot_AudioStreamWAV *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamWAV_set_tags(godot_AudioStreamWAV *self, const godot_Dictionary *tags);
GDEXTENSION_LITE_DECL godot_Dictionary godot_AudioStreamWAV_get_tags(const godot_AudioStreamWAV *self);
GDEXTENSION_LITE_DECL godot_Error godot_AudioStreamWAV_save_to_wav(godot_AudioStreamWAV *self, const godot_String *path);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_WAV_H__
