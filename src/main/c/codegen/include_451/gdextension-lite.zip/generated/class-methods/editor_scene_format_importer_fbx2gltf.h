// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_FORMAT_IMPORTER_FBX2GLTF_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_FORMAT_IMPORTER_FBX2GLTF_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorSceneFormatImporterFBX2GLTF *godot_new_EditorSceneFormatImporterFBX2GLTF();


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_FORMAT_IMPORTER_FBX2GLTF_H__
