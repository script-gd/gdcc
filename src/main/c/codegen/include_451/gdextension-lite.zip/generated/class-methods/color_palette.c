// This file was automatically generated
// Do not modify this file
#include "color_palette.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ColorPalette *godot_new_ColorPalette() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ColorPalette);
}

// Methods
void godot_ColorPalette_set_colors(godot_ColorPalette *self, const godot_PackedColorArray *colors) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPalette, set_colors, 3546319833, void, self, colors)
}
godot_PackedColorArray godot_ColorPalette_get_colors(const godot_ColorPalette *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPalette, get_colors, 1392750486, godot_PackedColorArray, self)
}


#ifdef __cplusplus
}
#endif
