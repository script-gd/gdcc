// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_TEXTURE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_TEXTURE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CanvasTexture *godot_new_CanvasTexture();

// Methods
GDEXTENSION_LITE_DECL void godot_CanvasTexture_set_diffuse_texture(godot_CanvasTexture *self, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_CanvasTexture_get_diffuse_texture(const godot_CanvasTexture *self);
GDEXTENSION_LITE_DECL void godot_CanvasTexture_set_normal_texture(godot_CanvasTexture *self, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_CanvasTexture_get_normal_texture(const godot_CanvasTexture *self);
GDEXTENSION_LITE_DECL void godot_CanvasTexture_set_specular_texture(godot_CanvasTexture *self, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_CanvasTexture_get_specular_texture(const godot_CanvasTexture *self);
GDEXTENSION_LITE_DECL void godot_CanvasTexture_set_specular_color(godot_CanvasTexture *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CanvasTexture_get_specular_color(const godot_CanvasTexture *self);
GDEXTENSION_LITE_DECL void godot_CanvasTexture_set_specular_shininess(godot_CanvasTexture *self, godot_float shininess);
GDEXTENSION_LITE_DECL godot_float godot_CanvasTexture_get_specular_shininess(const godot_CanvasTexture *self);
GDEXTENSION_LITE_DECL void godot_CanvasTexture_set_texture_filter(godot_CanvasTexture *self, godot_CanvasItem_TextureFilter filter);
GDEXTENSION_LITE_DECL godot_CanvasItem_TextureFilter godot_CanvasTexture_get_texture_filter(const godot_CanvasTexture *self);
GDEXTENSION_LITE_DECL void godot_CanvasTexture_set_texture_repeat(godot_CanvasTexture *self, godot_CanvasItem_TextureRepeat repeat);
GDEXTENSION_LITE_DECL godot_CanvasItem_TextureRepeat godot_CanvasTexture_get_texture_repeat(const godot_CanvasTexture *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_TEXTURE_H__
