// This file was automatically generated
// Do not modify this file
#include "editor_export_platform_windows.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlatformWindows *godot_new_EditorExportPlatformWindows() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlatformWindows);
}


#ifdef __cplusplus
}
#endif
