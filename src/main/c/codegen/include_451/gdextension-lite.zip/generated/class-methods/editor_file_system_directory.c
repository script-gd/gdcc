// This file was automatically generated
// Do not modify this file
#include "editor_file_system_directory.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorFileSystemDirectory *godot_new_EditorFileSystemDirectory() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorFileSystemDirectory);
}

// Methods
godot_int godot_EditorFileSystemDirectory_get_subdir_count(const godot_EditorFileSystemDirectory *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_subdir_count, 3905245786, godot_int, self)
}
godot_EditorFileSystemDirectory * godot_EditorFileSystemDirectory_get_subdir(godot_EditorFileSystemDirectory *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_subdir, 2330964164, godot_EditorFileSystemDirectory *, self, &idx)
}
godot_int godot_EditorFileSystemDirectory_get_file_count(const godot_EditorFileSystemDirectory *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_file_count, 3905245786, godot_int, self)
}
godot_String godot_EditorFileSystemDirectory_get_file(const godot_EditorFileSystemDirectory *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_file, 844755477, godot_String, self, &idx)
}
godot_String godot_EditorFileSystemDirectory_get_file_path(const godot_EditorFileSystemDirectory *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_file_path, 844755477, godot_String, self, &idx)
}
godot_StringName godot_EditorFileSystemDirectory_get_file_type(const godot_EditorFileSystemDirectory *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_file_type, 659327637, godot_StringName, self, &idx)
}
godot_String godot_EditorFileSystemDirectory_get_file_script_class_name(const godot_EditorFileSystemDirectory *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_file_script_class_name, 844755477, godot_String, self, &idx)
}
godot_String godot_EditorFileSystemDirectory_get_file_script_class_extends(const godot_EditorFileSystemDirectory *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_file_script_class_extends, 844755477, godot_String, self, &idx)
}
godot_bool godot_EditorFileSystemDirectory_get_file_import_is_valid(const godot_EditorFileSystemDirectory *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_file_import_is_valid, 1116898809, godot_bool, self, &idx)
}
godot_String godot_EditorFileSystemDirectory_get_name(godot_EditorFileSystemDirectory *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_name, 2841200299, godot_String, self)
}
godot_String godot_EditorFileSystemDirectory_get_path(const godot_EditorFileSystemDirectory *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_path, 201670096, godot_String, self)
}
godot_EditorFileSystemDirectory * godot_EditorFileSystemDirectory_get_parent(godot_EditorFileSystemDirectory *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, get_parent, 842323275, godot_EditorFileSystemDirectory *, self)
}
godot_int godot_EditorFileSystemDirectory_find_file_index(const godot_EditorFileSystemDirectory *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, find_file_index, 1321353865, godot_int, self, name)
}
godot_int godot_EditorFileSystemDirectory_find_dir_index(const godot_EditorFileSystemDirectory *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemDirectory, find_dir_index, 1321353865, godot_int, self, name)
}


#ifdef __cplusplus
}
#endif
