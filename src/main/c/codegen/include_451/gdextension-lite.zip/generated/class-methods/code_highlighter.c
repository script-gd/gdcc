// This file was automatically generated
// Do not modify this file
#include "code_highlighter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CodeHighlighter *godot_new_CodeHighlighter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CodeHighlighter);
}

// Methods
void godot_CodeHighlighter_add_keyword_color(godot_CodeHighlighter *self, const godot_String *keyword, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, add_keyword_color, 1636512886, void, self, keyword, color)
}
void godot_CodeHighlighter_remove_keyword_color(godot_CodeHighlighter *self, const godot_String *keyword) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, remove_keyword_color, 83702148, void, self, keyword)
}
godot_bool godot_CodeHighlighter_has_keyword_color(const godot_CodeHighlighter *self, const godot_String *keyword) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, has_keyword_color, 3927539163, godot_bool, self, keyword)
}
godot_Color godot_CodeHighlighter_get_keyword_color(const godot_CodeHighlighter *self, const godot_String *keyword) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_keyword_color, 3855908743, godot_Color, self, keyword)
}
void godot_CodeHighlighter_set_keyword_colors(godot_CodeHighlighter *self, const godot_Dictionary *keywords) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, set_keyword_colors, 4155329257, void, self, keywords)
}
void godot_CodeHighlighter_clear_keyword_colors(godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, clear_keyword_colors, 3218959716, void, self)
}
godot_Dictionary godot_CodeHighlighter_get_keyword_colors(const godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_keyword_colors, 3102165223, godot_Dictionary, self)
}
void godot_CodeHighlighter_add_member_keyword_color(godot_CodeHighlighter *self, const godot_String *member_keyword, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, add_member_keyword_color, 1636512886, void, self, member_keyword, color)
}
void godot_CodeHighlighter_remove_member_keyword_color(godot_CodeHighlighter *self, const godot_String *member_keyword) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, remove_member_keyword_color, 83702148, void, self, member_keyword)
}
godot_bool godot_CodeHighlighter_has_member_keyword_color(const godot_CodeHighlighter *self, const godot_String *member_keyword) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, has_member_keyword_color, 3927539163, godot_bool, self, member_keyword)
}
godot_Color godot_CodeHighlighter_get_member_keyword_color(const godot_CodeHighlighter *self, const godot_String *member_keyword) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_member_keyword_color, 3855908743, godot_Color, self, member_keyword)
}
void godot_CodeHighlighter_set_member_keyword_colors(godot_CodeHighlighter *self, const godot_Dictionary *member_keyword) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, set_member_keyword_colors, 4155329257, void, self, member_keyword)
}
void godot_CodeHighlighter_clear_member_keyword_colors(godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, clear_member_keyword_colors, 3218959716, void, self)
}
godot_Dictionary godot_CodeHighlighter_get_member_keyword_colors(const godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_member_keyword_colors, 3102165223, godot_Dictionary, self)
}
void godot_CodeHighlighter_add_color_region(godot_CodeHighlighter *self, const godot_String *start_key, const godot_String *end_key, const godot_Color *color, godot_bool line_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, add_color_region, 2924977451, void, self, start_key, end_key, color, &line_only)
}
void godot_CodeHighlighter_remove_color_region(godot_CodeHighlighter *self, const godot_String *start_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, remove_color_region, 83702148, void, self, start_key)
}
godot_bool godot_CodeHighlighter_has_color_region(const godot_CodeHighlighter *self, const godot_String *start_key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, has_color_region, 3927539163, godot_bool, self, start_key)
}
void godot_CodeHighlighter_set_color_regions(godot_CodeHighlighter *self, const godot_Dictionary *color_regions) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, set_color_regions, 4155329257, void, self, color_regions)
}
void godot_CodeHighlighter_clear_color_regions(godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, clear_color_regions, 3218959716, void, self)
}
godot_Dictionary godot_CodeHighlighter_get_color_regions(const godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_color_regions, 3102165223, godot_Dictionary, self)
}
void godot_CodeHighlighter_set_function_color(godot_CodeHighlighter *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, set_function_color, 2920490490, void, self, color)
}
godot_Color godot_CodeHighlighter_get_function_color(const godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_function_color, 3444240500, godot_Color, self)
}
void godot_CodeHighlighter_set_number_color(godot_CodeHighlighter *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, set_number_color, 2920490490, void, self, color)
}
godot_Color godot_CodeHighlighter_get_number_color(const godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_number_color, 3444240500, godot_Color, self)
}
void godot_CodeHighlighter_set_symbol_color(godot_CodeHighlighter *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, set_symbol_color, 2920490490, void, self, color)
}
godot_Color godot_CodeHighlighter_get_symbol_color(const godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_symbol_color, 3444240500, godot_Color, self)
}
void godot_CodeHighlighter_set_member_variable_color(godot_CodeHighlighter *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CodeHighlighter, set_member_variable_color, 2920490490, void, self, color)
}
godot_Color godot_CodeHighlighter_get_member_variable_color(const godot_CodeHighlighter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CodeHighlighter, get_member_variable_color, 3444240500, godot_Color, self)
}


#ifdef __cplusplus
}
#endif
