// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONCAVE_POLYGON_SHAPE2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONCAVE_POLYGON_SHAPE2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ConcavePolygonShape2D *godot_new_ConcavePolygonShape2D();

// Methods
GDEXTENSION_LITE_DECL void godot_ConcavePolygonShape2D_set_segments(godot_ConcavePolygonShape2D *self, const godot_PackedVector2Array *segments);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_ConcavePolygonShape2D_get_segments(const godot_ConcavePolygonShape2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONCAVE_POLYGON_SHAPE2D_H__
