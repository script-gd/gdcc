// This file was automatically generated
// Do not modify this file
#include "audio_stream_polyphonic.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamPolyphonic *godot_new_AudioStreamPolyphonic() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamPolyphonic);
}

// Methods
void godot_AudioStreamPolyphonic_set_polyphony(godot_AudioStreamPolyphonic *self, godot_int voices) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPolyphonic, set_polyphony, 1286410249, void, self, &voices)
}
godot_int godot_AudioStreamPolyphonic_get_polyphony(const godot_AudioStreamPolyphonic *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPolyphonic, get_polyphony, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
