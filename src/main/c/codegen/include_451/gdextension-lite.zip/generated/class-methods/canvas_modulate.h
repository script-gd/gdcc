// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_MODULATE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_MODULATE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CanvasModulate *godot_new_CanvasModulate();

// Methods
GDEXTENSION_LITE_DECL void godot_CanvasModulate_set_color(godot_CanvasModulate *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CanvasModulate_get_color(const godot_CanvasModulate *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_MODULATE_H__
