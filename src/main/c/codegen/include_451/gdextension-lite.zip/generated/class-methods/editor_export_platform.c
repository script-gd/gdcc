// This file was automatically generated
// Do not modify this file
#include "editor_export_platform.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_String godot_EditorExportPlatform_get_os_name(const godot_EditorExportPlatform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_os_name, 201670096, godot_String, self)
}
godot_EditorExportPreset * godot_EditorExportPlatform_create_preset(godot_EditorExportPlatform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, create_preset, 2572397818, godot_EditorExportPreset *, self)
}
godot_Dictionary godot_EditorExportPlatform_find_export_template(const godot_EditorExportPlatform *self, const godot_String *template_file_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, find_export_template, 2248993622, godot_Dictionary, self, template_file_name)
}
godot_Array godot_EditorExportPlatform_get_current_presets(const godot_EditorExportPlatform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_current_presets, 3995934104, godot_Array, self)
}
godot_Dictionary godot_EditorExportPlatform_save_pack(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, godot_bool embed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, save_pack, 3420080977, godot_Dictionary, self, preset, &debug, path, &embed)
}
godot_Dictionary godot_EditorExportPlatform_save_zip(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, save_zip, 1485052307, godot_Dictionary, self, preset, &debug, path)
}
godot_Dictionary godot_EditorExportPlatform_save_pack_patch(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, save_pack_patch, 1485052307, godot_Dictionary, self, preset, &debug, path)
}
godot_Dictionary godot_EditorExportPlatform_save_zip_patch(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, save_zip_patch, 1485052307, godot_Dictionary, self, preset, &debug, path)
}
godot_PackedStringArray godot_EditorExportPlatform_gen_export_flags(godot_EditorExportPlatform *self, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, gen_export_flags, 2976483270, godot_PackedStringArray, self, flags)
}
godot_Error godot_EditorExportPlatform_export_project_files(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_Callable *save_cb, const godot_Callable *shared_cb) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, export_project_files, 1063735070, godot_Error, self, preset, &debug, save_cb, shared_cb)
}
godot_Error godot_EditorExportPlatform_export_project(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, export_project, 3879521245, godot_Error, self, preset, &debug, path, flags)
}
godot_Error godot_EditorExportPlatform_export_pack(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, export_pack, 3879521245, godot_Error, self, preset, &debug, path, flags)
}
godot_Error godot_EditorExportPlatform_export_zip(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, export_zip, 3879521245, godot_Error, self, preset, &debug, path, flags)
}
godot_Error godot_EditorExportPlatform_export_pack_patch(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_PackedStringArray *patches, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, export_pack_patch, 608021658, godot_Error, self, preset, &debug, path, patches, flags)
}
godot_Error godot_EditorExportPlatform_export_zip_patch(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug, const godot_String *path, const godot_PackedStringArray *patches, const godot_EditorExportPlatform_DebugFlags *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, export_zip_patch, 608021658, godot_Error, self, preset, &debug, path, patches, flags)
}
void godot_EditorExportPlatform_clear_messages(godot_EditorExportPlatform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlatform, clear_messages, 3218959716, void, self)
}
void godot_EditorExportPlatform_add_message(godot_EditorExportPlatform *self, godot_EditorExportPlatform_ExportMessageType type, const godot_String *category, const godot_String *message) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlatform, add_message, 782767225, void, self, &type, category, message)
}
godot_int godot_EditorExportPlatform_get_message_count(const godot_EditorExportPlatform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_message_count, 3905245786, godot_int, self)
}
godot_EditorExportPlatform_ExportMessageType godot_EditorExportPlatform_get_message_type(const godot_EditorExportPlatform *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_message_type, 2667287293, godot_EditorExportPlatform_ExportMessageType, self, &index)
}
godot_String godot_EditorExportPlatform_get_message_category(const godot_EditorExportPlatform *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_message_category, 844755477, godot_String, self, &index)
}
godot_String godot_EditorExportPlatform_get_message_text(const godot_EditorExportPlatform *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_message_text, 844755477, godot_String, self, &index)
}
godot_EditorExportPlatform_ExportMessageType godot_EditorExportPlatform_get_worst_message_type(const godot_EditorExportPlatform *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_worst_message_type, 2580557466, godot_EditorExportPlatform_ExportMessageType, self)
}
godot_Error godot_EditorExportPlatform_ssh_run_on_remote(const godot_EditorExportPlatform *self, const godot_String *host, const godot_String *port, const godot_PackedStringArray *ssh_arg, const godot_String *cmd_args, const godot_Array *output, godot_int port_fwd) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, ssh_run_on_remote, 3163734797, godot_Error, self, host, port, ssh_arg, cmd_args, output, &port_fwd)
}
godot_int godot_EditorExportPlatform_ssh_run_on_remote_no_wait(const godot_EditorExportPlatform *self, const godot_String *host, const godot_String *port, const godot_PackedStringArray *ssh_args, const godot_String *cmd_args, godot_int port_fwd) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, ssh_run_on_remote_no_wait, 3606362233, godot_int, self, host, port, ssh_args, cmd_args, &port_fwd)
}
godot_Error godot_EditorExportPlatform_ssh_push_to_remote(const godot_EditorExportPlatform *self, const godot_String *host, const godot_String *port, const godot_PackedStringArray *scp_args, const godot_String *src_file, const godot_String *dst_file) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, ssh_push_to_remote, 218756989, godot_Error, self, host, port, scp_args, src_file, dst_file)
}
godot_Dictionary godot_EditorExportPlatform_get_internal_export_files(godot_EditorExportPlatform *self, const godot_EditorExportPreset *preset, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_internal_export_files, 89550086, godot_Dictionary, self, preset, &debug)
}
godot_PackedStringArray godot_EditorExportPlatform_get_forced_export_files(const godot_EditorExportPreset *preset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlatform, get_forced_export_files, 1939331020, godot_PackedStringArray, NULL, preset)
}


#ifdef __cplusplus
}
#endif
