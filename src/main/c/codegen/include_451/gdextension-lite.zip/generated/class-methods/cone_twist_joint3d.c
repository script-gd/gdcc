// This file was automatically generated
// Do not modify this file
#include "cone_twist_joint3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ConeTwistJoint3D *godot_new_ConeTwistJoint3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ConeTwistJoint3D);
}

// Methods
void godot_ConeTwistJoint3D_set_param(godot_ConeTwistJoint3D *self, godot_ConeTwistJoint3D_Param param, godot_float value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConeTwistJoint3D, set_param, 1062470226, void, self, &param, &value)
}
godot_float godot_ConeTwistJoint3D_get_param(const godot_ConeTwistJoint3D *self, godot_ConeTwistJoint3D_Param param) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConeTwistJoint3D, get_param, 2928790850, godot_float, self, &param)
}


#ifdef __cplusplus
}
#endif
