// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PALETTE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PALETTE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ColorPalette *godot_new_ColorPalette();

// Methods
GDEXTENSION_LITE_DECL void godot_ColorPalette_set_colors(godot_ColorPalette *self, const godot_PackedColorArray *colors);
GDEXTENSION_LITE_DECL godot_PackedColorArray godot_ColorPalette_get_colors(const godot_ColorPalette *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PALETTE_H__
