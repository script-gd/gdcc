// This file was automatically generated
// Do not modify this file
#include "box_container.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BoxContainer *godot_new_BoxContainer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BoxContainer);
}

// Methods
godot_Control * godot_BoxContainer_add_spacer(godot_BoxContainer *self, godot_bool begin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoxContainer, add_spacer, 1326660695, godot_Control *, self, &begin)
}
void godot_BoxContainer_set_alignment(godot_BoxContainer *self, godot_BoxContainer_AlignmentMode alignment) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoxContainer, set_alignment, 2456745134, void, self, &alignment)
}
godot_BoxContainer_AlignmentMode godot_BoxContainer_get_alignment(const godot_BoxContainer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoxContainer, get_alignment, 1915476527, godot_BoxContainer_AlignmentMode, self)
}
void godot_BoxContainer_set_vertical(godot_BoxContainer *self, godot_bool vertical) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoxContainer, set_vertical, 2586408642, void, self, &vertical)
}
godot_bool godot_BoxContainer_is_vertical(const godot_BoxContainer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoxContainer, is_vertical, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
