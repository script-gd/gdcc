// This file was automatically generated
// Do not modify this file
#include "base_material3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
void godot_BaseMaterial3D_set_albedo(godot_BaseMaterial3D *self, const godot_Color *albedo) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_albedo, 2920490490, void, self, albedo)
}
godot_Color godot_BaseMaterial3D_get_albedo(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_albedo, 3444240500, godot_Color, self)
}
void godot_BaseMaterial3D_set_transparency(godot_BaseMaterial3D *self, godot_BaseMaterial3D_Transparency transparency) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_transparency, 3435651667, void, self, &transparency)
}
godot_BaseMaterial3D_Transparency godot_BaseMaterial3D_get_transparency(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_transparency, 990903061, godot_BaseMaterial3D_Transparency, self)
}
void godot_BaseMaterial3D_set_alpha_antialiasing(godot_BaseMaterial3D *self, godot_BaseMaterial3D_AlphaAntiAliasing alpha_aa) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_alpha_antialiasing, 3212649852, void, self, &alpha_aa)
}
godot_BaseMaterial3D_AlphaAntiAliasing godot_BaseMaterial3D_get_alpha_antialiasing(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_alpha_antialiasing, 2889939400, godot_BaseMaterial3D_AlphaAntiAliasing, self)
}
void godot_BaseMaterial3D_set_alpha_antialiasing_edge(godot_BaseMaterial3D *self, godot_float edge) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_alpha_antialiasing_edge, 373806689, void, self, &edge)
}
godot_float godot_BaseMaterial3D_get_alpha_antialiasing_edge(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_alpha_antialiasing_edge, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_shading_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_ShadingMode shading_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_shading_mode, 3368750322, void, self, &shading_mode)
}
godot_BaseMaterial3D_ShadingMode godot_BaseMaterial3D_get_shading_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_shading_mode, 2132070559, godot_BaseMaterial3D_ShadingMode, self)
}
void godot_BaseMaterial3D_set_specular(godot_BaseMaterial3D *self, godot_float specular) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_specular, 373806689, void, self, &specular)
}
godot_float godot_BaseMaterial3D_get_specular(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_specular, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_metallic(godot_BaseMaterial3D *self, godot_float metallic) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_metallic, 373806689, void, self, &metallic)
}
godot_float godot_BaseMaterial3D_get_metallic(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_metallic, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_roughness(godot_BaseMaterial3D *self, godot_float roughness) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_roughness, 373806689, void, self, &roughness)
}
godot_float godot_BaseMaterial3D_get_roughness(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_roughness, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_emission(godot_BaseMaterial3D *self, const godot_Color *emission) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_emission, 2920490490, void, self, emission)
}
godot_Color godot_BaseMaterial3D_get_emission(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_emission, 3444240500, godot_Color, self)
}
void godot_BaseMaterial3D_set_emission_energy_multiplier(godot_BaseMaterial3D *self, godot_float emission_energy_multiplier) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_emission_energy_multiplier, 373806689, void, self, &emission_energy_multiplier)
}
godot_float godot_BaseMaterial3D_get_emission_energy_multiplier(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_emission_energy_multiplier, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_emission_intensity(godot_BaseMaterial3D *self, godot_float emission_energy_multiplier) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_emission_intensity, 373806689, void, self, &emission_energy_multiplier)
}
godot_float godot_BaseMaterial3D_get_emission_intensity(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_emission_intensity, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_normal_scale(godot_BaseMaterial3D *self, godot_float normal_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_normal_scale, 373806689, void, self, &normal_scale)
}
godot_float godot_BaseMaterial3D_get_normal_scale(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_normal_scale, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_rim(godot_BaseMaterial3D *self, godot_float rim) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_rim, 373806689, void, self, &rim)
}
godot_float godot_BaseMaterial3D_get_rim(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_rim, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_rim_tint(godot_BaseMaterial3D *self, godot_float rim_tint) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_rim_tint, 373806689, void, self, &rim_tint)
}
godot_float godot_BaseMaterial3D_get_rim_tint(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_rim_tint, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_clearcoat(godot_BaseMaterial3D *self, godot_float clearcoat) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_clearcoat, 373806689, void, self, &clearcoat)
}
godot_float godot_BaseMaterial3D_get_clearcoat(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_clearcoat, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_clearcoat_roughness(godot_BaseMaterial3D *self, godot_float clearcoat_roughness) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_clearcoat_roughness, 373806689, void, self, &clearcoat_roughness)
}
godot_float godot_BaseMaterial3D_get_clearcoat_roughness(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_clearcoat_roughness, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_anisotropy(godot_BaseMaterial3D *self, godot_float anisotropy) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_anisotropy, 373806689, void, self, &anisotropy)
}
godot_float godot_BaseMaterial3D_get_anisotropy(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_anisotropy, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_heightmap_scale(godot_BaseMaterial3D *self, godot_float heightmap_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_heightmap_scale, 373806689, void, self, &heightmap_scale)
}
godot_float godot_BaseMaterial3D_get_heightmap_scale(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_heightmap_scale, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_subsurface_scattering_strength(godot_BaseMaterial3D *self, godot_float strength) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_subsurface_scattering_strength, 373806689, void, self, &strength)
}
godot_float godot_BaseMaterial3D_get_subsurface_scattering_strength(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_subsurface_scattering_strength, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_transmittance_color(godot_BaseMaterial3D *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_transmittance_color, 2920490490, void, self, color)
}
godot_Color godot_BaseMaterial3D_get_transmittance_color(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_transmittance_color, 3444240500, godot_Color, self)
}
void godot_BaseMaterial3D_set_transmittance_depth(godot_BaseMaterial3D *self, godot_float depth) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_transmittance_depth, 373806689, void, self, &depth)
}
godot_float godot_BaseMaterial3D_get_transmittance_depth(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_transmittance_depth, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_transmittance_boost(godot_BaseMaterial3D *self, godot_float boost) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_transmittance_boost, 373806689, void, self, &boost)
}
godot_float godot_BaseMaterial3D_get_transmittance_boost(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_transmittance_boost, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_backlight(godot_BaseMaterial3D *self, const godot_Color *backlight) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_backlight, 2920490490, void, self, backlight)
}
godot_Color godot_BaseMaterial3D_get_backlight(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_backlight, 3444240500, godot_Color, self)
}
void godot_BaseMaterial3D_set_refraction(godot_BaseMaterial3D *self, godot_float refraction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_refraction, 373806689, void, self, &refraction)
}
godot_float godot_BaseMaterial3D_get_refraction(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_refraction, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_point_size(godot_BaseMaterial3D *self, godot_float point_size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_point_size, 373806689, void, self, &point_size)
}
godot_float godot_BaseMaterial3D_get_point_size(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_point_size, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_detail_uv(godot_BaseMaterial3D *self, godot_BaseMaterial3D_DetailUV detail_uv) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_detail_uv, 456801921, void, self, &detail_uv)
}
godot_BaseMaterial3D_DetailUV godot_BaseMaterial3D_get_detail_uv(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_detail_uv, 2306920512, godot_BaseMaterial3D_DetailUV, self)
}
void godot_BaseMaterial3D_set_blend_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_BlendMode blend_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_blend_mode, 2830186259, void, self, &blend_mode)
}
godot_BaseMaterial3D_BlendMode godot_BaseMaterial3D_get_blend_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_blend_mode, 4022690962, godot_BaseMaterial3D_BlendMode, self)
}
void godot_BaseMaterial3D_set_depth_draw_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_DepthDrawMode depth_draw_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_depth_draw_mode, 1456584748, void, self, &depth_draw_mode)
}
godot_BaseMaterial3D_DepthDrawMode godot_BaseMaterial3D_get_depth_draw_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_depth_draw_mode, 2578197639, godot_BaseMaterial3D_DepthDrawMode, self)
}
void godot_BaseMaterial3D_set_depth_test(godot_BaseMaterial3D *self, godot_BaseMaterial3D_DepthTest depth_test) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_depth_test, 3918692338, void, self, &depth_test)
}
godot_BaseMaterial3D_DepthTest godot_BaseMaterial3D_get_depth_test(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_depth_test, 3434785811, godot_BaseMaterial3D_DepthTest, self)
}
void godot_BaseMaterial3D_set_cull_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_CullMode cull_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_cull_mode, 2338909218, void, self, &cull_mode)
}
godot_BaseMaterial3D_CullMode godot_BaseMaterial3D_get_cull_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_cull_mode, 1941499586, godot_BaseMaterial3D_CullMode, self)
}
void godot_BaseMaterial3D_set_diffuse_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_DiffuseMode diffuse_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_diffuse_mode, 1045299638, void, self, &diffuse_mode)
}
godot_BaseMaterial3D_DiffuseMode godot_BaseMaterial3D_get_diffuse_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_diffuse_mode, 3973617136, godot_BaseMaterial3D_DiffuseMode, self)
}
void godot_BaseMaterial3D_set_specular_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_SpecularMode specular_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_specular_mode, 584737147, void, self, &specular_mode)
}
godot_BaseMaterial3D_SpecularMode godot_BaseMaterial3D_get_specular_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_specular_mode, 2569953298, godot_BaseMaterial3D_SpecularMode, self)
}
void godot_BaseMaterial3D_set_flag(godot_BaseMaterial3D *self, godot_BaseMaterial3D_Flags flag, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_flag, 3070159527, void, self, &flag, &enable)
}
godot_bool godot_BaseMaterial3D_get_flag(const godot_BaseMaterial3D *self, godot_BaseMaterial3D_Flags flag) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_flag, 1286410065, godot_bool, self, &flag)
}
void godot_BaseMaterial3D_set_texture_filter(godot_BaseMaterial3D *self, godot_BaseMaterial3D_TextureFilter mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_texture_filter, 22904437, void, self, &mode)
}
godot_BaseMaterial3D_TextureFilter godot_BaseMaterial3D_get_texture_filter(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_texture_filter, 3289213076, godot_BaseMaterial3D_TextureFilter, self)
}
void godot_BaseMaterial3D_set_feature(godot_BaseMaterial3D *self, godot_BaseMaterial3D_Feature feature, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_feature, 2819288693, void, self, &feature, &enable)
}
godot_bool godot_BaseMaterial3D_get_feature(const godot_BaseMaterial3D *self, godot_BaseMaterial3D_Feature feature) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_feature, 1965241794, godot_bool, self, &feature)
}
void godot_BaseMaterial3D_set_texture(godot_BaseMaterial3D *self, godot_BaseMaterial3D_TextureParam param, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_texture, 464208135, void, self, &param, texture)
}
godot_Texture2D * godot_BaseMaterial3D_get_texture(const godot_BaseMaterial3D *self, godot_BaseMaterial3D_TextureParam param) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_texture, 329605813, godot_Texture2D *, self, &param)
}
void godot_BaseMaterial3D_set_detail_blend_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_BlendMode detail_blend_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_detail_blend_mode, 2830186259, void, self, &detail_blend_mode)
}
godot_BaseMaterial3D_BlendMode godot_BaseMaterial3D_get_detail_blend_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_detail_blend_mode, 4022690962, godot_BaseMaterial3D_BlendMode, self)
}
void godot_BaseMaterial3D_set_uv1_scale(godot_BaseMaterial3D *self, const godot_Vector3 *scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_uv1_scale, 3460891852, void, self, scale)
}
godot_Vector3 godot_BaseMaterial3D_get_uv1_scale(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_uv1_scale, 3360562783, godot_Vector3, self)
}
void godot_BaseMaterial3D_set_uv1_offset(godot_BaseMaterial3D *self, const godot_Vector3 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_uv1_offset, 3460891852, void, self, offset)
}
godot_Vector3 godot_BaseMaterial3D_get_uv1_offset(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_uv1_offset, 3360562783, godot_Vector3, self)
}
void godot_BaseMaterial3D_set_uv1_triplanar_blend_sharpness(godot_BaseMaterial3D *self, godot_float sharpness) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_uv1_triplanar_blend_sharpness, 373806689, void, self, &sharpness)
}
godot_float godot_BaseMaterial3D_get_uv1_triplanar_blend_sharpness(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_uv1_triplanar_blend_sharpness, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_uv2_scale(godot_BaseMaterial3D *self, const godot_Vector3 *scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_uv2_scale, 3460891852, void, self, scale)
}
godot_Vector3 godot_BaseMaterial3D_get_uv2_scale(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_uv2_scale, 3360562783, godot_Vector3, self)
}
void godot_BaseMaterial3D_set_uv2_offset(godot_BaseMaterial3D *self, const godot_Vector3 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_uv2_offset, 3460891852, void, self, offset)
}
godot_Vector3 godot_BaseMaterial3D_get_uv2_offset(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_uv2_offset, 3360562783, godot_Vector3, self)
}
void godot_BaseMaterial3D_set_uv2_triplanar_blend_sharpness(godot_BaseMaterial3D *self, godot_float sharpness) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_uv2_triplanar_blend_sharpness, 373806689, void, self, &sharpness)
}
godot_float godot_BaseMaterial3D_get_uv2_triplanar_blend_sharpness(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_uv2_triplanar_blend_sharpness, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_billboard_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_BillboardMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_billboard_mode, 4202036497, void, self, &mode)
}
godot_BaseMaterial3D_BillboardMode godot_BaseMaterial3D_get_billboard_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_billboard_mode, 1283840139, godot_BaseMaterial3D_BillboardMode, self)
}
void godot_BaseMaterial3D_set_particles_anim_h_frames(godot_BaseMaterial3D *self, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_particles_anim_h_frames, 1286410249, void, self, &frames)
}
godot_int godot_BaseMaterial3D_get_particles_anim_h_frames(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_particles_anim_h_frames, 3905245786, godot_int, self)
}
void godot_BaseMaterial3D_set_particles_anim_v_frames(godot_BaseMaterial3D *self, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_particles_anim_v_frames, 1286410249, void, self, &frames)
}
godot_int godot_BaseMaterial3D_get_particles_anim_v_frames(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_particles_anim_v_frames, 3905245786, godot_int, self)
}
void godot_BaseMaterial3D_set_particles_anim_loop(godot_BaseMaterial3D *self, godot_bool loop) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_particles_anim_loop, 2586408642, void, self, &loop)
}
godot_bool godot_BaseMaterial3D_get_particles_anim_loop(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_particles_anim_loop, 36873697, godot_bool, self)
}
void godot_BaseMaterial3D_set_heightmap_deep_parallax(godot_BaseMaterial3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_heightmap_deep_parallax, 2586408642, void, self, &enable)
}
godot_bool godot_BaseMaterial3D_is_heightmap_deep_parallax_enabled(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, is_heightmap_deep_parallax_enabled, 36873697, godot_bool, self)
}
void godot_BaseMaterial3D_set_heightmap_deep_parallax_min_layers(godot_BaseMaterial3D *self, godot_int layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_heightmap_deep_parallax_min_layers, 1286410249, void, self, &layer)
}
godot_int godot_BaseMaterial3D_get_heightmap_deep_parallax_min_layers(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_heightmap_deep_parallax_min_layers, 3905245786, godot_int, self)
}
void godot_BaseMaterial3D_set_heightmap_deep_parallax_max_layers(godot_BaseMaterial3D *self, godot_int layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_heightmap_deep_parallax_max_layers, 1286410249, void, self, &layer)
}
godot_int godot_BaseMaterial3D_get_heightmap_deep_parallax_max_layers(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_heightmap_deep_parallax_max_layers, 3905245786, godot_int, self)
}
void godot_BaseMaterial3D_set_heightmap_deep_parallax_flip_tangent(godot_BaseMaterial3D *self, godot_bool flip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_heightmap_deep_parallax_flip_tangent, 2586408642, void, self, &flip)
}
godot_bool godot_BaseMaterial3D_get_heightmap_deep_parallax_flip_tangent(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_heightmap_deep_parallax_flip_tangent, 36873697, godot_bool, self)
}
void godot_BaseMaterial3D_set_heightmap_deep_parallax_flip_binormal(godot_BaseMaterial3D *self, godot_bool flip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_heightmap_deep_parallax_flip_binormal, 2586408642, void, self, &flip)
}
godot_bool godot_BaseMaterial3D_get_heightmap_deep_parallax_flip_binormal(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_heightmap_deep_parallax_flip_binormal, 36873697, godot_bool, self)
}
void godot_BaseMaterial3D_set_grow(godot_BaseMaterial3D *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_grow, 373806689, void, self, &amount)
}
godot_float godot_BaseMaterial3D_get_grow(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_grow, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_emission_operator(godot_BaseMaterial3D *self, godot_BaseMaterial3D_EmissionOperator op) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_emission_operator, 3825128922, void, self, &op)
}
godot_BaseMaterial3D_EmissionOperator godot_BaseMaterial3D_get_emission_operator(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_emission_operator, 974205018, godot_BaseMaterial3D_EmissionOperator, self)
}
void godot_BaseMaterial3D_set_ao_light_affect(godot_BaseMaterial3D *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_ao_light_affect, 373806689, void, self, &amount)
}
godot_float godot_BaseMaterial3D_get_ao_light_affect(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_ao_light_affect, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_alpha_scissor_threshold(godot_BaseMaterial3D *self, godot_float threshold) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_alpha_scissor_threshold, 373806689, void, self, &threshold)
}
godot_float godot_BaseMaterial3D_get_alpha_scissor_threshold(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_alpha_scissor_threshold, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_alpha_hash_scale(godot_BaseMaterial3D *self, godot_float threshold) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_alpha_hash_scale, 373806689, void, self, &threshold)
}
godot_float godot_BaseMaterial3D_get_alpha_hash_scale(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_alpha_hash_scale, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_grow_enabled(godot_BaseMaterial3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_grow_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_BaseMaterial3D_is_grow_enabled(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, is_grow_enabled, 36873697, godot_bool, self)
}
void godot_BaseMaterial3D_set_metallic_texture_channel(godot_BaseMaterial3D *self, godot_BaseMaterial3D_TextureChannel channel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_metallic_texture_channel, 744167988, void, self, &channel)
}
godot_BaseMaterial3D_TextureChannel godot_BaseMaterial3D_get_metallic_texture_channel(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_metallic_texture_channel, 568133867, godot_BaseMaterial3D_TextureChannel, self)
}
void godot_BaseMaterial3D_set_roughness_texture_channel(godot_BaseMaterial3D *self, godot_BaseMaterial3D_TextureChannel channel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_roughness_texture_channel, 744167988, void, self, &channel)
}
godot_BaseMaterial3D_TextureChannel godot_BaseMaterial3D_get_roughness_texture_channel(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_roughness_texture_channel, 568133867, godot_BaseMaterial3D_TextureChannel, self)
}
void godot_BaseMaterial3D_set_ao_texture_channel(godot_BaseMaterial3D *self, godot_BaseMaterial3D_TextureChannel channel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_ao_texture_channel, 744167988, void, self, &channel)
}
godot_BaseMaterial3D_TextureChannel godot_BaseMaterial3D_get_ao_texture_channel(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_ao_texture_channel, 568133867, godot_BaseMaterial3D_TextureChannel, self)
}
void godot_BaseMaterial3D_set_refraction_texture_channel(godot_BaseMaterial3D *self, godot_BaseMaterial3D_TextureChannel channel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_refraction_texture_channel, 744167988, void, self, &channel)
}
godot_BaseMaterial3D_TextureChannel godot_BaseMaterial3D_get_refraction_texture_channel(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_refraction_texture_channel, 568133867, godot_BaseMaterial3D_TextureChannel, self)
}
void godot_BaseMaterial3D_set_proximity_fade_enabled(godot_BaseMaterial3D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_proximity_fade_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_BaseMaterial3D_is_proximity_fade_enabled(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, is_proximity_fade_enabled, 36873697, godot_bool, self)
}
void godot_BaseMaterial3D_set_proximity_fade_distance(godot_BaseMaterial3D *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_proximity_fade_distance, 373806689, void, self, &distance)
}
godot_float godot_BaseMaterial3D_get_proximity_fade_distance(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_proximity_fade_distance, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_msdf_pixel_range(godot_BaseMaterial3D *self, godot_float range) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_msdf_pixel_range, 373806689, void, self, &range)
}
godot_float godot_BaseMaterial3D_get_msdf_pixel_range(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_msdf_pixel_range, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_msdf_outline_size(godot_BaseMaterial3D *self, godot_float size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_msdf_outline_size, 373806689, void, self, &size)
}
godot_float godot_BaseMaterial3D_get_msdf_outline_size(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_msdf_outline_size, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_distance_fade(godot_BaseMaterial3D *self, godot_BaseMaterial3D_DistanceFadeMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_distance_fade, 1379478617, void, self, &mode)
}
godot_BaseMaterial3D_DistanceFadeMode godot_BaseMaterial3D_get_distance_fade(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_distance_fade, 2694575734, godot_BaseMaterial3D_DistanceFadeMode, self)
}
void godot_BaseMaterial3D_set_distance_fade_max_distance(godot_BaseMaterial3D *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_distance_fade_max_distance, 373806689, void, self, &distance)
}
godot_float godot_BaseMaterial3D_get_distance_fade_max_distance(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_distance_fade_max_distance, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_distance_fade_min_distance(godot_BaseMaterial3D *self, godot_float distance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_distance_fade_min_distance, 373806689, void, self, &distance)
}
godot_float godot_BaseMaterial3D_get_distance_fade_min_distance(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_distance_fade_min_distance, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_z_clip_scale(godot_BaseMaterial3D *self, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_z_clip_scale, 373806689, void, self, &scale)
}
godot_float godot_BaseMaterial3D_get_z_clip_scale(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_z_clip_scale, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_fov_override(godot_BaseMaterial3D *self, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_fov_override, 373806689, void, self, &scale)
}
godot_float godot_BaseMaterial3D_get_fov_override(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_fov_override, 1740695150, godot_float, self)
}
void godot_BaseMaterial3D_set_stencil_mode(godot_BaseMaterial3D *self, godot_BaseMaterial3D_StencilMode stencil_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_stencil_mode, 2272367200, void, self, &stencil_mode)
}
godot_BaseMaterial3D_StencilMode godot_BaseMaterial3D_get_stencil_mode(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_stencil_mode, 2908443456, godot_BaseMaterial3D_StencilMode, self)
}
void godot_BaseMaterial3D_set_stencil_flags(godot_BaseMaterial3D *self, godot_int stencil_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_stencil_flags, 1286410249, void, self, &stencil_flags)
}
godot_int godot_BaseMaterial3D_get_stencil_flags(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_stencil_flags, 3905245786, godot_int, self)
}
void godot_BaseMaterial3D_set_stencil_compare(godot_BaseMaterial3D *self, godot_BaseMaterial3D_StencilCompare stencil_compare) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_stencil_compare, 3741726481, void, self, &stencil_compare)
}
godot_BaseMaterial3D_StencilCompare godot_BaseMaterial3D_get_stencil_compare(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_stencil_compare, 2824600492, godot_BaseMaterial3D_StencilCompare, self)
}
void godot_BaseMaterial3D_set_stencil_reference(godot_BaseMaterial3D *self, godot_int stencil_reference) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_stencil_reference, 1286410249, void, self, &stencil_reference)
}
godot_int godot_BaseMaterial3D_get_stencil_reference(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_stencil_reference, 3905245786, godot_int, self)
}
void godot_BaseMaterial3D_set_stencil_effect_color(godot_BaseMaterial3D *self, const godot_Color *stencil_color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_stencil_effect_color, 2920490490, void, self, stencil_color)
}
godot_Color godot_BaseMaterial3D_get_stencil_effect_color(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_stencil_effect_color, 3444240500, godot_Color, self)
}
void godot_BaseMaterial3D_set_stencil_effect_outline_thickness(godot_BaseMaterial3D *self, godot_float stencil_outline_thickness) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BaseMaterial3D, set_stencil_effect_outline_thickness, 373806689, void, self, &stencil_outline_thickness)
}
godot_float godot_BaseMaterial3D_get_stencil_effect_outline_thickness(const godot_BaseMaterial3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BaseMaterial3D, get_stencil_effect_outline_thickness, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
