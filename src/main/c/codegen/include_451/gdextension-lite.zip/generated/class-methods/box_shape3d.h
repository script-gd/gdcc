// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_SHAPE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_SHAPE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BoxShape3D *godot_new_BoxShape3D();

// Methods
GDEXTENSION_LITE_DECL void godot_BoxShape3D_set_size(godot_BoxShape3D *self, const godot_Vector3 *size);
GDEXTENSION_LITE_DECL godot_Vector3 godot_BoxShape3D_get_size(const godot_BoxShape3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_SHAPE3D_H__
