// This file was automatically generated
// Do not modify this file
#include "audio_effect_pitch_shift.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectPitchShift *godot_new_AudioEffectPitchShift() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectPitchShift);
}

// Methods
void godot_AudioEffectPitchShift_set_pitch_scale(godot_AudioEffectPitchShift *self, godot_float rate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPitchShift, set_pitch_scale, 373806689, void, self, &rate)
}
godot_float godot_AudioEffectPitchShift_get_pitch_scale(const godot_AudioEffectPitchShift *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPitchShift, get_pitch_scale, 1740695150, godot_float, self)
}
void godot_AudioEffectPitchShift_set_oversampling(godot_AudioEffectPitchShift *self, godot_int amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPitchShift, set_oversampling, 1286410249, void, self, &amount)
}
godot_int godot_AudioEffectPitchShift_get_oversampling(const godot_AudioEffectPitchShift *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPitchShift, get_oversampling, 3905245786, godot_int, self)
}
void godot_AudioEffectPitchShift_set_fft_size(godot_AudioEffectPitchShift *self, godot_AudioEffectPitchShift_FFTSize size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectPitchShift, set_fft_size, 2323518741, void, self, &size)
}
godot_AudioEffectPitchShift_FFTSize godot_AudioEffectPitchShift_get_fft_size(const godot_AudioEffectPitchShift *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectPitchShift, get_fft_size, 2361246789, godot_AudioEffectPitchShift_FFTSize, self)
}


#ifdef __cplusplus
}
#endif
