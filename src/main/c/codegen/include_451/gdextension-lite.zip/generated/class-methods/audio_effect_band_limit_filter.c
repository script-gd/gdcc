// This file was automatically generated
// Do not modify this file
#include "audio_effect_band_limit_filter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectBandLimitFilter *godot_new_AudioEffectBandLimitFilter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectBandLimitFilter);
}


#ifdef __cplusplus
}
#endif
