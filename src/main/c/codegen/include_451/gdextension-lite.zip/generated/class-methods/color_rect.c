// This file was automatically generated
// Do not modify this file
#include "color_rect.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ColorRect *godot_new_ColorRect() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ColorRect);
}

// Methods
void godot_ColorRect_set_color(godot_ColorRect *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorRect, set_color, 2920490490, void, self, color)
}
godot_Color godot_ColorRect_get_color(const godot_ColorRect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorRect, get_color, 3444240500, godot_Color, self)
}


#ifdef __cplusplus
}
#endif
