// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CYLINDER_MESH_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CYLINDER_MESH_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CylinderMesh *godot_new_CylinderMesh();

// Methods
GDEXTENSION_LITE_DECL void godot_CylinderMesh_set_top_radius(godot_CylinderMesh *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CylinderMesh_get_top_radius(const godot_CylinderMesh *self);
GDEXTENSION_LITE_DECL void godot_CylinderMesh_set_bottom_radius(godot_CylinderMesh *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CylinderMesh_get_bottom_radius(const godot_CylinderMesh *self);
GDEXTENSION_LITE_DECL void godot_CylinderMesh_set_height(godot_CylinderMesh *self, godot_float height);
GDEXTENSION_LITE_DECL godot_float godot_CylinderMesh_get_height(const godot_CylinderMesh *self);
GDEXTENSION_LITE_DECL void godot_CylinderMesh_set_radial_segments(godot_CylinderMesh *self, godot_int segments);
GDEXTENSION_LITE_DECL godot_int godot_CylinderMesh_get_radial_segments(const godot_CylinderMesh *self);
GDEXTENSION_LITE_DECL void godot_CylinderMesh_set_rings(godot_CylinderMesh *self, godot_int rings);
GDEXTENSION_LITE_DECL godot_int godot_CylinderMesh_get_rings(const godot_CylinderMesh *self);
GDEXTENSION_LITE_DECL void godot_CylinderMesh_set_cap_top(godot_CylinderMesh *self, godot_bool cap_top);
GDEXTENSION_LITE_DECL godot_bool godot_CylinderMesh_is_cap_top(const godot_CylinderMesh *self);
GDEXTENSION_LITE_DECL void godot_CylinderMesh_set_cap_bottom(godot_CylinderMesh *self, godot_bool cap_bottom);
GDEXTENSION_LITE_DECL godot_bool godot_CylinderMesh_is_cap_bottom(const godot_CylinderMesh *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CYLINDER_MESH_H__
