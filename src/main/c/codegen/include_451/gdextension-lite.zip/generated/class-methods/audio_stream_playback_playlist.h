// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_PLAYLIST_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_PLAYLIST_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"



#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_PLAYLIST_H__
