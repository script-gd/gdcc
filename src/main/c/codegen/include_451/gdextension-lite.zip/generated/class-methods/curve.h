// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Curve *godot_new_Curve();

// Methods
GDEXTENSION_LITE_DECL godot_int godot_Curve_get_point_count(const godot_Curve *self);
GDEXTENSION_LITE_DECL void godot_Curve_set_point_count(godot_Curve *self, godot_int count);
GDEXTENSION_LITE_DECL godot_int godot_Curve_add_point(godot_Curve *self, const godot_Vector2 *position, godot_float left_tangent, godot_float right_tangent, godot_Curve_TangentMode left_mode, godot_Curve_TangentMode right_mode);
GDEXTENSION_LITE_DECL void godot_Curve_remove_point(godot_Curve *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_Curve_clear_points(godot_Curve *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Curve_get_point_position(const godot_Curve *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_Curve_set_point_value(godot_Curve *self, godot_int index, godot_float y);
GDEXTENSION_LITE_DECL godot_int godot_Curve_set_point_offset(godot_Curve *self, godot_int index, godot_float offset);
GDEXTENSION_LITE_DECL godot_float godot_Curve_sample(const godot_Curve *self, godot_float offset);
GDEXTENSION_LITE_DECL godot_float godot_Curve_sample_baked(const godot_Curve *self, godot_float offset);
GDEXTENSION_LITE_DECL godot_float godot_Curve_get_point_left_tangent(const godot_Curve *self, godot_int index);
GDEXTENSION_LITE_DECL godot_float godot_Curve_get_point_right_tangent(const godot_Curve *self, godot_int index);
GDEXTENSION_LITE_DECL godot_Curve_TangentMode godot_Curve_get_point_left_mode(const godot_Curve *self, godot_int index);
GDEXTENSION_LITE_DECL godot_Curve_TangentMode godot_Curve_get_point_right_mode(const godot_Curve *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_Curve_set_point_left_tangent(godot_Curve *self, godot_int index, godot_float tangent);
GDEXTENSION_LITE_DECL void godot_Curve_set_point_right_tangent(godot_Curve *self, godot_int index, godot_float tangent);
GDEXTENSION_LITE_DECL void godot_Curve_set_point_left_mode(godot_Curve *self, godot_int index, godot_Curve_TangentMode mode);
GDEXTENSION_LITE_DECL void godot_Curve_set_point_right_mode(godot_Curve *self, godot_int index, godot_Curve_TangentMode mode);
GDEXTENSION_LITE_DECL godot_float godot_Curve_get_min_value(const godot_Curve *self);
GDEXTENSION_LITE_DECL void godot_Curve_set_min_value(godot_Curve *self, godot_float min);
GDEXTENSION_LITE_DECL godot_float godot_Curve_get_max_value(const godot_Curve *self);
GDEXTENSION_LITE_DECL void godot_Curve_set_max_value(godot_Curve *self, godot_float max);
GDEXTENSION_LITE_DECL godot_float godot_Curve_get_value_range(const godot_Curve *self);
GDEXTENSION_LITE_DECL godot_float godot_Curve_get_min_domain(const godot_Curve *self);
GDEXTENSION_LITE_DECL void godot_Curve_set_min_domain(godot_Curve *self, godot_float min);
GDEXTENSION_LITE_DECL godot_float godot_Curve_get_max_domain(const godot_Curve *self);
GDEXTENSION_LITE_DECL void godot_Curve_set_max_domain(godot_Curve *self, godot_float max);
GDEXTENSION_LITE_DECL godot_float godot_Curve_get_domain_range(const godot_Curve *self);
GDEXTENSION_LITE_DECL void godot_Curve_clean_dupes(godot_Curve *self);
GDEXTENSION_LITE_DECL void godot_Curve_bake(godot_Curve *self);
GDEXTENSION_LITE_DECL godot_int godot_Curve_get_bake_resolution(const godot_Curve *self);
GDEXTENSION_LITE_DECL void godot_Curve_set_bake_resolution(godot_Curve *self, godot_int resolution);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_H__
