// This file was automatically generated
// Do not modify this file
#include "audio_effect_compressor.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectCompressor *godot_new_AudioEffectCompressor() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectCompressor);
}

// Methods
void godot_AudioEffectCompressor_set_threshold(godot_AudioEffectCompressor *self, godot_float threshold) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCompressor, set_threshold, 373806689, void, self, &threshold)
}
godot_float godot_AudioEffectCompressor_get_threshold(const godot_AudioEffectCompressor *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCompressor, get_threshold, 1740695150, godot_float, self)
}
void godot_AudioEffectCompressor_set_ratio(godot_AudioEffectCompressor *self, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCompressor, set_ratio, 373806689, void, self, &ratio)
}
godot_float godot_AudioEffectCompressor_get_ratio(const godot_AudioEffectCompressor *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCompressor, get_ratio, 1740695150, godot_float, self)
}
void godot_AudioEffectCompressor_set_gain(godot_AudioEffectCompressor *self, godot_float gain) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCompressor, set_gain, 373806689, void, self, &gain)
}
godot_float godot_AudioEffectCompressor_get_gain(const godot_AudioEffectCompressor *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCompressor, get_gain, 1740695150, godot_float, self)
}
void godot_AudioEffectCompressor_set_attack_us(godot_AudioEffectCompressor *self, godot_float attack_us) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCompressor, set_attack_us, 373806689, void, self, &attack_us)
}
godot_float godot_AudioEffectCompressor_get_attack_us(const godot_AudioEffectCompressor *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCompressor, get_attack_us, 1740695150, godot_float, self)
}
void godot_AudioEffectCompressor_set_release_ms(godot_AudioEffectCompressor *self, godot_float release_ms) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCompressor, set_release_ms, 373806689, void, self, &release_ms)
}
godot_float godot_AudioEffectCompressor_get_release_ms(const godot_AudioEffectCompressor *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCompressor, get_release_ms, 1740695150, godot_float, self)
}
void godot_AudioEffectCompressor_set_mix(godot_AudioEffectCompressor *self, godot_float mix) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCompressor, set_mix, 373806689, void, self, &mix)
}
godot_float godot_AudioEffectCompressor_get_mix(const godot_AudioEffectCompressor *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCompressor, get_mix, 1740695150, godot_float, self)
}
void godot_AudioEffectCompressor_set_sidechain(godot_AudioEffectCompressor *self, const godot_StringName *sidechain) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCompressor, set_sidechain, 3304788590, void, self, sidechain)
}
godot_StringName godot_AudioEffectCompressor_get_sidechain(const godot_AudioEffectCompressor *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCompressor, get_sidechain, 2002593661, godot_StringName, self)
}


#ifdef __cplusplus
}
#endif
