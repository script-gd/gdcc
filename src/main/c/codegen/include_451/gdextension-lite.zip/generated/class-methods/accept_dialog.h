// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ACCEPT_DIALOG_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ACCEPT_DIALOG_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AcceptDialog *godot_new_AcceptDialog();

// Methods
GDEXTENSION_LITE_DECL godot_Button * godot_AcceptDialog_get_ok_button(godot_AcceptDialog *self);
GDEXTENSION_LITE_DECL godot_Label * godot_AcceptDialog_get_label(godot_AcceptDialog *self);
GDEXTENSION_LITE_DECL void godot_AcceptDialog_set_hide_on_ok(godot_AcceptDialog *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_AcceptDialog_get_hide_on_ok(const godot_AcceptDialog *self);
GDEXTENSION_LITE_DECL void godot_AcceptDialog_set_close_on_escape(godot_AcceptDialog *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_AcceptDialog_get_close_on_escape(const godot_AcceptDialog *self);
GDEXTENSION_LITE_DECL godot_Button * godot_AcceptDialog_add_button(godot_AcceptDialog *self, const godot_String *text, godot_bool right, const godot_String *action);
GDEXTENSION_LITE_DECL godot_Button * godot_AcceptDialog_add_cancel_button(godot_AcceptDialog *self, const godot_String *name);
GDEXTENSION_LITE_DECL void godot_AcceptDialog_remove_button(godot_AcceptDialog *self, const godot_Button *button);
GDEXTENSION_LITE_DECL void godot_AcceptDialog_register_text_enter(godot_AcceptDialog *self, const godot_LineEdit *line_edit);
GDEXTENSION_LITE_DECL void godot_AcceptDialog_set_text(godot_AcceptDialog *self, const godot_String *text);
GDEXTENSION_LITE_DECL godot_String godot_AcceptDialog_get_text(const godot_AcceptDialog *self);
GDEXTENSION_LITE_DECL void godot_AcceptDialog_set_autowrap(godot_AcceptDialog *self, godot_bool autowrap);
GDEXTENSION_LITE_DECL godot_bool godot_AcceptDialog_has_autowrap(godot_AcceptDialog *self);
GDEXTENSION_LITE_DECL void godot_AcceptDialog_set_ok_button_text(godot_AcceptDialog *self, const godot_String *text);
GDEXTENSION_LITE_DECL godot_String godot_AcceptDialog_get_ok_button_text(const godot_AcceptDialog *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ACCEPT_DIALOG_H__
