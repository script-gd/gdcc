// This file was automatically generated
// Do not modify this file
#include "animation_node_time_seek.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeTimeSeek *godot_new_AnimationNodeTimeSeek() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeTimeSeek);
}

// Methods
void godot_AnimationNodeTimeSeek_set_explicit_elapse(godot_AnimationNodeTimeSeek *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeTimeSeek, set_explicit_elapse, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeTimeSeek_is_explicit_elapse(const godot_AnimationNodeTimeSeek *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeTimeSeek, is_explicit_elapse, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
