// This file was automatically generated
// Do not modify this file
#include "editor_debugger_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorDebuggerPlugin *godot_new_EditorDebuggerPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorDebuggerPlugin);
}

// Methods
void godot_EditorDebuggerPlugin__setup_session(godot_EditorDebuggerPlugin *self, godot_int session_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerPlugin, _setup_session, 1286410249, void, self, &session_id)
}
godot_bool godot_EditorDebuggerPlugin__has_capture(const godot_EditorDebuggerPlugin *self, const godot_String *capture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorDebuggerPlugin, _has_capture, 3927539163, godot_bool, self, capture)
}
godot_bool godot_EditorDebuggerPlugin__capture(godot_EditorDebuggerPlugin *self, const godot_String *message, const godot_Array *data, godot_int session_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorDebuggerPlugin, _capture, 2607901833, godot_bool, self, message, data, &session_id)
}
void godot_EditorDebuggerPlugin__goto_script_line(godot_EditorDebuggerPlugin *self, const godot_Script *script, godot_int line) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerPlugin, _goto_script_line, 1208513123, void, self, script, &line)
}
void godot_EditorDebuggerPlugin__breakpoints_cleared_in_tree(godot_EditorDebuggerPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerPlugin, _breakpoints_cleared_in_tree, 3218959716, void, self)
}
void godot_EditorDebuggerPlugin__breakpoint_set_in_tree(godot_EditorDebuggerPlugin *self, const godot_Script *script, godot_int line, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorDebuggerPlugin, _breakpoint_set_in_tree, 2338735218, void, self, script, &line, &enabled)
}
godot_EditorDebuggerSession * godot_EditorDebuggerPlugin_get_session(godot_EditorDebuggerPlugin *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorDebuggerPlugin, get_session, 3061968499, godot_EditorDebuggerSession *, self, &id)
}
godot_Array godot_EditorDebuggerPlugin_get_sessions(godot_EditorDebuggerPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorDebuggerPlugin, get_sessions, 2915620761, godot_Array, self)
}


#ifdef __cplusplus
}
#endif
