// This file was automatically generated
// Do not modify this file
#include "crypto_key.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CryptoKey *godot_new_CryptoKey() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CryptoKey);
}

// Methods
godot_Error godot_CryptoKey_save(godot_CryptoKey *self, const godot_String *path, godot_bool public_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CryptoKey, save, 885841341, godot_Error, self, path, &public_only)
}
godot_Error godot_CryptoKey_load(godot_CryptoKey *self, const godot_String *path, godot_bool public_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CryptoKey, load, 885841341, godot_Error, self, path, &public_only)
}
godot_bool godot_CryptoKey_is_public_only(const godot_CryptoKey *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CryptoKey, is_public_only, 36873697, godot_bool, self)
}
godot_String godot_CryptoKey_save_to_string(godot_CryptoKey *self, godot_bool public_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CryptoKey, save_to_string, 32795936, godot_String, self, &public_only)
}
godot_Error godot_CryptoKey_load_from_string(godot_CryptoKey *self, const godot_String *string_key, godot_bool public_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CryptoKey, load_from_string, 885841341, godot_Error, self, string_key, &public_only)
}


#ifdef __cplusplus
}
#endif
